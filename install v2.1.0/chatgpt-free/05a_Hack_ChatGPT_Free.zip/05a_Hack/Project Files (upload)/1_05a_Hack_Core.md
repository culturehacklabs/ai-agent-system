# FILE: KB_05a_Hack_Actions_A.md

# KB: Hack — Actions A: The Hacking Tree
**Agent 05a · CHL AI Agent System**
*Load when working through any branch of the Hacking Tree: Media, Meme, Tone, or Hack.*

---

## Branch 1 — Media: What form carries the message?

### 1.1 Audiences

**If Agent 04 outputs are available:**
Reference the Audience Profile(s) from Agent 04 directly. Ask: are these still the right audiences for this hack, or has anything shifted? If multiple audience profiles exist, confirm which one(s) this hack is designed to reach — only proceed with audiences that are close enough in cultural ground to be served by one intervention.

**If using Stand-alone Mode:**
Collect the light Audience Profile from the Module before proceeding. Essential fields only. Do not accept "the general public."

### 1.2 Intersections

Once audiences are confirmed, identify the shared cultural ground:
- What platforms, spaces, or media do they both use?
- What aesthetic, genre, or cultural references do they share?
- What experiences, values, or emotional states connect them?

This is the strategic input to format choice. The intersection is where the hack can land for both audiences simultaneously — without diluting the message for either.

### 1.3 Format

Choose the specific medium that fits the audience intersection and is within the team's real production capacity.

```
## Branch 1 — Media

**Audiences:**
- Audience 1: [name — from Agent 04 or light profile]
- Audience 2 (if applicable): [name — confirm shared cultural ground exists]

**Intersections:**
- Shared platforms/spaces: [what they both use]
- Shared cultural references: [aesthetic, genre, figures, symbols]
- Shared emotional ground: [what connects them]
- Bridging element: [the specific thing that makes one format viable for both]

**Format:**
- Primary format: [specific medium — TikTok video, mural, op-ed, song, workshop, performance, etc.]
- Why this format: [audience fit + strategic reasoning]
- Production capacity: [honest assessment — can the team make this?]
- Distribution plan: [how it reaches the audience]

**Format specifications (complete the relevant type):**

Digital/Social Media:
- Platform: / Content type: / Visual style:

Physical/Offline:
- Format: / Location type: / Scale: / Duration:

Media/Publication:
- Type: / Outlet targets: / Style:

Cultural Production:
- Type: / Form: / Distribution:

Educational/Organising:
- Type: / Format: / Scalability:
```

---

## Branch 2 — Meme: What is the sticky cultural unit?

**Transition note:** Your message from Agent 04 is the full structure of meaning — 1 to 3 paragraphs carrying the recoded logic, framing, and worldview. The meme is what that message becomes in the hands of the audience: a hashtag, a slogan, an image, a gesture. It is the vessel. The whole narrative travels inside it without being stated. That is the memetic power — the logic jumps from mind to mind without the explanation.

### 2.1 Symbols

Identify existing cultural objects already in circulation in the audience's world:
- What symbols (flags, gestures, colours, words, images, figures) carry emotional or cultural weight?
- Which are already associated with the issue, the movement, or the community?
- Which are surprising — unexpected carriers that could reframe how the issue is perceived?

### 2.2 Associations

Remix the symbol's meaning:
- What does this symbol currently mean to the audience?
- What do you want it to mean — what new association activates the recoded frames?
- What is the bridge: how do you move from the old meaning to the new one?

### 2.3 Synthesis

Produce the exact cultural unit:

```
## Branch 2 — Meme

**Symbol:**
- Chosen symbol: [what it is]
- Current association: [what it means now to the audience]
- New association: [what you want it to mean]
- Bridge: [how the remix works — what connects old to new]
- Why this symbol: [why it carries weight for this audience]

**Synthesis:**
- The meme: [exact form — hashtag / slogan / image description / gesture / phrase]
- Form: [hashtag / slogan / visual / gesture / other]
- In one line: [state it]

**Stickiness test:**
- Simple: [can anyone grasp it instantly?]
- Unexpected: [does it surprise or intrigue?]
- Concrete: [is it specific and tangible?]
- Credible: [is it believable for this audience?]
- Emotional: [does it make people feel something?]
- Story: [does it carry a story or imply one?]

**Overall assessment:** [what's strong / what to sharpen]
```

---

## Branch 3 — Tone: What emotions carry the message?

### 3.1 Mood

Read the current emotional climate:
- What is the dominant feeling in the narrative space right now?
- What is the target audience feeling about this issue — fear, anger, despair, apathy, hope, determination?
- What emotional patterns are the competing narratives using?

### 3.2 Feelings to Generate

Design the emotional journey:
- What feelings does the hack aim to produce in the audience?
- What is the journey: from where they are now → through what transitional feeling → to where you want them?
- Why these feelings — how do they serve the strategy and lead to agency?

Tone must be empowering, not manipulative. The test: does the emotion produced lead to action, or does it leave people stuck in feeling?

### 3.3 Stimuli

Choose the specific creative tools that produce those feelings:

```
## Branch 3 — Tone

**Current mood:**
- Dominant emotion in narrative space: [what's in the air]
- Target audience's emotional state: [what they're feeling about this issue]
- What competing narratives are doing emotionally: [the emotional landscape you're entering]

**Feelings to generate:**
- Primary emotion(s) to produce: [1–2 feelings]
- Emotional journey: [from → through → to]
- Why these feelings serve the strategy: [connection to objectives and agency]
- Authenticity check: does this emotion empower or trap? [brief assessment]

**Stimuli (complete relevant types):**

Visual (if applicable):
- Colours: / Imagery: / Composition: / Style:

Audio (if applicable):
- Music style: / Tempo: / Voice register: / Sound elements:

Written/spoken (if applicable):
- Language register: / Rhythm: / Word choices: / Rhetorical devices:

Physical/embodied (if applicable):
- Space design: / Movement: / Interaction: / Materiality:
```

---

## Branch 4 — Hack: Where, how big, and when?

### 4.1 Space

Choose where to intervene. Space choice carries symbolic meaning — it is not just a delivery mechanism, it is part of the message.

**Points of intervention (Beautiful Trouble framework):**
- **Point of production** — where things are made (factory, farm, studio, office)
- **Point of destruction** — where harm happens (landfill, clearcut, demolition site)
- **Point of consumption** — where things are bought or used (store, platform, public square)
- **Point of decision** — where power is exercised (government building, boardroom, institution)
- **Point of assumption** — where common sense is produced (media, education, culture)
- **Point of potential** — underutilised space where new things can grow

### 4.2 Scale

Be honest about reach. Ambition is good; overcommitment kills hacks.
- **Micro** — under 100 people (intimate, relational, high trust)
- **Meso** — 100–10,000 (community, network, organisation)
- **Macro** — 10k–1M (city, region, large platform)
- **Mega** — over 1M (national, international, mass scale)

Also assess: primary audience (core reach) + secondary audience (who else gets touched) + viral/replication potential.

### 4.3 Moment

Time the hack to maximise impact:
- **Planned timing** — a set date or period chosen in advance
- **Event-responsive timing** — a political crisis, movement surge, policy announcement, or cultural moment that creates an opening
- **Cyclical timing** — an anniversary, commemoration, ecological cycle, or political rhythm

The wave question: is there momentum already building that this hack can ride? When is it cresting? What is the backup if the planned moment shifts?

```
## Branch 4 — Hack: Space, Scale, Moment

**Space:**
- Type: [physical public / community / virtual / institutional / hybrid]
- Specific location or platform: [name it]
- Point of intervention: [production / destruction / consumption / decision / assumption / potential]
- Why this space creates leverage: [reasoning]
- Symbolic meaning of this space: [what it represents]
- Access and permissions needed: [practical note]

**Scale:**
- Scope: [Micro / Meso / Macro / Mega]
- Primary audience reach (realistic): [estimate]
- Secondary audience reach: [who else might be touched]
- Viral/replication potential: [yes / limited / no — brief note]
- Capacity match: [honest — does this match what the team can actually do?]

**Moment:**
- Timing type: [planned / event-responsive / cyclical]
- Target date or period: [when]
- Wave assessment: [is there momentum to catch? when is it cresting?]
- Response speed if opportunity arises: [how fast can you deploy?]
- Backup timing: [if planned moment shifts]
```


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05a_Hack_Actions_B.md

# KB: Hack — Actions B: Logistics
**Agent 05a · CHL AI Agent System**
*Load when working through Logistics. Offer lean or full track based on practitioner's needs.*

---

## What Logistics Is

Logistics is the reality check. The Hacking Tree designs the intervention; Logistics asks whether the team can actually make it happen — and what needs to be in place before, during, and after.

Two tracks are available:

**Lean logistics ⚡** — for teams that need to move quickly or are in early planning. Covers the essentials: timeline, roles, minimum budget, and documentation baseline. Fast to complete; enough to get started.

**Full logistics 🔍** — for teams preparing a serious implementation, a fellowship deliverable, or a multi-phase campaign. Covers all sub-sections in depth including capacity assessment, external needs, budget breakdown, documentation plan, and monitoring with response protocols.

Ask the practitioner which track fits their situation before proceeding. If unsure, lean is the better default — it can always be expanded.

**On documentation:** This section captures the *plan* — what will be documented, how, and what metrics tracked during launch. The full processing and evaluation of that evidence belongs to Agent 05b.

---

## Lean Logistics Track ⚡

```
## Logistics (Lean)

**Timeline:**
- Development start: [date]
- Production complete: [date]
- Launch: [date/period]
- Evaluation begins: [date]

**Team:**
- Project lead: [name/role]
- Creative lead: [name/role]
- Key roles: [who does what — keep to essentials]
- Gaps: [what's missing]

**Budget:**
- Minimum viable: [amount + what it covers]
- Funding status: [secured / pending / still needed]

**Documentation baseline:**
- Before launch: [what to capture — state of narrative space, baseline metrics]
- During launch: [what to track — reach, engagement, qualitative responses]
- After launch: [what to collect — evidence of shift or response]

*For full logistics planning, use the Full Track below or work with Agent 05b.*
```

---

## Full Logistics Track 🔍

### 5.1 Timeline

```
**Development phase:**
- Start date: / Key milestones: / Decision points (go/no-go):

**Production phase:**
- Creation period: / Testing/iteration window: / Finalisation date:

**Launch phase:**
- Launch date/period: / Initial monitoring period: / Adjustment window:

**Sustained phase (if applicable):**
- Duration: / Rhythm: / Planned evolution:

**Evaluation phase:**
- Data collection period: / Analysis timeline: / Learning documentation:
```

### 5.2 Team

```
**Core team:**
- Project lead: [name/role — overall coordination]
- Creative lead: [name/role — artistic and messaging decisions]
- Production: [name/role — makes the thing]
- Distribution: [name/role — gets it to the audience]
- Documentation: [name/role — captures process and impact]
- Evaluation: [name/role — measures results]

**Capacity:**
- Total hours available (realistic): [estimate]
- Decision-making process: [how the team decides]
```

### 5.3 Capacities

```
**In-house:**
- Skills: [what the team can do]
- Tools/equipment: [what they have]
- Networks: [connections they can activate]
- Spaces: [places they have access to]

**External needs:**
- Skills/expertise gaps: [what's missing + who might provide]
- Resources needed: [materials, technology, space, distribution]
- Partners: [organisations, individuals, networks to involve]
- Procurement strategy: [in-kind / partnership / purchase — and timeline]
```

### 5.4 Budget

```
**Budget breakdown:**
- Personnel: $[amount]
- Production: $[amount]
- Distribution: $[amount]
- Documentation: $[amount]
- Contingency (10–20%): $[amount]
- **Total needed: $[amount]**

**Funding reality:**
- Minimum viable: $[amount] — [what this covers]
- Optimal: $[amount] — [what this covers]
- Currently secured: $[amount] — [source]
- Still needed: $[amount] — [plan to close gap]
```

### 5.5 Documentation Plan

```
**What to capture:**

Before launch (baseline):
- [Narrative space state — screenshots, data, media scan]
- [Audience baseline — how target audience currently talks about the issue]

During launch:
- [Reach metrics — platform analytics, attendance, coverage]
- [Engagement metrics — shares, responses, comments]
- [Qualitative signals — what people say and do in response]

After launch:
- [Sustained engagement — any continued spread or uptake]
- [Adoption signals — are target audiences using new language or frames?]
- [Unexpected responses — anything surprising]

**Tools and storage:**
- Digital tools: [platforms for capturing]
- Physical tools: [cameras, recorders]
- Storage: [where documentation lives + who has access]

*Full evaluation methodology and impact analysis: Agent 05b.*
```

### 5.6 Monitoring

```
**Real-time monitoring plan:**

What to track:
- Reach: [specific metrics + tools]
- Engagement: [specific metrics + tools]
- Qualitative feedback: [how collected — comments, DMs, in-person responses]

Monitoring schedule:
- Launch period: [frequency + focus]
- Sustained period: [frequency + focus]

Response protocols:
- If engagement lower than expected: [what you'll do]
- If negative response: [how you'll handle]
- If unexpected reach or virality: [how you'll capitalise]
- If safety issues arise: [response plan]

Adaptation triggers:
- What would cause an adjustment: [specific thresholds]
- Who decides: [decision-making process]
- What can change easily: [built-in flexibility]
```

---

## Prototyping Philosophy

Culture hacking is iterative by nature. The goal is not a perfect intervention — it is one that is good enough to launch and learn from. A hack that ships and produces unexpected results teaches more than one that never launches.

Before finalising the logistics plan, one question worth asking: *is there a small version of this hack we could test with a handful of people from the target audience before full launch?* Not a gate — a choice. Testing a meme in a conversation, running a version of the workshop with 10 people, or sharing the visual with a trusted community member costs little and can sharpen everything.

The philosophy: wax on, wax off. Each cycle teaches the next one.


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05a_Hack_Module.md

# KB: Hack Phase — Hacking Tree + Logistics
**Agent 05a · CHL AI Agent System**
*Load always — phase scope, key concepts, documentation questions, stand-alone mode, before/after.*

---

## What This Phase Is

Hack is the fifth phase of the Culture Hack Method. It is where the recoded narrative becomes a concrete cultural intervention — something that actually exists in the world and reaches an audience.

The phase works through two layers:

**The Hacking Tree** — four creative branches that translate the message into a cultural unit and design its delivery: Media (what format), Meme (what cultural unit), Tone (what emotions), and Hack (what space, scale, and moment).

**Logistics** — the practical plan that makes the hack real: timeline, team, capacities, budget, documentation, and monitoring.

**On creativity:** This phase is a co-creative moment. The agent helps brainstorm, structure, and sharpen — but the best hacks carry a human creative touch that no tool can produce alone. The practitioner should feel free to bring in artists, designers, or community members at any point in this phase. The Hacking Tree can serve as a creative brief handed to collaborators, or as a script for the practitioner's own creative process.

**On prototyping:** Culture hacking is iterative by nature. The goal is not a perfect intervention — it is a good-enough one that can be launched, learned from, and improved. A hack that ships and fails teaches more than one that never launches. Build in enough to start; the next cycle will sharpen it.

**Stand-alone use:** This phase can be used independently of the full cycle — for example, to design a campaign action, a workshop, or a one-off intervention. In stand-alone mode, the agent collects a light Audience Profile before proceeding. "The general public" is not a valid audience — the hack must be designed for specific people.

---

## Key Concepts

**The Hacking Tree**
The structured creative design of the intervention. Four branches, each with three sub-elements, each building on the previous. Together they answer: how does the message become an action in the world?

**Media**
The format and platform that carries the message to the audience. The best media is the one the audience already uses, understands, and shares — TikTok, hip hop, slam poetry, murals, food rituals, theatre, op-eds, billboards. Media choice is driven by audience habits, cultural ground, and the team's production capacity.

The Media branch has three sub-elements:
- **Audiences** — who specifically the hack reaches (one or more from Agent 04, or built in stand-alone mode)
- **Intersections** — the shared cultural ground between audience segments: the platforms they both use, the references they share, the aesthetic they both respond to. This is what makes a format choice strategic rather than arbitrary.
- **Format** — the specific medium chosen, with reasoning: why this format fits this audience, and whether the team can produce it

**Meme**
The message distilled into a simple cultural unit that can jump from mind to mind — something people can instantly grasp, share, and make their own. The meme is the vessel; the message from Agent 04 is the cargo. A hashtag, slogan, image, or gesture carries the full logic of the recoded narrative without stating it. That is the memetic power: the whole worldview travels inside a single shareable unit.

The Meme branch has three sub-elements:
- **Symbols** — existing cultural objects already in circulation that carry emotional or cultural weight for the audience
- **Associations** — remixing what those symbols mean: from their current association to the new one that activates the recoded frames
- **Synthesis** — the exact cultural unit: the hashtag, slogan, image, gesture, or phrase that carries the message in condensed, spreadable form

**Stickiness test (SUCCESs):** Simple · Unexpected · Concrete · Credible · Emotional · Story

**Tone**
The emotions evoked through the message and spread in the conversation. Just as films use sound, colour, and rhythm to shape feeling, the hack intentionally evokes specific sentiments. Tone is not decoration — it is strategy. Emotion leads to agency, not just feeling.

The Tone branch has three sub-elements:
- **Mood** — the current emotional climate of the narrative space and the target audience
- **Feelings** — the emotions the hack aims to generate, and the emotional journey from where the audience is now to where the hack wants to take them
- **Stimuli** — the specific creative tools (visual, sonic, linguistic, physical) that produce those feelings

Tone must be empowering and authentic. The test: does the emotion lead to action and agency, or does it trap people in feeling?

**Hack: Space, Scale, Moment**
The three dimensions of where, how big, and when:

- **Space** — where to intervene: physical public space, community space, virtual platform, institutional space, or hybrid. Space choice carries symbolic meaning. The Point of Intervention framework helps identify leverage: production, destruction, consumption, decision, assumption, or potential.
- **Scale** — the realistic reach: Micro (under 100), Meso (100–10,000), Macro (10k–1M), Mega (1M+). Scale must match the narrative ambition and the team's actual capacity.
- **Moment** — the political timing that maximises impact: planned timing, event-responsive timing (catching a crisis, movement surge, or cultural moment), or cyclical timing (commemorations, ecological cycles, political rhythms). The key question: is there a wave to catch?

**Logistics**
The practical infrastructure that lets the hack actually happen. Two tracks are available:
- **Lean logistics** — for teams that need speed: timeline essentials, roles, minimum budget, and a documentation baseline
- **Full logistics** — for teams that need depth: detailed timeline with phases, full team roles, capacity assessment, budget breakdown (minimum viable through optimal), documentation plan, and monitoring with response protocols

Logistics is a reality check: can the team actually do this? Ambition is good; overcommitment kills hacks. The logistics plan should be honest.

---

## Stand-alone Audience Profile (light)

When arriving without Agent 04 outputs, collect the following before starting the Hacking Tree:

**Essential (required):**
- Age, gender, location, political stance
- Narrative objective: what shift is being sought with this audience?

**Optional (deepen when relevant):**
- What do they hear about this issue?
- What do they see in daily life?
- What do they say about the topic?
- What do they think/feel (logics, values, feelings)?
- What do they do (actions related to the issue)?

"The general public" is not a valid audience. If the practitioner cannot describe their audience as specific people, the agent should help them narrow before proceeding.

---

## Documentation Questions

**On audience and media**
- Who exactly is the hack reaching? Are these the same audiences from Agent 04, or have they shifted?
- What do both/all audience segments have in common — platforms, aesthetics, cultural references, shared experiences?
- What format fits this audience and is within the team's real production capacity?

**On meme**
- What symbols are already active in the audience's world? Which carry emotional weight?
- What does the chosen symbol currently mean, and what do you want it to mean instead?
- What is the exact cultural unit — the hashtag, slogan, image, or gesture? Say it in one line.
- Does it pass the stickiness test: is it simple, unexpected, concrete, credible, emotional, story-like?

**On tone**
- What is the dominant emotional mood of the narrative space right now? What is your audience feeling?
- What feelings do you want to generate — and what is the journey from where they are to there?
- What specific creative tools (colours, rhythm, imagery, word register, music, physical movement) produce those feelings?
- Is the emotion empowering? Does it lead to agency?

**On space, scale, moment**
- Where are you intervening — and why does that space create leverage?
- What point of intervention is this: production, destruction, consumption, decision, assumption, or potential?
- What is the realistic scale — primary and secondary reach?
- Is there a wave to catch — a political crisis, movement surge, anniversary, or cultural moment? If so, when is it cresting?

**On logistics**
- What is the honest timeline from development through launch to evaluation?
- Who does what? Are there gaps in the team?
- What can the team do in-house? What needs to be sourced externally?
- What is the minimum viable budget — and what is secured?
- What needs to be documented before, during, and after — and how?

---

## What Comes Before / After

**Before:** Receives **Narrative Strategy + Recoded Narrative (with Message) + Audience Profile(s)** from Agent 04. The message, target audience, and strategy objectives are all direct inputs to the Hacking Tree design.

**After:** Passes the **Hacking Tree + Logistics Plan** to Agent 05b (Impact & Iteration). The full documentation package — baseline from Agents 02b and 03, narrative strategy from Agent 04, and the monitoring plan from this phase — travels with it.

**On iteration:** Hacks are iterative. Some things work and some don't. The logistics plan includes a documentation and monitoring layer precisely so that what is learned feeds the next cycle. After evaluation, the practitioner may return to Agent 02a to update the Listening Model, or to Agent 04 to revise the narrative strategy.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
