# FILE: KB_03_Understand_MapCheck.md

# KB: Map Check-in
**Agent 03 · CHL AI Agent System**
*Load only during the Map Check-in — after ANP analysis, before Language Analysis.*

---

## What the Map Check-in Is

The Map Check-in is the single co-creation moment in Agent 03. It happens after the ANP Assessment — when the evidence-based work is complete — and before Language Analysis, which is interpretive. This is the pivot point.

The practitioner reviews the draft community positioning on the Justice/Ontology map and either confirms it or adjusts it. Their direct community knowledge is the authority here — the AI-generated positioning is a starting point, not a verdict.

**Critical — Ontofake / Cooptation communities:**
Automated analysis is structurally biased toward misreading Ontofake communities as Catalytic or Justice + Onto-shift. Their language looks right. Their metaphors can look right. Only practitioner knowledge of actual practices, structural effects, and community context reveals the cooptation. During the Map Check-in, the agent should specifically flag any community it has placed in the upper right quadrant and ask: "Does this community's actual practice match its language — or could this be an Ontofake/Cooptation community that belongs in the upper left?" This question should always be asked, not left to the practitioner to raise.

The output of the Map Check-in is a **practitioner-reviewed JSON** that becomes the authoritative version of the Narrative Map. The final Community Analysis Report and Narrative Map both note: *"Map positioning reflects practitioner-reviewed analysis."*

---

## Two Pathways

Both pathways produce the same JSON output. The practitioner chooses based on their preference and context.

---

### Pathway 1 — Lite (Table + Mermaid)

**When to use:** Fast, text-based, works in any environment. Best for practitioners comfortable reading tables and numbers.

**Step 1 — Agent presents draft positioning**

The agent presents the draft map in two forms simultaneously:

*Editable table:*
```
| # | Community | Type | Justice (0–100) | Ontology (0–100) | Influence |
|---|---|---|---|---|---|
| 1 | [Name] | hegemonic | [value] | [value] | high |
| 2 | [Name] | catalytic | [value] | [value] | medium |
| 3 | [Name] | alternative | [value] | [value] | low |
```

*Axis reminder:*
- Justice: 0 = Injustice · 100 = Justice
- Ontology: 0 = Monoculture/Singular (bottom) · 100 = Onto-shift/Plural (top)
- Influence: high / medium / low (controls bubble size)

*Note: when you confirm values, the agent handles the mapper tool conversion automatically.*

*Mermaid render for spatial view:*
```
quadrantChart
    title Draft Narrative Map
    x-axis Injustice --> Justice
    y-axis Monoculture --> Onto-shift
    [Community name]: [justice/100], [ontology/100]
```

**Step 2 — Practitioner reviews**

The agent asks:
*"Does this positioning match your understanding of these communities? You can:*
- *Adjust any number — Justice or Ontology value*
- *Change a community's influence (high / medium / low)*
- *Change a community's type (hegemonic / catalytic / alternative)*
- *Rename a community*
- *Split a community into two*
- *Confirm as-is"*

**Step 3 — Practitioner responds**

Options:
- *"Looks right, proceed"* → agent generates final JSON and proceeds to Language Analysis
- *"Change community 2 to justice: 80"* → agent updates the table, re-renders Mermaid, asks for confirmation
- *"Community 3 should be two communities: X and Y"* → agent asks for positioning and type of each, updates table and Mermaid, confirms

**Step 4 — Agent generates final JSON**

Once confirmed, the agent produces the final Narrative Map JSON (see template in `KB_03_Understand_Actions.md`), states *"Map confirmed — proceeding to Language Analysis,"* and continues.

---

### Pathway 2 — Visual (CHL Narrative Mapper Tool)

**When to use:** When the practitioner wants to adjust community positions visually, drag-and-drop style. Requires access to the CHL Narrative Mapper tool.

**Step 1 — Agent produces draft JSON**

The agent produces a complete Narrative Map JSON using the confirmed schema:

```json
{
  "customTitle": "[Project name]",
  "communities": [
    {
      "name": "[Community name]",
      "justice": [value — 0=Injustice, 100=Justice],
      "ontology": [value — 0=Monoculture, 100=Onto-shift. Agent converts for current mapper tool automatically],
      "influence": "[high | medium | low]",
      "customSize": null,
      "description": "[description]",
      "communityType": "[hegemonic | catalytic | alternative]",
      "keyFrames": "[key frames from ANP analysis]",
      "color": "[hex]"
    }
  ],
  "windowOfDiscourse": null
}
```

*Note: `windowOfDiscourse` is left null at this stage — it will be populated after Window of Discourse analysis in Step 5.*

**Step 2 — Agent instructs the practitioner**

*"Here is the draft Narrative Map JSON. To review and adjust visually:*
1. *Open the CHL Narrative Mapper tool*
2. *Import this JSON file (or paste the JSON directly)*
3. *Drag communities to adjust positioning*
4. *Adjust bubble size using the influence setting (high / medium / low)*
5. *Change community type if needed*
6. *When satisfied, export the JSON*
7. *Paste the exported JSON back here"*

**Step 3 — Practitioner adjusts and exports**

The practitioner works in the mapper tool and pastes back the revised JSON.

**Step 4 — Agent receives revised JSON**

The agent reads the revised JSON, notes any changes from the draft, and confirms:
*"Received. Here are the changes you made: [list changes]. Does this look right?"*

Practitioner confirms → agent proceeds to Language Analysis using the revised positioning.

---

## Window of Discourse — Added After Step 5

After Window of Discourse analysis is complete (Step 5 in the main workflow), the agent adds the `windowOfDiscourse` rectangle to the JSON and presents it for confirmation:

*"Based on the Window of Discourse analysis, I'm proposing this rectangle position — it places mainstream discourse in the [quadrant description] area of the map. Does this match your assessment?"*

```json
"windowOfDiscourse": {
  "left": [X position],
  "top": [Y position],
  "width": [width],
  "height": [height]
}
```

If using the Visual pathway, the practitioner can import the updated JSON into the mapper tool to adjust the window rectangle directly, then export and return.

---

## What the Map Check-in Is Not

It is not a full re-opening of the analysis. ANP findings are not re-discussed here. The check-in is specifically about positioning, sizing, and typing — the spatial argument about where communities sit politically.

If the practitioner wants to substantially revise an ANP finding during the check-in, note it and revisit it in the Community Analysis Report — but do not restart the ANP process.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_03_Understand_Prompting.md

# KB: Prompting Guide — Understand Agent
**Agent 03 · CHL AI Agent System**
*Load when the practitioner is stuck or asks for prompt guidance.*

---

## How to Use This Guide

Agent 03 works best when given the complete Agent 02b package: Narrative Report, CSV Database, ANP Source Library, and completed Handoff Checklist. The more of the Handoff Checklist is answered, the faster and more accurately analysis proceeds.

---

## Starter Prompts

### Full Analysis — Complete 02b Package

Use this when you have everything from Agent 02b and are ready for full analysis.

> *"Here is my Agent 02b package: [attach/paste Narrative Report, ANP Source Library, and completed Handoff Checklist]. Run the full Understand analysis — ANP, map check-in, language analysis, Window of Discourse, and Strategic Insights / Narrative Intentions."*

---

### Full Analysis — Incomplete Handoff Checklist

Use this when some Handoff Checklist questions are unanswered but you want to proceed.

> *"Here is my Agent 02b package: [attach/paste]. The Handoff Checklist has some unanswered questions — I'll note them as gaps. Please flag where these gaps affect the analysis and proceed with what we have."*

---

### Learning Mode

Use this when you want to understand each analytical step as you go.

> *"Learning mode. Here is my Agent 02b package: [attach/paste]. Walk me through each analytical step — explain the reasoning behind ANP, community mapping, and language analysis before we proceed."*

---

### Iteration Mode

Use this when returning for a second or later cycle.

> *"Iteration mode. Here are my existing Community Profiles from Cycle 1: [attach/paste]. Here is my new Agent 02b package from Cycle 2: [attach/paste]. Update the profiles using [Updated] markers and produce a revised Community Analysis Report and Narrative Map."*

---

## Power Prompts

### Trigger the Map Check-in Explicitly

Use when you want to go straight to the map review — for example when you have an existing map and just want to update positioning.

> *"Skip to the Map Check-in. Here is the current community list with my initial positioning thoughts: [paste]. I want to use the [Lite / Visual] pathway."*

---

### Deeper ANP on a Specific Community

Use when the standard ANP feels thin for a particular community.

> *"The ANP assessment for [community name] feels thin. Can you go deeper on [Attention / Network / Power]? Are there additional Folio IDs in the ANP Source Library that should be included?"*

---

### Request More ANP Sources from Agent 02b Before Proceeding

Use when the ANP Source Library doesn't have enough for a specific community.

> *"The ANP Source Library only has [X] entries for [community name] and I don't think that's enough for a solid analysis. Before we proceed, I need to go back to Agent 02b and request more entries for this community. What should I ask for?"*

---

### Request the Visual Map Check-in Pathway

Use when you specifically want to use the CHL Narrative Mapper tool.

> *"For the Map Check-in, I want to use the Visual pathway — produce the JSON so I can import it into the CHL Narrative Mapper tool."*

---

### Request Language Analysis Only

Use when ANP is already done and you want to focus on frames and metaphors.

> *"The ANP is complete. Run Language Analysis only for these communities: [list]. Focus especially on [frames / metaphors / what is absent]."*

---

### Request Strategic Insights / Narrative Intentions Summary Only

Use when the full analysis is done and you want a focused brief for Agent 04.

> *"The Community Analysis Report is complete. Produce the Strategic Insights / Narrative Intentions section only — a focused analytical brief on what the analysis points toward for Agent 04."*

---

### Flag Insufficient Data

Use when you suspect the research base is too thin for reliable analysis.

> *"I'm concerned the data for [community name] is too thin. What would you need from Agent 02b before this community can be reliably analysed? Should I go back and request more sources?"*

---

## Prompt Tips

**Share the Handoff Checklist answers before starting.** Even partial answers make analysis significantly more accurate — especially on community identification and Big/Small Listening divergences.

**Choose your Map Check-in pathway before the session starts.** Lite (table) if you're comfortable with numbers and want speed. Visual (mapper tool) if you want to see the spatial picture and drag communities directly.

**Review Language Analysis before passing to Agent 04.** This is the interpretive layer — the agent's reading of frames and metaphors is a starting point, not a final verdict. Your community knowledge should shape this section.

**In iteration, be specific about what changed.** The more you tell the agent about what the hack revealed, the more precisely the `[Updated]` markers will reflect real change vs. stable patterns.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_03_Understand_Tools.md

# KB: Tools — Understand Agent
**Agent 03 · CHL AI Agent System**
*Load when the practitioner asks about tools, evidence use, or the mapper.*

---

## Agent 03 Has No Active Search Tools

Agent 03 is an analytical agent. Its primary inputs are the Agent 02b research package and practitioner knowledge. It does not run new searches. If the analysis reveals that the research base is insufficient — too few sources for a community, missing voices, critical gaps — the agent flags this and asks the practitioner to return to Agent 02b for more material before proceeding.

---

## Using the ANP Source Library

The ANP Source Library from Agent 02b is the evidence base for the ANP Assessment. Each entry has a Folio ID, a source, a platform, a date, a link, an extract, and a note on ANP relevance.

**How to use it:**
- For each ANP sub-lens (volume, reach, resonance, key nodes, etc.), identify which Source Library entries provide evidence
- Cite the Folio IDs in brackets after the claim: `[BL-H-003, BL-H-007]`
- If a claim cannot be supported by at least one Folio ID, either flag it as an unverified observation or return to Agent 02b for more sources

**When to request more sources:**
If a community has fewer than 5 entries in the ANP Source Library, or if the available entries only cover one dimension (e.g. all Attention, no Network or Power), the analysis will be thin. Request more entries from Agent 02b using this prompt:

> *"I need more ANP Source Library entries for [community name], specifically for [Attention / Network / Power]. Can you flag 5 more entries from the CSV for this community with ANP Source = Yes?"*

---

## When to Cite vs. When to Interpret

**Cite Folio IDs in:** ANP Assessment — every claim about volume, reach, key nodes, power levels. This is evidence-based work and must be auditable.

**Do not cite in:** Language Analysis, Community Mapping, Window of Discourse, Strategic Insights / Narrative Intentions. These sections involve interpretive judgment that goes beyond what individual sources can prove. They are grounded in the data but not reducible to it.

This distinction matters for practitioners reading the output: they know which parts are evidence-based and which require their own review and judgment.

---

## The `[Updated]` Marker System

In Iteration Mode, any field in a Community Profile that has changed from the previous cycle gets an `[Updated]` marker. Format:

```
[Updated — brief note on what changed and why, with Folio IDs from new cycle if applicable]
```

Example:
```
**Overall power level:** Medium [Updated — institutional power has grown since Cycle 1,
new policy involvement noted — BL-C2-H-008]
```

This creates a longitudinal record of how communities are shifting — which is evidence of narrative change over time and feeds directly into Agent 05b's impact evaluation.

Never silently overwrite previous analysis. If something changed, the `[Updated]` marker is how you show it.

---

## The CHL Narrative Mapper Tool

The CHL Narrative Mapper is a web-based tool that renders the Justice/Ontology map visually. It accepts JSON import and exports JSON. It allows practitioners to drag communities to adjust positioning, resize bubbles by changing influence, and place the Window of Discourse rectangle.

**JSON schema** (use exactly these field names):

```json
{
  "customTitle": "Project name",
  "communities": [
    {
      "name": "Community Name",
      "justice": 0-100,
      "ontology": 0-100,
      "influence": "high | medium | low",
      "customSize": null,
      "description": "1-2 sentence description",
      "communityType": "hegemonic | catalytic | alternative",
      "keyFrames": "key frames comma separated",
      "color": "#hex"
    }
  ],
  "windowOfDiscourse": {
    "left": 0-100,
    "top": 0-100,
    "width": 0-100,
    "height": 0-100
  }
}
```

**Critical: axis convention and mapper tool conversion**
The agent uses the **intuitive axis convention**: ontology 100 = top of map = Onto-shift/Plural. This is what the agent produces analytically and what gets stored in the Community Analysis Report.

However, the **current mapper tool** uses an inverted ontology axis (high value renders at bottom). Until the tool is updated, apply this conversion when generating JSON for export to the current mapper:

`mapper_ontology = 100 - ontology`

Example: a community analysed at ontology = 72 (genuinely plural, upper half) exports as mapper_ontology = 28 to render correctly in the current tool.

When the practitioner returns an exported JSON from the mapper tool, reverse the conversion before storing analytical values: `ontology = 100 - mapper_ontology`.

**Quadrant reference (intuitive convention — use this for analysis):**

| Quadrant | Justice | Ontology |
|---|---|---|
| Justice + Onto-shift (UR) | > 50 | > 50 |
| Injustice + Ontofake (UL) | < 50 | > 50 |
| Justice + Reform (LR) | > 50 | < 50 |
| Injustice + Monoculture (LL) | < 50 | < 50 |

**Default colors by community type:**
- Hegemonic: `#e74c3c` (red)
- Catalytic: `#27ae60` (green)
- Alternative: `#f39c12` (orange)
- Override with any hex if a community needs a different color for clarity

**windowOfDiscourse positioning:**
- `left` and `top` use the same coordinate system as communities
- `width` and `height` are percentages of the full map area
- A typical Window of Discourse rectangle covers 30–50% of the map area
- Position it to reflect where mainstream/acceptable discourse currently sits

---

**Mermaid for the Lite Pathway**

When the mapper tool is not available, use a Mermaid quadrant chart for the visual layer.

```
quadrantChart
    title Narrative Map — [Project Name]
    x-axis Injustice --> Justice
    y-axis Monoculture --> Onto-shift
    Community Name: [justice/100], [ontology/100]
```

The Mermaid y-axis matches the intuitive convention — no conversion needed. Plot directly as `justice/100` and `ontology/100`.

---

## When to Flag Insufficient Data

Flag and pause analysis when:
- A community has fewer than 3 entries in the ANP Source Library
- All entries for a community are from a single source or platform
- The community was identified in Big Listening only with no Small Listening grounding and the Handoff Checklist flags this as a concern
- The practitioner expresses uncertainty about whether a community is real or an artefact of search parameters

In these cases: name the gap, describe what additional research would be needed, and ask whether to proceed with caveats or return to Agent 02b first.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
