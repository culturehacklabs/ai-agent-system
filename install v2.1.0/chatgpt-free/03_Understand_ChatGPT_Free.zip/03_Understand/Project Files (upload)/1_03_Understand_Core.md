# FILE: KB_03_Understand_Actions.md

# KB: Actions — Understand Phase Output Templates
**Agent 03 · CHL AI Agent System**
*Load when producing any output: Community Analysis Report or Narrative Map.*

---

## Output A — Community Analysis Report

One flowing document covering all four analytical layers. Produced after the Map Check-in is complete.

```
# Community Analysis Report
## [Project Name / Pathway]

**POV (Short):** [restated from Agent 01]
**Research basis:** Narrative Report + ANP Source Library from Agent 02b
**Date:** [date produced]
**Communities analysed:** [number]

---

## 1. Community Profiles

*Initial community identifications from Agent 02b have been confirmed and reviewed
with the practitioner. Profiles below reflect the agreed community picture.*

### Community [#]: [Name]

**Description:** [1–2 sentences — what this community is]
**Community Type:** Hegemonic / Alternative / Catalytic
*[If this community uses progressive or pluralistic language while its practices
reinforce systems of oppression, note: "Positioned Injustice + Ontofake —
see Language Analysis for discourse/practice gap analysis"]*

**Core Narrative:**
[The central story this community tells — how it explains the issue,
its causes, and its solutions. What worldview does this narrative assume?]

**Key Actors:** [organisations, individuals, publications, platforms]

**Language Patterns:**
- Vocabulary: [specific recurring terms and keywords]
- Slogans / Hashtags: [if applicable]

**Platform Presence:** [where most active, geographic spread]

[Repeat for each community — 3 to 5 total]

---

## 2. ANP Assessment

*This section is evidence-based. All claims cite Folio IDs from the ANP Source Library.*

### [Community Name] — ANP Assessment

**Attention**
- Content volume: [frequency of narrative production — High / Medium / Low] [Folio IDs]
- Reach: [how far narratives travel beyond the community] [Folio IDs]
- Resonance: [which themes generate most activity] [Folio IDs]
- Temporal pattern: [growing / stable / declining over the research period] [Folio IDs]
- Comparative: [how this community's attention compares to others in the space]

**Network**
- Key nodes: [most central actors or organisations] [Folio IDs]
- Density: [tight / loose internal connections]
- Topology: [centralised / decentralised / distributed]
- Bridge actors: [who moves between this community and others — strategic note] [Folio IDs]
- Information flow: [how ideas spread within and beyond this community]

**Power**
- Institutional power: [media access, economic resources, policy influence — High / Medium / Low] [Folio IDs]
- Cultural power: [legitimacy, credibility, whose framing is treated as common sense] [Folio IDs]
- Network power: [coalition capacity, mobilisation ability] [Folio IDs]
- **Overall power level:** High / Medium / Low — [reasoning]

[Repeat ANP Assessment for each community]

**Cross-community observations:**
- Bridge actors identified: [actors who appear across multiple communities]
- Power differential: [which community dominates, which is marginalised]
- Network connections: [where communities are linked, where they are isolated]

---

## 3. Language Analysis

*The following analysis is interpretive — it draws on research data and practitioner
knowledge but involves analytical judgment. The practitioner should review this
section before passing to Agent 04.*

### [Community Name] — Language Analysis

**Frames:**
- Inside the frame: [what is included, made visible, centred — what this community talks about]
- Outside the frame: [what is excluded, made invisible, dismissed — what doesn't get said]
- How common sense is constructed: [the underlying logic — what makes this community's view feel natural, inevitable, or acceptable. What assumptions must already be held for this narrative to make sense?]
- Ideological logic: [the worldview tying frames together — what larger belief system this serves, what future it implies, what it protects]

**Dominant Metaphors:**
- [Metaphor 1]: [what it maps — source domain → target domain. What does this metaphor make thinkable? What does it foreclose?]
- [Metaphor 2]: [same structure]
[Be specific — use actual language from the research, not generic descriptions]

**What is absent:**
[What topics, actors, or perspectives never appear in this community's discourse.
What would feel strange or inappropriate to say here. What is treated as unthinkable.]

**Discourse / Practice gap** *(include only for communities positioned Injustice + Ontofake):*
[What does this community say versus what does it structurally do?
Who benefits from the narrative it produces?
Does the language of change function to absorb dissent rather than enable transformation?
What practices or structures remain intact despite the progressive framing?]

[Repeat Language Analysis for each community]

---

## 4. Window of Discourse

**Current positions:**

*Mainstream/Acceptable:*
[Which narratives are dominant and treated as common sense.
Which communities maintain them. What frames define the centre of public debate.]

*Emerging/Contested:*
[Which narratives are gaining traction but not yet mainstream.
Who is pushing them. What would tip them into mainstream.]

*Radical/Unacceptable:*
[Which narratives are currently marginalised or treated as extreme.
Who holds them. What would bring them into the Emerging position.]

**Position of the desired reframe:**
[Where does the narrative change the POV points toward currently sit —
Mainstream / Emerging / Radical? Why?]

**Catalytic communities and window movement:**
[Which Catalytic communities are already pushing in the desired direction.
What would amplify their impact. Are there moments, movements, or crises
that could accelerate window movement?]

**Window of Discourse coordinates (for Narrative Map):**
- left: [X position of window's left edge, 0–100]
- top: [Y position of window's top edge, 0–100 — 100 = Onto-shift, top of map]
- width: [width as % of map]
- height: [height as % of map]
*[Reasoning: which part of the Justice/Ontology map does mainstream discourse
currently occupy?]*

---

## 5. Strategic Insights + Narrative Intentions

*Strategic Insights describe what the analysis observes about the narrative space.
Narrative Intentions are possible directions that emerge from those insights — options,
not commitments. Agent 04 turns Narrative Intentions into Narrative Objectives:
the committed strategic plan.*

**Communities with movement potential:**
[Which communities show potential for shift toward Justice + Onto-shift, and why.
What would need to happen for movement to occur. What the analysis suggests
about realistic vs aspirational movement.]

**Frame openings:**
[Where are the contradictions, tensions, or unresolved questions in existing frames
that a reframe could work through? Which frames are most amenable to recoding?
Which currently-circulating alternative frames could be amplified?]

**Bridge opportunities:**
[Which bridge actors or community connections could be activated.
Where are communities close enough on the map that connection seems possible.]

**Window leverage:**
[What the Window of Discourse analysis suggests about timing and approach.
What is close to the edge of acceptable. What early signals of movement are visible.]

**Acupuncture Points:**
[Specific communities, actors, moments, or connections where a targeted culture hack
could have disproportionate impact — small pressure, significant shift.
Each Acupuncture Point should be named specifically: which community, what kind of
intervention, why this is the right pressure point in the system right now.
These are the most concrete and actionable outputs of this section.]

**Narrative Intentions — possible directions for Agent 04:**
[Options emerging from the analysis — possible communities to engage, frames to
challenge or amplify, directions of movement to pursue. Presented as options,
not decisions. Agent 04 selects and commits.]

**Gaps and risks:**
[What the analysis doesn't yet answer. What risks the strategy should account for.
Where the data is thin and more listening may be needed before strategy.]
```

---

## Output B — Narrative Map

Kept as a separate document. Three components: JSON (for the CHL Narrative Mapper tool), Mermaid (lightweight visual render), and summary table.

### Component 1 — Narrative Map JSON

```json
{
  "customTitle": "[Project name]",
  "communities": [
    {
      "name": "[Community name]",
      "justice": [0–100 float — 0=Injustice, 100=Justice],
      "ontology": [0–100 float — 0=Monoculture/Singular, 100=Onto-shift/Plural],
      "influence": "[high | medium | low]",
      "customSize": null,
      "description": "[1–2 sentence description]",
      "communityType": "[hegemonic | catalytic | alternative]",
      "keyFrames": "[2–3 key frames, comma separated]",
      "color": "[hex — defaults: hegemonic #e74c3c, catalytic #27ae60, alternative #f39c12]"
    }
  ],
  "windowOfDiscourse": {
    "left": [X position of left edge, 0–100],
    "top": [Y position of top edge, 0–100],
    "width": [width as % of map],
    "height": [height as % of map]
  }
}
```

**⚠️ Mapper tool conversion:** Until the mapper tool is updated to match the intuitive axis convention, apply this conversion when exporting JSON for the current tool: `mapper_ontology = 100 - ontology`. Keep your analytical values intuitive (100 = Onto-shift) and convert only for the JSON. See `KB_03_Understand_Tools.md`.

**Axis reference — intuitive convention:**
- justice 0–50 = Injustice side · justice 50–100 = Justice side
- ontology 0–50 = lower half (Monoculture / Reform) · ontology 50–100 = upper half (Onto-shift / Ontofake)
- Upper Right (Justice + Onto-shift): justice > 50, ontology > 50
- Upper Left (Injustice + Ontofake): justice < 50, ontology > 50
- Lower Right (Justice + Reform): justice > 50, ontology < 50
- Lower Left (Injustice + Monoculture): justice < 50, ontology < 50

*To use this JSON: paste into the CHL Narrative Mapper tool (with conversion applied). The tool renders the map visually and allows further adjustment. Export the revised JSON and paste back — remember to reverse the conversion on import.*

---

### Component 2 — Mermaid Render

A lightweight text-based visual. Use when the mapper tool is not available or for quick reference.

```
quadrantChart
    title Narrative Map — [Project Name]
    x-axis Injustice --> Justice
    y-axis Monoculture --> Onto-shift
    [Community Name]: [justice/100], [ontology/100]
```

*Mermaid y-axis matches the intuitive convention — no conversion needed. Plot directly as justice/100 and ontology/100.*

*If the platform does not render Mermaid in chat (e.g. ChatGPT), still provide the Mermaid code block. If a code-execution tool is available (e.g. ChatGPT Code Interpreter), also plot the same values as a labelled scatter chart: x = justice, y = ontology, both 0–100 with no conversion, quadrant lines at 50, community names as point labels.*

---

### Component 3 — Summary Table

```
## Community Map Summary

| Community | Type | Quadrant | Justice | Ontology | Influence | Strategic Potential |
|---|---|---|---|---|---|---|
| [Name] | [type] | [UR/UL/LR/LL] | [value] | [value] | [H/M/L] | [brief note] |

**Clusters:** [which communities group together and what that means]
**Distances:** [which communities are far apart — tensions or opportunities]
**Gaps:** [empty spaces in the map — what is absent]
**Window of Discourse:** [which communities and narratives sit inside the current window]
**Leverage points:** [where intervention could create movement]
```

---

## Iteration — Output Markers

In a second or later cycle, use `[Updated]` markers to show what changed. Example:

```
**Attention:** High [Updated — reach increased significantly after the hack period,
new actors entering the conversation — BL-C2-H-004]
```

For communities that were split from a previous cycle, add a note:

```
*[Split from "Community X" in Cycle 2 — the hack revealed this was two distinct
communities with different frames and positions. See Cycle 1 profiles for original.]*
```

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_03_Understand_Module.md

# KB: Understand Phase — Narrative Communities + Mapper
**Agent 03 · CHL AI Agent System**
*Load always — phase theory, analytical sequence, key concepts, and iteration workflow.*

---

## What This Phase Is

Understand is the third phase of the Culture Hack Method. It transforms the research package from Agent 02b into strategic intelligence about the narrative space.

The phase applies four analytical tools in sequence:

1. **ANP Analysis** — Attention, Network, Power: evidence-based assessment of each community's presence and position in the narrative space, grounded in the ANP Source Library from Agent 02b
2. **Language Analysis** — Frames, metaphors, and ideological logic: the cognitive architecture that organises how each community makes sense of the issue
3. **Community Mapping** — Positioning communities on the Justice/Ontology axes, reviewed and confirmed by the practitioner through the Map Check-in
4. **Window of Discourse** — Identifying which narratives are mainstream, emerging, or marginalised, and where intervention can shift the window

Together these produce the **Community Analysis Report** and the **Narrative Map** — the strategic foundation that Agent 04 builds its strategy on.

---

## What Arrives from Agent 02b

Before beginning analysis, confirm these four inputs are present:

- **Narrative Report** — the landscape summary with community first drafts, patterns, and Folio ID citations
- **CSV Database** — the full source dataset with 13 columns including Folio IDs and ANP Source flags
- **ANP Source Library** — 5+ sourced extracts per community, drawn from the CSV, ready for ANP analysis
- **Handoff Checklist** — 4–6 specific questions from Agent 02b about gaps, divergences, and unclear communities

**Step 0 — Handoff Checklist check:**
Review the Handoff Checklist before starting any analysis. If critical questions are unanswered — particularly about community identification, Big/Small Listening divergences, or missing voices — surface them to the practitioner and resolve before proceeding. Minor gaps can be noted and carried forward into the analysis.

---

## Key Concepts

**Narrative Community**
A group of actors persistently engaged in conversation about a specific topic over time, using shared language, frames, and belief systems. Three types:
- **Hegemonic** — reinforces dominant narratives and existing power structures
- **Alternative** — proposes different stories; exists at the fringes of mainstream
- **Catalytic** — has high potential to drive broader narrative shifts and bridge communities

Note on Cooptation: communities that perform progressive or pluralistic language while their actual practices reinforce systems of oppression are typed as `alternative` in the mapper tool but positioned in the **Injustice + Ontofake** quadrant. They are not a fourth community type — they are a specific and dangerous configuration that requires practitioner knowledge to identify correctly. Automated analysis will almost always misread them as Catalytic or Justice + Onto-shift. See the critical Ontofake note in the Justice/Ontology Map section below.

**ANP Analysis**
Three criteria for assessing narrative communities. Each has a deep-dive structure:

*Attention — volume, reach, and resonance:*
- Content volume: frequency of narrative production over the research timeframe
- Reach: how far narratives travel beyond the immediate community
- Resonance: which themes generate the most activity and sharing
- Temporal patterns: is the community's narrative growing, declining, or stable?
- Comparative: how does this community's attention level compare to others in the space?

*Network — social structure:*
- Key nodes: which actors or organisations are most central
- Density: how tightly connected is the community internally
- Topology: centralised (hub-and-spoke), decentralised (multiple centres), or distributed (flat)
- Bridge actors: who moves between this community and others — these are strategically important
- Information flow: how do ideas spread within and beyond this community

*Power — influence and centrality:*
- Institutional power: media access, economic resources, policy influence
- Cultural power: legitimacy, credibility, symbolic authority — whose framing is treated as common sense
- Network power: coalition capacity, mobilisation ability, ability to bring others into alignment
- Overall power level: High / Medium / Low — with reasoning

Communities with the most attention and network interactions over time have the most power. Power is relative — assess it in comparison to other communities in this space.

**Folio IDs in ANP Analysis**
The ANP Assessment is the evidence-based layer of the analysis. Every claim must cite the Folio IDs from the ANP Source Library that support it. Example: "This community has high institutional power, with consistent placement in mainstream media outlets [BL-H-003, BL-H-007]."

**Language Analysis — Frames and Metaphors**
Systematic analysis of the cognitive architecture of each community's narrative. This is interpretive work — it draws on the research data and practitioner knowledge but involves analytical judgment that goes beyond what can be sourced. Folio IDs are not required in this section.

Three frame questions:
1. *What is inside the frame?* — what is included, made visible, centred
2. *What is outside the frame?* — what is excluded, made invisible, dismissed
3. *How is what's inside constructed?* — how common sense is created; what makes certain ideas feel natural, inevitable, or acceptable, and others unthinkable

Alongside frames, identify:
- **Dominant metaphors** — conceptual mappings that ground abstract ideas in familiar experiences. What does the metaphor make thinkable? What does it foreclose? (e.g. "the economy is a machine" enables efficiency-thinking but disables care-thinking)
- **Ideological logic** — the worldview tying frames together into a coherent system with internal justification

What is absent in the discourse often says more than what is present.

**Justice/Ontology Map**
A two-axis map for positioning narrative communities:
- **Justice axis (X, 0–100):** 0 = Injustice/Individual/Reform end · 100 = Justice/Systemic/Transformative end
- **Ontology axis (Y, 0–100):** 0 = Monoculture/Singular ways of knowing · 100 = Onto-shift/Plural ways of knowing. High = more plural, top of map. Low = more singular, bottom of map.

**Note for the mapper tool:** The current mapper tool inverts the ontology axis (high value = bottom). A tool update is required to match this intuitive convention. Until updated, use the conversion in `KB_03_Understand_Tools.md` when generating JSON coordinates.

Four quadrants:
- **Upper Right (Justice + Onto-shift):** justice > 50, ontology > 50 — systems change + plural ways of knowing. Target direction for culture change.
- **Upper Left (Injustice + Ontofake):** justice < 50, ontology > 50 — structural oppression performing plural/change language. See critical note below.
- **Lower Right (Justice + Reform):** justice > 50, ontology < 50 — structural change through conventional knowledge
- **Lower Left (Injustice + Monoculture):** justice < 50, ontology < 50 — oppression + singular ways of knowing

The axes can be adapted to fit the POV's specific goals — the framework is a tool, not a fixed grid.

**Critical note — Injustice + Ontofake quadrant:**
This is the trickiest quadrant in the map. Ontofake communities use the language of ontological shift — plurality, relationality, Indigenous epistemology, care — while their actual practices and structures keep systems of oppression intact. Cooptation is the mechanism: progressive discourse absorbs and neutralises challenge rather than enabling it.

Automated analysis is structurally biased toward misreading Ontofake communities as Catalytic or Justice + Onto-shift — because the language looks right and the metaphors can look right. Only practitioner knowledge of actual practices, structural effects, and community context reveals the cooptation. This is why the Map Check-in is a co-creation moment, not an automated output.

When analysing a suspected Ontofake community in Language Analysis, apply a specific additional lens: **the gap between discourse and practice.** Ask: What does this community say versus what does it structurally do? Who benefits from the narrative it produces? Does the language of change function to absorb and neutralise dissent rather than enable transformation? Does progressive framing serve to maintain existing power arrangements?

**Acupuncture Points**
Specific communities, actors, moments, or connections in the narrative space where a targeted culture hack could have disproportionate impact — small pressure, significant shift. Named by analogy to acupuncture: the right intervention at the right point in the system produces effects beyond what the scale of the intervention would suggest. Acupuncture Points emerge from the intersection of the ANP analysis (where is there network bridging capacity?), the Language Analysis (where are the frame contradictions or openings?), and the Window of Discourse (what is close to tipping?). They are the most specific and actionable outputs of the Strategic Insights section.

**Window of Discourse**
The Window of Discourse is the range of narratives treated as acceptable in public debate at a given moment. Positioning the narrative space against it shows what is currently common sense, what is gaining ground, and what remains marginal. Three positions:
- **Mainstream/Acceptable** — dominant, treated as common sense
- **Emerging/Contested** — gaining traction, not yet mainstream
- **Radical/Unacceptable** — marginalised, treated as extreme or unthinkable

The window is represented on the Narrative Map as a draggable rectangle with coordinates:
- `left`: X position of the window's left edge (0–100, same as justice axis)
- `top`: Y position of the window's top edge (0–100, same ontology axis — 100 = Onto-shift, top of map)
- `width` and `height`: size of the window as percentage of map

The window is always moving. Social movements, cultural moments, and political crises shift what sits inside or outside it. Identifying where the practitioner's desired reframe currently sits — and what would move the window — is the strategic conclusion of this phase.

---

## The Analytical Sequence

### Step 1 — Confirm Community First Drafts

From the Narrative Report, confirm the community first drafts from Agent 02b. For each community, review:
- Name and description
- Initial type (Hegemonic / Alternative / Catalytic)
- Whether the practitioner agrees with the initial identification

Adjust names, descriptions, or types as needed. If the practitioner identifies that a community is more complex than initially mapped — for example, two distinct sub-communities were grouped together — split it here before proceeding. 3–5 communities is the working range.

### Step 2 — ANP Analysis

For each community, work through the full deep-dive structure. Use the ANP Source Library entries as evidence — cite Folio IDs. Produce an ANP Assessment for each community covering all three dimensions with sub-lenses. Compare communities relatively: which has most attention, most power, most bridging capacity?

Bridge actors are particularly important — identify any actors who appear in multiple communities or move between them. These are strategic nodes for the Recode phase.

### Step 3 — Map Check-in

After ANP, before Language Analysis. This is the single co-creation moment in Agent 03. Load `KB_03_Understand_MapCheck.md`. Present the draft positioning, invite the practitioner to review and adjust. Proceed only after confirmation.

The Map Check-in is the pivot between evidence-based work (ANP) and interpretive work (Language Analysis). The positioning confirmed here feeds directly into the final Narrative Map JSON.

### Step 4 — Language Analysis

For each community, apply the three frame questions. Identify dominant metaphors and what they make thinkable or foreclose. Identify the ideological logic. Note what is absent — what the community doesn't say, what would feel out of place, what is treated as unthinkable.

For any community positioned in the **Injustice + Ontofake** quadrant, apply an additional lens: the gap between discourse and practice. Ask: What does this community say versus what does it structurally do? Who benefits from the narrative it produces? Does the language of change function to absorb and neutralise dissent rather than enable transformation?

*Note at the start of this section in the output: "The following analysis is interpretive — it draws on research data and practitioner knowledge but involves analytical judgment. The practitioner should review this section before passing to Agent 04."*

### Step 5 — Window of Discourse

Assess the current narrative space as a whole. Where does the dominant narrative sit? Where does the practitioner's desired reframe currently sit — Mainstream, Emerging, or Radical? What would move the window? Identify the Catalytic communities already pushing in the desired direction.

Determine the Window of Discourse rectangle coordinates for the Narrative Map — where does mainstream discourse currently sit on the Justice/Ontology axes?

### Step 6 — Strategic Insights + Narrative Intentions

Surface what the analysis points toward. Two layers: Strategic Insights (observations about the narrative space — what is possible, where frame openings exist, where Acupuncture Points are) and Narrative Intentions (options for Agent 04 — possible communities, frames, directions). See the Strategic Insights + Narrative Intentions section below for full guidance.

---

## Strategic Insights + Narrative Intentions

At the end of the Community Analysis Report, surface what the analysis points toward. This section has two layers:

**Strategic Insights** — what the analysis observes about the narrative space: where movement is possible, where frame openings exist, where the window is close to shifting, where Acupuncture Points are located. These are analytical observations, not decisions.

**Narrative Intentions** — possible directions that emerge from the insights: options for which communities to engage, which frames to challenge or amplify, what kind of movement to pursue. These are options, not commitments. Agent 04 turns Narrative Intentions into Narrative Objectives — the committed strategic plan.

The distinction matters: Strategic Insights describe the landscape. Narrative Intentions describe possible moves within it. Narrative Objectives are the decisions made. Agent 03 produces the first two. Agent 04 produces the third.

---

## Iteration Workflow

In a second or later cycle, existing Community Profiles are updated — not rebuilt from scratch.

**What stays stable:**
- Community names (unless the hack revealed a naming problem)
- The basic analytical structure of each profile

**What gets updated:**
- ANP data: new research cycle, new Folio IDs, updated reach/power/network assessment
- Language patterns: new frames or metaphors that emerged during or after the hack
- Justice/Ontology positioning: has any community shifted? Document movement as evidence of change
- Window of Discourse: has the window moved? What is now Emerging that was Radical?
- Community type: has any community shifted from Alternative to Catalytic, or gained/lost influence?

**`[Updated]` markers:**
Any field that changed from the previous cycle gets an `[Updated]` tag with a brief note on what changed and why. Example: `**Attention:** High [Updated — reach increased significantly after the hack period, new actors entering the conversation — BL-C2-H-004]`

**Split communities:**
If the hack revealed that a community is more complex than initially mapped — for example, two distinct sub-communities with different frames and positions — split it into more specific communities that better reflect what was learned. Document the split with a note explaining why.

---

## What Comes Before / After

**Before:** Receives **Narrative Report + CSV Database + ANP Source Library + Handoff Checklist** from Agent 02b.

**After:** Passes **Community Analysis Report + Narrative Map** to Agent 04 (Recode), which uses them to set Narrative Objectives and build the reframe strategy.

**Note on the boundary with Agent 04:** Agent 03 produces analytical observations and surfaces Strategic Insights / Narrative Intentions. Agent 04 sets Narrative Objectives — which communities to target, which frames to challenge/strengthen/introduce, what direction of movement to pursue. This boundary matters: analysis should not be presented as strategy.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
