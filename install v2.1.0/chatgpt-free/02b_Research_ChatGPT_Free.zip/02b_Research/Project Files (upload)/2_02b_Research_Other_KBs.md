# FILE: KB_02b_Research_MultiInquiry.md

# KB: Multi-Inquiry Mode
**Agent 02b · CHL AI Agent System**
*Load only when Multi-Inquiry Mode is activated — two or more Big Listening Inquiries provided.*

---

## What Multi-Inquiry Mode Does

Multi-Inquiry Mode runs two or more Big Listening Inquiries in sequence and combines the findings into a single Narrative Report. Each inquiry gets its own section in the report. A cross-inquiry synthesis at the top identifies patterns, shared communities, and tensions that cut across all inquiries.

This mode is most useful when:
- Multiple fellows or practitioners on the same Pathway need research run together
- A project has distinct sub-questions that each require their own parameter set
- A grouped pathway research session covers several related narrative spaces at once

---

## Folio ID Convention in Multi-Inquiry Mode

Each inquiry is assigned a short tag that becomes part of the Folio ID. This keeps entries attributable across the combined CSV.

**Format:** `[Listening Mode]-[Inquiry Tag]-[Community Initial]-[Number]`

Examples:
- `BL-P1-H-001` — Big Listening, Pathway Inquiry 1, Hegemonic community, entry 1
- `BL-P2-A-003` — Big Listening, Pathway Inquiry 2, Alternative community, entry 3
- `SL-P1-C-002` — Small Listening, Pathway Inquiry 1, Catalytic community, entry 2

When an entry is relevant to more than one inquiry, it appears in the CSV once with a note in the Inquiry Tag column listing all relevant inquiries (e.g. `P1, P2`). It is cited in both relevant sections of the Narrative Report.

---

## Workflow

**Step 1 — Receive and confirm all inquiries**
Take in all Big Listening Inquiries. Assign a short tag to each (P1, P2, P3 — or named tags if the practitioner prefers, e.g. `BCG`, `EoR`). Confirm each inquiry's parameters before beginning. If any are underspecified, ask before proceeding.

**Step 2 — Run inquiries in sequence**
Run each inquiry separately using the deep web search and synthesis tools. Build the CSV continuously — each entry tagged to its inquiry. Assign Folio IDs as entries are retrieved.

After each inquiry, do a brief check: are there communities, actors, or themes appearing across multiple inquiries? Note these as cross-inquiry overlaps for the synthesis section.

**Step 3 — Identify communities per inquiry**
Produce a community first draft for each inquiry separately. Some communities may appear across inquiries — if so, note them as shared communities and describe them once in the cross-inquiry synthesis rather than repeating separately in each section.

**Step 4 — Select ANP Source Library entries**
Flag 5 entries per community per inquiry as `ANP Source = Yes`. For shared communities that appear across inquiries, flag 5 entries per inquiry they appear in — the practitioner or Agent 03 can decide how to consolidate.

**Step 5 — Produce the combined Narrative Report**

See the template below. Structure is:
1. Cross-Inquiry Synthesis (top)
2. Inquiry sections (one per inquiry, each with full Narrative Report structure)
3. Combined Sources
4. Handoff Checklist (covers all inquiries)

**Step 6 — Produce a single combined CSV**
All entries from all inquiries in one CSV, distinguished by Inquiry Tag column. This is the baseline for the full research session — Agent 03 receives one CSV covering all inquiries.

**Step 7 — Produce ANP Source Library per inquiry**
Each inquiry gets its own ANP Source Library section. Shared communities are noted across sections with cross-references.

---

## Combined Narrative Report Template

```
# Narrative Report — Multi-Inquiry
## [Project Name / Pathway]

**Inquiries covered:** [number] — [Inquiry 1 name / tag] · [Inquiry 2 name / tag] · [etc.]
**Total CSV entries:** [number] · **Report date:** [date]

---

## Cross-Inquiry Synthesis

[2–3 paragraphs identifying what cuts across all inquiries:
- Shared narrative communities appearing in multiple inquiry spaces
- Recurring language, actors, or dynamics across the inquiries
- Key tensions or connections between the different narrative spaces
- What the inquiries together reveal that no single inquiry shows alone
Every claim cites Folio IDs.]

**Shared communities identified:**
- [Community name] — appears across [Inquiry tags] — [brief note on how it shows up differently across spaces]

---

## Inquiry 1: [Name / Tag]

**Research Question:** [restated]
**Timeframe:** [period] · **Platforms / Geography:** [scope]

### 1.1 Narrative Landscape Summary
[Full landscape summary for this inquiry — Folio IDs throughout]

### 1.2 Narrative Patterns Timeline
[Timeline for this inquiry's narrative space]

### 1.3 Identified Narrative Communities — First Draft
[Community first drafts for this inquiry]

### 1.4 Key Narrative Dynamics
[Dynamics specific to this inquiry's space]

### 1.5 Big Listening / Small Listening Integration
[If applicable]

---

## Inquiry 2: [Name / Tag]

[Repeat full structure]

---

[Add sections for each additional inquiry]

---

## Combined Sources

**Total entries across all inquiries:** [number]
**Entries cited in this report:** [number]
**ANP Source Library entries:** [number]

| Folio ID | Inquiry | Actor / Source | Platform | Date | Link |
|---|---|---|---|---|---|
| [BL-P1-H-001] | P1 | [source] | [platform] | [date] | [URL] |
[Continue for all cited entries]

---

## Handoff Checklist for Agent 03

*Questions from all inquiries — practitioner answers what they can before passing to Agent 03.*

**Cross-inquiry questions:**
1. [Question about a shared community or cross-inquiry dynamic]
   **Answer:**

**Inquiry 1 — [Name]:**
2. [Specific question from this inquiry's research]
   **Answer:**

**Inquiry 2 — [Name]:**
3. [Specific question from this inquiry's research]
   **Answer:**

[Continue — up to 6 questions total across all inquiries]
```

---

## When to Keep Inquiries Separate

If two inquiries are about completely different narrative spaces with no shared actors, communities, or dynamics — and combining them produces no useful synthesis — it may be cleaner to produce separate Narrative Reports. In that case, exit Multi-Inquiry Mode and run each inquiry as a standard single-inquiry session.

Ask the practitioner before combining: *"These two inquiries don't appear to share communities or dynamics. Would you prefer a separate Narrative Report for each, or a combined report with minimal synthesis?"*

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02b_Research_Prompting.md

# KB: Prompting Guide — Research Agent
**Agent 02b · CHL AI Agent System**
*Load when the practitioner is stuck or asks for prompt guidance.*

---

## How to Use This Guide

The Research Agent works best when given the complete Big Listening Inquiry from Agent 02a. The more specific the parameters, the more focused and auditable the research output.

The agent always assigns Folio IDs and cites sources. If you receive output without Folio IDs, ask the agent to re-run with citations before accepting the report.

---

## Starter Prompts

### Small Listening Mode — Processing Community Research Only

Use this when your project has no Big Listening and you want to process your team's qualitative research directly into the standardised outputs.

> *"Small Listening mode. I have no Big Listening Inquiry — my research is based entirely on community interviews and qualitative material. Here is my Small Listening data: [paste interview notes / transcripts / observation notes / survey responses]. Process this into the CSV, produce a Narrative Report based on Small Listening only, and generate the ANP Source Library."*

---

### First Cycle — Standard Big Listening

Use this when you have a completed Big Listening Inquiry from Agent 02a and are ready to run research.

> *"Here is my Big Listening Inquiry: [paste inquiry]. Run the Big Listening, build the CSV, and produce the Narrative Report, CSV Database, and ANP Source Library."*

---

### First Cycle — Big Listening Only (No Small Listening Yet)

Use this when your team's Small Listening is still in progress and you want to run Big Listening first.

> *"Here is my Big Listening Inquiry: [paste]. Run the Big Listening now and produce the three outputs. I'll add Small Listening data when my team has collected it. Leave Section 5 of the Narrative Report as a placeholder."*

---

### Processing Small Listening Data

Use this when your team has collected Small Listening material and you want to integrate it into the CSV and Narrative Report.

> *"Here is my existing CSV: [paste or attach]. Here is my Small Listening material: [paste interview notes / transcripts / media scans]. Help me structure this into the CSV and update Section 5 of the Narrative Report with what the Small Listening found."*

---

### Iteration Mode

Use this when returning for a second or later cycle.

> *"Iteration mode. Here is my existing CSV from Cycle 1: [attach]. Here is my existing Narrative Report from Cycle 1: [attach]. Here is my updated Big Listening Inquiry from Agent 02a: [paste]. Extend the CSV with new research, and produce an updated Narrative Report that includes a What Has Changed section."*

---

## Power Prompts

### Request More ANP Source Library Entries

Use when you want more than the standard 5 entries per community for Agent 03's ANP analysis.

> *"Give me 10 ANP Source Library entries for [community name]. Flag the new entries as ANP Source = Yes in the CSV."*

> *"Give me the maximum available entries for all communities — I want a comprehensive ANP Source Library for a deep analysis cycle."*

---

### Audit a Specific Claim

Use when you want to verify that a specific statement in the Narrative Report has proper source support.

> *"Show me the CSV entries behind this claim from the Narrative Report: [paste claim]. What Folio IDs support it?"*

---

### Flag Unverified Patterns

Use when you want to explicitly surface what the research couldn't confirm — for Small Listening follow-up.

> *"What patterns appeared in the Big Listening that could not be sourced or verified? List them as unverified patterns with a note on what Small Listening action would confirm or challenge each."*

---

### Expand a Community Description

Use when a community first draft feels thin and you want more data before passing to Agent 03.

> *"The first draft for [community name] feels thin. Run additional searches to surface more actors, language patterns, and platform activity for this community. Add new entries to the CSV and update the community description in the Narrative Report."*

---

### Generate the Handoff Checklist Only

Use when you want to produce the Handoff Checklist as a standalone document — for example to share with your team before they answer the questions.

> *"Generate the Handoff Checklist for Agent 03 from the current Narrative Report. List the open questions without answers — I'll fill them in before passing to Agent 03."*

---

### Check for Missing Voices

Use when you want to verify that the parameters were searched thoroughly and expected actors were found.

> *"The Big Listening Inquiry included [actor / community] in the Who parameters but I don't see them in the CSV. Did they appear in the research? If not, what might explain their absence?"*

---

## Prompt Tips

**Always pass a complete Big Listening Inquiry.** The agent can work from a partial one but will ask for what is missing — which slows the process. A complete inquiry from Agent 02a means research can start immediately.

**Review Folio IDs before accepting the report.** Every claim in the Narrative Report should have at least one Folio ID in brackets. If you see a claim without a citation, ask the agent to source it or flag it as unverified before proceeding.

**Add Small Listening incrementally.** You don't have to wait for all Small Listening to be complete before starting. The CSV is a living document — you can add Small Listening entries in batches as your team collects material, and ask the agent to update Section 5 of the Narrative Report each time.

**Answer the Handoff Checklist before passing to Agent 03.** The more of the checklist you complete, the more efficiently Agent 03 can proceed. Unanswered questions don't block Agent 03 — but they slow it down.

**Request more ANP sources when the space is complex.** Five entries per community is the standard for most projects. For Pathways with many active actors or fast-moving narrative spaces, 10 entries gives Agent 03 richer material to work from.


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02b_Research_Tools.md

# KB: Tools — Research Agent
**Agent 02b · CHL AI Agent System**
*Load when the practitioner asks about tools or how to run the research.*

---

## Primary Tools

The tools below are named for Claude. On other platforms, use the equivalent: in ChatGPT, Web Search and Deep Research (plus Code Interpreter to deliver the CSV as a file); in Gemini or other assistants, their built-in web search; with no built-in search, the practitioner runs searches in a separate tool (Perplexity, Tavily, SerpAPI, etc.) and pastes the results in. The process below stays the same. Never substitute the model's memory for retrieved sources — a remembered source has no URL or content to cite and cannot receive a Folio ID.

### Exa Search MCP
Deep web search with full source retrieval. Returns full page content, URLs, and publication metadata — not just summaries. This is the primary tool for locating actors, publications, content, and platform activity across the research parameters.

**Best used for:**
- Searching for specific actors, organisations, or publications named in the Who parameters
- Retrieving content from specific platforms or time periods
- Finding how particular keywords and themes appear in the wild
- Locating source material for the ANP Source Library
- Surfacing less visible actors who may not appear in top search results

**Search strategy for narrative research:**
- Start with the most specific terms first — actor names, organisation names, specific hashtags
- Then broaden to thematic keywords to find actors not named in the parameters
- Use platform-specific searches where possible (e.g. searching for content from specific publications or accounts)
- Search within the defined timeframe — check date filters are applied
- For each community, run at least 3–4 distinct search queries to avoid missing clusters

**Assigning Folio IDs:** Assign a Folio ID to each retrieved source at the moment of retrieval — before reading or synthesising. This ensures every CSV entry exists before any claim is made about it.

---

### Claude Research Mode (Native)
Synthesis and pattern recognition across retrieved source material. Available natively — no activation required.

**Best used for:**
- Identifying recurring language patterns across multiple retrieved sources
- Summarising what a cluster of actors is saying about a topic
- Drafting community first-draft descriptions from accumulated CSV entries
- Writing the Narrative Landscape Summary and Key Narrative Dynamics sections
- Building ANP Source Library entry descriptions

**Important constraint:** Claude Research Mode synthesises — it does not independently verify. All synthesis must be traceable to sources already in the CSV. If the synthesis produces a claim that cannot be traced to a Folio ID, it is flagged as an unverified pattern, not stated as a finding.

---

## Optional Tools

If additional web search, scraping, or social listening tools are available in the practitioner's environment, ask before activating them:

> *"I can see [tool name] is available. Would you like me to use it for this research? It would be particularly useful for [specific capability]."*

Do not assume. Different tools have different data access, coverage, and reliability. The practitioner decides what is activated.

---

## AI Limitations in This Work

AI research tools are effective at pattern recognition, actor identification, and synthesis across large bodies of text. They are not effective at understanding lived experience, community relationships, or the cultural context that gives language its meaning.

This means:

**Big Listening produces a structural map — not a complete picture.** The actors and narratives most visible in digital data are not necessarily the most important ones. Communities with strong offline or relationship-based organising may leave few digital traces. Communities that are actively suppressed or marginalised may be underrepresented in search results.

**Small Listening fills what Big Listening cannot reach.** Community interviews, direct observation, and relationship-based research are the primary source for nuance, context, and community voice. AI-generated findings are a starting point for those conversations — not a substitute for them.

**The practitioner is the final check.** Before any research output is passed to Agent 03, the practitioner should review the community first drafts and the Handoff Checklist. If something in the data does not match what the practitioner knows from direct community engagement, that divergence is a signal — not an error to resolve in favour of the data.

**On search bias:** Search results reflect what is indexed, ranked, and accessible on the open web. They carry the biases of the platforms and algorithms that surface them. Content in languages other than English, content from marginalised communities, and content on less visible platforms will be underrepresented. Name these gaps explicitly in the Narrative Report rather than treating the data as complete.

---

## The Community Test

Before finalising the Narrative Report, apply this test to every community description:

*"If you shared this description with someone from this community, would they recognise themselves?"*

If the answer is uncertain — because the description is based entirely on digital data with no Small Listening to ground it — flag it as an unverified first draft and note it in the Handoff Checklist for Agent 03.

This test comes from `KB_AI_Fluency.md` — the shared ethical framework for all CHL agents.

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
