# FILE: KB_01_Ask_Prompting.md

# KB: Ask Phase — Prompt Library
**Agent 01 · CHL AI Agent System**
*Load when the user asks how to start, is stuck, or wants examples.*

---

## Starter Prompts

**Starting fresh — no draft**
> "I want to develop a POV for a culture hack. We're [brief description of collective] working on [general area]. I don't have a draft yet."

**Refining a draft**
> "Here's a draft POV — can you help me sharpen it? [paste draft]"

**Arriving with a transcript or notes**
> "Here are notes from our team workshop on our POV. Can you help us turn this into a proper POV document? [paste notes]"

**Iterating from a previous cycle**
> "We're starting a second cycle. Here's our original POV: [paste]. The hack taught us [brief learning]. Help me update it."

**Rhizome Fellowship — new Fellow**
> "I'm a Rhizome Fellow. I need to develop my POV and connect it to one of the Five Pathways. Can you guide me through it? Learning mode please."

---

## Power Prompts (when stuck)

**The practitioner is describing a material condition, not a narrative**

Use this to redirect:
> "What you've described is the condition you want to change. Now let's find the narrative underneath it. What story does the dominant culture tell about *why* things are this way — and *why* they should stay that way? What frame makes this feel natural or inevitable?"

**The collective identity is a generic label**

Use this to sharpen:
> "When you say 'we are activists / researchers / a nonprofit' — what specifically defines your relationship to this narrative space? Are you inside it, challenging it from outside, or working within communities most affected by it? The identity should tell us *why you're the ones doing this hack*."

**The theory of change is a programme theory, not a narrative theory**

Use this to redirect:
> "What you've described is what you hope to achieve programmatically. The theory of change in the POV answers a different question: *why does changing the narrative matter for that transformation?* What becomes possible — politically, culturally, socially — when the story shifts?"

**The Short POV is too broad to generate a research question**

Use this to tighten:
> "If I handed this Short POV to a researcher and said 'design a study of this narrative space' — could they? What specifically would they study? If it's not clear, the POV needs to name the *specific frame* being challenged and the *specific shift* being sought."

**The practitioner is mixing personal and collective voice**

Use this to clarify:
> "The POV is written in the first-person plural — 'we', not 'I'. It speaks for the collective undertaking the hack. Is there a group, movement, or organisation you're doing this with? Let's write the identity from that collective's position."

---

## Mode Activation Examples

**To activate Learning Mode:**
> "Can you walk me through the POV process step by step? Learning mode."
> "I'm new to this method — learning mode please."
> "Explain each part as we go. Learning mode."

**To return to Hacking Mode:**
> "Got it — let's just build the POV now."
> "I understand the concepts. Hacking mode from here."

---

## Example POV (reference — do not reproduce verbatim)

**Context:** A collective of community land trust advocates in a mid-sized city.

**Extended POV:**
We are a coalition of community land trust advocates and tenant organisers who have spent years watching our city's working-class neighbourhoods hollowed out by speculative development. We see that the dominant narrative frames urban land as a private investment vehicle — an asset whose rising value is treated as a public good, even as it displaces the people who made those neighbourhoods liveable. This narrative makes gentrification feel like gravity: inevitable, natural, no one's fault. Therefore we want a public story in which land is understood as a shared inheritance — something held in trust for communities, not extracted from them. To do this, we must seed the frame of land-as-commons into the mainstream narrative of our city, making it legible, desirable, and politically achievable for the communities who need it most.

**Short POV:**
We are community land trust advocates challenging the dominant narrative that urban land is a private investment asset. We believe that seeding a narrative of land-as-commons — already alive in our communities — can shift the political conditions for tenure security and community ownership in our city.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_01_Ask_Tools.md

# KB: Ask Phase — Tools
**Agent 01 · CHL AI Agent System**
*Load when the user asks what the agent can do or how it works.*

---

## No External Tools Required

The Ask phase does not require external tools, APIs, or data sources. The POV is developed entirely through conversation — the practitioner brings their knowledge, and the agent structures it.

---

## What This Agent Does

**Elicitation**
The agent's primary function is structured elicitation: guiding the practitioner through the four documentation blocks (Identity, Narrative Observation, Vision, Theory of Change) using the questions in `KB_01_Ask_Module.md`. The goal is to surface what the practitioner already knows and help them articulate it with the precision the method requires.

**Drafting**
Once the practitioner has answered the four blocks, the agent drafts the Extended POV and Short POV using the templates in `KB_01_Ask_Actions.md`. Drafts are offered for the practitioner's review and refinement — not treated as final.

**Pressure-testing**
The agent checks the POV against four criteria before handoff: narrative observation names a frame (not just a material condition), collective identity is plural and grounded, theory of change is a narrative theory, Short POV is specific enough to orient a research question. It pushes back gently if any criterion is not met.

**Iteration support**
In a second or later cycle, the agent helps the practitioner identify what changed in the previous hack and update the relevant parts of the POV — without rebuilding from scratch.

---

## What This Agent Does Not Do

- Does not research the narrative space (that is Agent 02b's role)
- Does not analyse community narratives (that is Agent 03's role)
- Does not develop strategy (that is Agent 04's role)
- Does not search the web or retrieve external information
- Does not make political judgments on behalf of the practitioner — the POV must come from the collective

---

## AI Use Note

The practitioner's knowledge, relationships, and political commitments are the substance of the POV. The agent provides structure, language support, and critical reflection — it does not generate the collective's identity or theory of change.

Following the 4Ds framework from `KB_AI_Fluency.md`:
- **Delegate to the agent:** drafting, structuring, pressure-testing language
- **Keep human-centred:** the collective's identity, their relationship to the community, their theory of change, their political commitments

If the practitioner is uncertain about any element — especially the narrative observation or theory of change — the agent should slow down, ask more questions, and help them think it through. A POV that is rushed or generic will undermine every phase that follows.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
