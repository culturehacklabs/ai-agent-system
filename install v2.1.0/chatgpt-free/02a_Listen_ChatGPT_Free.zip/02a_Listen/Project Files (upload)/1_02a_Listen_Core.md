# FILE: KB_02a_Listen_Actions.md

# KB: Actions — Listening Model Templates
**Agent 02a · CHL AI Agent System**
*Load when producing any output: Listening Model, Big Listening Inquiry, or Iteration Cycle update.*

---

## Output A — Listening Model

The full research design document. Produced at the end of a first-cycle session with the practitioner. Contains both Small Listening actions and the Big Listening Inquiry.

```
## Listening Model

**POV (Short):** [1–3 sentence Short POV from Agent 01]

**Research Question (Why):**
[The specific, focused inquiry derived from the Short POV.
Narrow enough to be answerable. Connected directly to the narrative problem.]

**Listening Objectives:**
[2–4 specific questions this research needs to answer — more focused than the
research question, these define what success looks like for this phase]

---

### Small Listening

**Action 1: [Name / Description]**
- **What (Themes):** [specific topics, keywords, frames to track]
- **Who (Actors):** [communities, individuals, or organisations to engage]
- **When (Timeframe):** [period and reasoning — why this window?]
- **Where (Spaces):** [platforms, geography, physical or digital spaces]
- **How (Method):** [specific approach: interviews / surveys / media analysis / observation]
- **Documentation Plan:** [how findings will be recorded and stored]
- **Expected Output:** [what this action will produce]

[Repeat for each Small Listening action — 1 to 3 actions recommended]

---

### Big Listening Inquiry

[See Output B below — the Big Listening Inquiry is both part of the Listening Model
and the standalone handoff document to Agent 02b]
```

---

## Output B — Big Listening Inquiry

The structured handoff to Agent 02b. Contains the Research Question and the five parameters. Produced as a standalone document as well as the final section of the Listening Model.

```
## Big Listening Inquiry

**Research Question (Why):**
[The specific, focused question this Big Listening is designed to answer.
This is the reason for listening — it carries the hypothesis and orients
all five parameters.]

---

### Parameters

**What — Themes and Keywords**

Primary themes:
- [Theme 1: description + sample keywords]
- [Theme 2: description + sample keywords]
- [Theme 3: description + sample keywords]

Secondary themes:
- [Theme: description + keywords — present in the space but not the core focus]

**Who — Actors and Communities**

Primary actors:
- [Organisation / individual / publication + why they matter]
- [Organisation / individual / publication + why they matter]

Communities to locate:
- [Working description of community expected to be present]
- [Working description of community expected to be present]

Voices likely absent from digital data:
- [Community or voice — flag for Small Listening]

**When — Timeframe**
- Period: [start date → end date]
- Reasoning: [why this window — events, campaigns, political moments]
- Secondary period (if applicable): [earlier context period]

**Where — Platforms and Geography**
- Primary platforms: [list]
- Secondary platforms: [list]
- Geographic scope: [regions, countries, languages]
- Less visible spaces: [forums, closed groups, physical spaces — flag for Small Listening]

**How — Method and Documentation**
- Big Listening tools: [Deep web search + multi-source synthesis — handled by Agent 02b]
- Small Listening running in parallel: [reference to Small Listening actions in the Listening Model]
- Documentation: [how data will be stored and organised — CSV Database]

---

### Handoff Notes for Agent 02b
[Any additional context: prior CHL research to reference,
community voices to prioritise, known limitations]
```

---

## Output C — Iteration Cycle Update

Produced in Iteration Mode. Documents what changes in the Listening Model for the new cycle, and why. Does not replace the original Listening Model — it layers over it.

```
## Iteration Cycle Update

**Cycle:** [number — e.g. Cycle 2]
**Date:** [when this update was produced]
**Iteration Input:** [what triggered the update — Case Study / Post-Hack Evaluation / Narrative Strategy / Narrative Objectives]

---

### What the Previous Cycle Revealed

**Key finding for the Listening Model:**
[What the hack / evaluation showed about the narrative space that changes
what needs to be researched in this cycle]

**POV update (if any):**
[Has the narrative observation or theory of change sharpened?
If a more significant change is needed, flag for Agent 01.]

---

### Updated Research Question

**Previous:** [original research question]
**Updated:** [revised research question — and why it changed]

---

### Updated Parameters

**What — changes:**
- New keywords / themes to add: [list + reasoning]
- Keywords / themes to drop or de-prioritise: [list + reasoning]

**Who — changes:**
- New actors or communities to include: [list + reasoning]
- Communities to investigate more specifically: [any that proved more complex than mapped — consider splitting into sub-communities]

**When — changes:**
- New timeframe: [covers the period since the last cycle, plus any relevant new political moments]

**Where — changes:**
- New platforms or spaces to add: [list + reasoning]

**How — changes:**
- New Small Listening actions needed: [based on gaps from previous cycle]
- Documentation updates: [any changes to how data is captured]

---

### Updated Big Listening Inquiry

**Updated Research Question:**
[Revised research question — and why it changed]

**Parameters:** [reproduce in full as a clean standalone document for Agent 02b]

---

### What Stays Stable

- CSV Database: extended, not replaced [confirm with Agent 02b]
- Core POV identity and vision: [confirm stable or flag change]
- [Any other elements that carry forward unchanged]
```

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02a_Listen_Module.md

# KB: Listen Phase — Listening Model
**Agent 02a · CHL AI Agent System**
*Load always — core phase theory, documentation questions, and iteration workflow.*

---

## What This Phase Is

Listen is the second phase of the Culture Hack Method. Its purpose is to research the narrative space the practitioner wants to intervene in — before drawing any strategic conclusions.

The method does not assume it already knows what needs to be done. Listening is how the practitioner discovers where new moments of change are occurring and what they are revealing. It is an act of genuine inquiry, not confirmation of what the POV already suspects.

The output of this phase — collected and organised data — becomes the **baseline** that all later analysis and impact evaluation will compare against. What the narrative space looks like before the hack is as important as what it looks like after. Without a rigorous baseline, there is nothing to measure change against.

Agent 02a designs the research framework. Agent 02b executes the Big Listening. Small Listening runs in parallel, conducted by the practitioner's team.

---

## Key Concepts

**Listening Model**
A theoretical and practical tool for researching narratives. It structures the inquiry by setting a research question (the Why) and five parameters (What, Who, When, Where, How). It must be unique to the specific inquiry — not a generic template applied across projects.

**Research Question**
The POV transformed into a specific, focused inquiry. It orients all listening parameters and keeps them coherent. A good research question is narrow enough to be answerable and connected directly to the narrative problem named in the POV.

Example of a focused research question: *"How are mainstream media outlets framing Indigenous land rights in the context of recent resource extraction legislation?"*
Example of a research question that is too broad: *"What is the narrative around land rights?"*

**Small Listening**
Qualitative, relationship-based research conducted by the practitioner's team: interviews, surveys, manual media analysis, community observation. Identifies texture, nuance, and direct community voice. Small Listening is particularly important for investigating patterns that emerge from Big Listening and for grounding AI-generated findings in lived community experience.

**Big Listening**
Large-scale digital research using online research tools to observe and collect data at scale. Reveals broader patterns across platforms and networks: which narratives are active, which actors are most influential, how narratives flow between communities. The Big Listening Inquiry is the structured research brief handed off to Agent 02b.

Both modes are complementary and run in parallel. Small Listening adds depth and community grounding; Big Listening adds scale and structural pattern recognition. Neither replaces the other.

**Big Listening Inquiry**
The structured handoff document from 02a to 02b. It contains the Research Question and the five parameters. The Research Question carries the hypothesis — the reason the practitioner is listening and what they want to understand. The parameters orient the research: what to look for, who to find, when and where to look, and how to capture it. Simple and sufficient to run the research.

---

## The Listening Model Structure

### Why — Research Question
Derived directly from the Short POV. The single question the listening is designed to answer.

Ask: *Given our POV, what do we most need to understand about this narrative space to design an effective intervention?*

### The Five Parameters

These apply to both Small and Big Listening:

| Parameter | What to define |
|---|---|
| **What** | Specific narrative themes, keywords, frames, or topics to track — including primary themes and secondary themes |
| **Who** | Communities, actors, organisations, or demographics of interest — including voices you expect to find and voices you suspect are absent |
| **When** | Time period for research — and why that timeframe. Are there defining events, political moments, or systems crises that bound the relevant period? |
| **Where** | Platforms, geographic regions, physical or digital spaces — including less visible or harder-to-access spaces where the conversation may be happening differently |
| **How** | Research methods, documentation format, and expected output. What is realistic for the team's capacity? How will data be stored so it can be retrieved and compared later? |

**A note on How:** Documentation discipline matters. The data collected here becomes the knowledge base for all analysis in the Understand phase and for measuring impact in the Evaluate phase. Interviews should be recorded and transcribed. Media sources tracked with links. Observations captured in consistent formats. If data cannot be retrieved and compared later, it cannot anchor any claims of change.

---

## Documentation Questions

Use these to guide the practitioner through designing their Listening Model. Work through them in sequence. In Hacking Mode, ask only for what is genuinely missing.

**Research Question**
- What do you most need to understand about this narrative space to inform your intervention?
- What assumptions does your POV make that need to be tested or validated through research?
- What are you genuinely uncertain about — what might surprise you?

**Parameters — What**
- What narrative themes, topics, or conversations are you tracking?
- What keywords or phrases are most likely to surface the narratives you care about?

**Parameters — Who**
- Which communities, actors, or organisations are active in this narrative space?
- Are there voices you already know about? Voices you suspect are there but haven't found yet?
- Whose voices are likely to be absent from digital data — and how will Small Listening reach them?

**Parameters — When**
- What time period will you research? Why that window?
- Are there specific events, campaigns, political moments, or systems crises that define the relevant period?

**Parameters — Where**
- Where does this narrative live — which platforms, media outlets, physical spaces, or geographic regions?
- Are there spaces where this conversation happens that are less visible or harder to access?

**Parameters — How**
- What research methods are realistic for your team's capacity?
- How will you store and organise what you collect so it can be used later?
- What do you expect this listening to produce?

**Small Listening design support:** If the practitioner needs help designing their Small Listening instruments — interview guides, observation frameworks, survey questions oriented toward narrative listening — load `KB_02a_Listen_SmallListening.md`. This is available on request at any point during the session, including after the Listening Model has been produced.

**Feasibility Check — before producing outputs**
Once the Small Listening design is drafted, confirm with the practitioner before finalising:
- Does the proposed plan match your team's actual capacity — time, access, community relationships, languages?
- Is anything here not realistic? Is anything important missing?

This is a brief alignment moment, not a re-opening of all the parameters. A simple confirmation is enough to proceed.

**Big Listening Inquiry**
- What is the specific research question you want the Big Listening to answer?
- What keywords, actors, platforms, and timeframe should the research focus on?

---

## Iteration Workflow

In a second or later cycle, the practitioner does not rebuild the Listening Model from scratch. They update it based on what the previous hack revealed.

**Iteration is activated when the practitioner provides any of:**
- A Case Study from Agent 05b
- A Post-Hack Evaluation (Output B) from Agent 05b
- A Narrative Strategy or Narrative Objectives from Agent 04

**What stays stable in iteration:**
- The core POV (may be sharpened but is not rebuilt)
- The basic research question structure (focus may sharpen)
- The CSV Database from Agent 02b (extended, not replaced)

**What gets updated in iteration:**
- Research question: refined based on what the hack revealed
- Parameters: new timeframe covering the period since the last cycle; updated keywords reflecting new frames or language observed; new actors or communities identified during the hack; new platforms or spaces revealed by the hack
- Small Listening actions: new methods or communities based on gaps identified in the previous cycle
- Big Listening Inquiry: reproduced with updated research question and parameters

**The iteration input tells the agent what to update:**
- Case Study / Post-Hack Evaluation → update based on what shifted (or didn't) in the narrative space
- Narrative Strategy → update to investigate whether strategic frames are gaining traction
- Narrative Objectives → update to track whether target communities are moving

**On POV refinement in iteration:**
New findings from the hack may sharpen the narrative observation or theory of change. The core collective identity and vision typically remain stable. If the hack revealed that the original POV was misaligned with what was found in the narrative space, this should be flagged to the practitioner and potentially returned to Agent 01 before proceeding.

---

## What Comes Before / After

**Before:** Receives the **Short POV** from Agent 01. If no POV exists, direct the practitioner to Agent 01 before proceeding.

**After:** Passes the **Big Listening Inquiry** to Agent 02b, which executes the large-scale digital research. Small Listening runs in parallel, conducted by the practitioner's team.

**On the cycle:** Listen is the second phase. The baseline established here travels all the way to Agent 05b (Impact & Iteration), where it becomes the reference point for measuring change. A weak baseline produces a weak evaluation.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
