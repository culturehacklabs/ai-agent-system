# FILE: KB_02a_Listen_Prompting.md

# KB: Prompting Guide — Listening Model Agent
**Agent 02a · CHL AI Agent System**
*Load when the practitioner is stuck, asks for prompt guidance, or needs to activate a specific mode.*

---

## How to Use This Guide

These prompts are starting points. The best prompt includes:
- Your Short POV (or a description of your narrative problem)
- Any context that helps the agent understand your project
- The mode you want to work in (if not the default)

The agent works best when given specific context. Vague prompts produce generic Listening Models. The more precise your POV and the clearer your uncertainty, the more focused your research design will be.

---

## Starter Prompts

### First Cycle — Standard

Use this when you have a Short POV and are designing your Listening Model for the first time.

> *"Here is my Short POV: [paste Short POV]. Help me design a Listening Model and Big Listening Inquiry for this project."*

---

### First Cycle — Learning Mode

Use this when you want to understand each step as you go, or when you are new to the method.

> *"Learning mode. Here is my Short POV: [paste Short POV]. Walk me through building a Listening Model step by step."*

---

### First Cycle — You Have a Draft Already

Use this when you have already done some thinking and want to refine rather than start from scratch.

> *"Here is my Short POV: [paste]. I've also started thinking about my research parameters: [share what you have]. Help me strengthen and complete this into a full Listening Model and Big Listening Inquiry."*

---

### Iteration Mode — From a Case Study

Use this when you are entering a second or later cycle and have a Case Study from Agent 05b.

> *"Iteration mode. Here is my original Short POV: [paste]. Here is my Case Study from the previous cycle: [paste or attach]. Update my Listening Model for the next cycle based on what we learned."*

---

### Iteration Mode — From a Post-Hack Evaluation

> *"Iteration mode. Here is my original Listening Model: [paste]. Here is my Post-Hack Evaluation from Agent 05b: [paste]. What needs to change in the research parameters for the next cycle?"*

---

### Iteration Mode — From a Narrative Strategy

Use this when the previous hack revealed something that changes what needs to be researched — and you want the new listening to specifically track whether strategic frames are gaining traction.

> *"Iteration mode. Here is my original Short POV: [paste]. Here is my Narrative Strategy from Agent 04: [paste]. Update my Listening Model to track whether the frames and target communities from this strategy are showing movement in the narrative space."*

---

## Power Prompts

### Sharpen a Research Question

Use when a research question feels too broad or too close to a topic description rather than a focused inquiry.

> *"My current research question is: [paste]. Is this specific enough to orient a Big Listening? If not, help me sharpen it based on this POV: [paste Short POV]."*

---

### Check for Gaps

Use when you want to stress-test your Listening Model before handing off to 02b.

> *"Here is my completed Listening Model: [paste]. Are there gaps — voices likely absent from digital data, platforms I've missed, or themes I haven't included? What would you add before handing off to Agent 02b?"*

---

### Design a Small Listening Action

Use when you know you need qualitative community research but aren't sure how to structure it.

> *"Here is my Listening Model: [paste]. I need to design a Small Listening action to reach [community or voice]. Help me design a specific method, documentation plan, and expected output for this action."*

---

### Design Small Listening Instruments

Use when you need actual research instruments — interview questions, observation frameworks, or survey structure — not just a method description. This loads the Small Listening design support.

> *"Here is my Small Listening action from my Listening Model: [paste action]. Help me design the actual interview guide / observation framework / survey for this action. It needs to be oriented toward listening for narrative — frames, language, and how this community makes sense of [topic]."*

> *"My project runs on Small Listening only — no Big Listening. Help me design a complete set of Small Listening instruments for this Listening Model: [paste]."*

---

### Build the Big Listening Inquiry from a Complete Listening Model

Use when you've built your Listening Model but want a clean standalone Big Listening Inquiry document for the handoff.

> *"Here is my Listening Model: [paste]. Produce a standalone Big Listening Inquiry document from this — ready to hand off to Agent 02b."*

---

## Prompt Tips

**Be specific about your uncertainty.** The best research questions come from naming what you genuinely don't know. "I don't know whether X community is growing or marginalised" produces a more focused inquiry than "I want to understand the narrative space."

**Include context about your team's capacity.** Small Listening design depends on what your team can realistically do: how many interviews, what languages, what access. Naming constraints early produces better design.

**In iteration, be specific about what surprised you.** The most useful input for updating a Listening Model is what the hack revealed that you didn't expect — whether that's a community that responded differently than predicted, a frame that backfired, or a platform that proved more active than anticipated.


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02a_Listen_SmallListening.md

# KB: Small Listening Design
**Agent 02a · CHL AI Agent System**
*Load when the practitioner asks for help designing Small Listening instruments — interview guides, observation frameworks, or survey design.*

---

## Purpose

This KB helps narrative practitioners design the actual research instruments they will use in the field — the questions they ask, the frameworks they observe with, the surveys they distribute. It is oriented specifically toward narrative listening: listening for how communities make sense of the world, what frames they use, what they make visible and invisible, and what language they reach for.

These instruments are designed by the agent but belong to the practitioner. They should always be reviewed, adjusted for cultural context, and tested before use. The practitioner knows their community — the agent provides a starting structure.

---

## What Narrative Listening Is Listening For

Standard research instruments listen for opinions, experiences, and facts. Narrative listening listens for something different — the cognitive architecture underneath the opinion:

- **Frames:** What does this person take for granted? What do they assume everyone already knows? What is so obvious to them it doesn't need to be said?
- **Metaphors:** How do they describe abstract things — the economy, the land, the community, the future? What images do they reach for?
- **Causality:** What causes what, in their account? Who has agency? Who is acted upon?
- **Absences:** What doesn't come up? What would feel strange or inappropriate to say? What is outside the frame?
- **Language:** What specific words do they use — and which words do they avoid? What terms carry weight?

Good narrative listening instruments create space for this deeper layer to emerge — they don't ask "what do you think about X?" but "tell me about a time when..." or "how would you describe X to someone who didn't know it?"

---

## Interview Guide Design

### Principles

**Open before specific.** Start with broad, open questions that let the person tell their own story before narrowing to the themes in your research parameters.

**Concrete before abstract.** Ask about specific experiences, events, or examples before asking about general views or beliefs. Stories reveal frames better than opinions do.

**Listen for language.** The exact words a person uses matter as much as what they say. Note recurring terms, metaphors, and the language they reach for when describing difficult or abstract things.

**Follow the unexpected.** The most valuable moments in a narrative interview are when something surprising appears — a word you didn't expect, a connection you didn't anticipate. Design space for that.

**End with reflection.** Close questions that invite the person to step back and reflect on the conversation — what they said, what matters, what they want to add.

### Interview Guide Template

```
## Interview Guide
**Project:** [project name]
**Small Listening Action:** [from Listening Model]
**Research Question:** [from Listening Model]
**Estimated duration:** [30–60 minutes recommended for narrative interviews]

---

### Opening (5 min)
Brief introduction: who you are, what this research is for, how findings will be used,
confidentiality, permission to take notes / record.

"Before we start, do you have any questions about the research or how your
responses will be used?"

---

### Warm-up — Their Story (10 min)
[Open questions that let the person situate themselves in relation to the topic.
Not about the narrative space — about them.]

1. "Can you tell me a little about your work / involvement with [topic area]?
   How did you come to be involved?"

2. "What drew you to this work / this community / this issue?"

[Adapt to context. The goal is to hear how they describe themselves in relation
to the topic — what role they give themselves, what language they use.]

---

### Core Questions — Narrative Listening (20–30 min)
[These are oriented toward the specific research question and parameters.
Generate 4–6 questions from the template below, adapted to the project.]

**Experience and story questions:**
- "Can you tell me about a specific moment when [topic] felt very present for you?
  What happened?"
- "What would you point to as a turning point in how [issue] has played out in
  [community / region / sector]?"

**Language and framing questions:**
- "How would you describe [topic] to someone who knew nothing about it?"
- "What words do people use when they talk about [topic] in your community?
  Are there words you find yourself avoiding or pushing back on?"

**Causality and agency questions:**
- "In your view, why is [situation] the way it is? What got us here?"
- "Who has the power to change this? What would need to happen?"

**What is missing / invisible questions:**
- "What do you think gets left out of how [topic] is usually talked about?"
- "Is there something important about [issue] that you rarely hear people say
  out loud — even if you think it's true?"

**Alternative narrative questions:**
- "Are there communities or places where [topic] is being talked about or
  approached differently? What does that look like?"
- "If things were going well — if [the change your POV points toward] were
  actually happening — what would that look like from where you sit?"

---

### Closing — Reflection (5–10 min)
- "Is there anything you expected me to ask that I didn't?"
- "Is there something you've been thinking about during our conversation
  that you'd like to add?"
- "Is there someone else you think I should speak with, or something you'd
  suggest I read or look at?"

---

### Post-Interview Notes (for researcher — fill in immediately after)
- What recurring language or phrases did this person use?
- What surprised you?
- What felt absent — what didn't come up that you expected?
- What frames or metaphors appeared?
- What does this add to or challenge from what you already know about this community?
```

---

## Observation Framework

Use when the Small Listening action involves attending an event, following a community space, or observing a public process — not conducting interviews.

### Principles

**Observe what is said and how, not just what.** The language used in a meeting, a protest, a community gathering is as important as the content of what is decided or demanded.

**Note what is absent.** What topics don't come up? Who doesn't speak? What would feel out of place here?

**Track recurring language.** What terms, phrases, or metaphors come up repeatedly? What words carry weight in this space?

**Note who speaks and who is listened to.** Power is visible in who gets the floor, who gets challenged, whose framing sticks.

### Observation Framework Template

```
## Observation Framework
**Project:** [project name]
**Space / Event:** [what is being observed]
**Date / Duration:** [when, how long]
**Observer:** [who is observing]

---

### Before (set up what you are listening for)
- Research question this observation is responding to:
- Communities or actors expected to be present:
- Specific themes or language to listen for:

---

### During (structured notes)

**Who is present:**
[Who is in the space — communities, roles, demographics]

**What is said — language notes:**
[Recurring terms, phrases, metaphors. Quote directly where possible.
Note who said what.]

**What frames appear:**
[What is taken for granted? What causal logic appears?
What is treated as obvious or self-evident?]

**What is absent:**
[Topics that don't come up. People who don't speak.
Things that would feel out of place here.]

**Power observations:**
[Who speaks? Who is listened to? Whose framing sticks?
Who gets challenged?]

**Unexpected moments:**
[Anything surprising — a word you didn't expect, a tension that surfaced,
a connection that appeared]

---

### After (reflection — fill in immediately)
- What narrative frames were dominant in this space?
- What did this observation add to or challenge from existing research?
- What follow-up questions does this raise?
- Folio IDs to assign: [SL-X-XXX for each distinct observation to enter in CSV]
```

---

## Survey Design for Narrative Research

Surveys are the weakest instrument for narrative listening — closed questions produce data about opinions, not frames. Use surveys only when scale matters and qualitative depth is not the priority. If possible, combine a short survey with follow-up interviews for a subset of respondents.

### Principles

**Open questions over scales.** Rating scales tell you intensity, not meaning. Open text fields, even short ones, reveal language and framing.

**Avoid leading language.** The words in your question prime the answer. Use neutral terms and test questions with someone from the community before distributing.

**Ask about experience before opinion.** "Have you experienced X?" before "What do you think about X?" grounds responses in concrete reality.

**Leave space for what isn't in your questions.** Always include a final open field: "Is there anything else you'd like to share?"

### Survey Template Structure

```
## Survey
**Project:** [project name]
**Estimated completion time:** [5–10 minutes recommended]

---

Section 1 — About You (optional, anonymous options available)
[2–3 questions about the respondent's relationship to the topic —
role, geography, how long involved. Do not ask for identifying information
unless necessary and consented to.]

Section 2 — Experience
[2–3 questions about concrete experience of the topic.
"Have you experienced X?" / "Can you describe a recent example of X?"]

Section 3 — Language and Framing
[2–3 open-text questions oriented toward narrative listening.
"How would you describe [topic] in your own words?"
"What words do you hear most often when people talk about [topic]?
Are there any you push back on?"]

Section 4 — What Is Missing
[1–2 questions about what gets left out.
"What do you think is missing from how [topic] is usually discussed?"]

Section 5 — Open
"Is there anything else you'd like to share about [topic] that we haven't asked about?"

---

### Post-Survey Analysis Notes
When processing survey responses into the CSV:
- Look for recurring language across open-text fields — these are frame signals
- Note outlier responses — unexpected framings are often the most useful
- Flag any responses that directly confirm or contradict Big Listening findings
- Assign Folio IDs to notable responses before entering them into the CSV
```

---

## Small Listening for Small Listening-Only Projects

When a project runs on Small Listening only — no Big Listening — the instrument design becomes even more important because it is the primary source of all research findings.

In this case, design at least two different instrument types — for example, interviews plus observation, or interviews plus a survey — to triangulate findings. Single-method Small Listening projects are more vulnerable to researcher bias and narrow sampling.

At the end of a Small Listening-only project, always ask: what would Big Listening add? The answer becomes part of the Handoff Checklist for Agent 03 and informs the next cycle's Listening Model update in Agent 02a.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02a_Listen_Tools.md

# KB: Tools — Listening Model Agent
**Agent 02a · CHL AI Agent System**
*Load when the practitioner asks about tools, research methods, or what Agent 02b will use.*

---

## 02a Has No Active Search Tools

Agent 02a is a design and planning agent. Its job is to build the research framework — not to execute research. No search tools are called at this stage.

The practitioner's output from this agent is a Listening Model and Big Listening Inquiry. These documents are then handed to Agent 02b, which runs the actual research using its own toolset.

---

## What Agent 02b Will Use

When the practitioner is ready to hand off to Agent 02b, they can expect the following tools to be available:

**Deep web search** *(Claude: Exa Search MCP · ChatGPT: Web Search)*
Web search with full source retrieval. Best for: locating specific actors and publications, finding content from particular platforms or time periods, retrieving source material for the ANP Source Library. Returns full page content and URLs — not just summaries.

**Multi-source synthesis** *(Claude: Research mode · ChatGPT: Deep Research, where available)*
Pattern recognition across large bodies of retrieved material. Best for: identifying narrative patterns across multiple sources, summarising what multiple actors are saying about a topic, building the Narrative Report from the retrieved data.

If the platform running Agent 02b has no web search, the practitioner runs the searches with a separate tool and pastes the results in — the Big Listening Inquiry designed here works the same either way.

If other web search or scraping tools are active in the practitioner's environment, Agent 02b will ask whether they should be used before proceeding.

---

## Prior CHL Research as a Starting Point

Before running new Big Listening, it is worth checking whether CHL or the Rhizome Fellowship has prior research on the same narrative space or Pathway. Prior research can:
- Provide a baseline for comparison
- Surface communities or actors already identified
- Avoid duplicating work already done

In Iteration Mode, the existing CSV Database from the previous cycle is the primary starting point. Agent 02b extends it rather than replacing it.

If this is a first cycle, ask the practitioner: *"Has CHL or your team done any prior research on this narrative space? If so, sharing it with Agent 02b at the start of the research session will help ground the new listening in existing knowledge."*

---

## Small Listening — The Practitioner's Responsibility

Small Listening is conducted by the practitioner's team, not by the AI agent. Agent 02a designs the Small Listening actions; the team executes them. Agent 02b can help organise and process Small Listening data once it is collected, but it cannot conduct interviews, ethnographic observation, or community engagement.

**Common Small Listening methods:**
- Semi-structured interviews with community members, organisers, or practitioners
- Surveys or questionnaires distributed through community networks
- Manual media analysis: reading publications, following accounts, reviewing campaign materials
- Community observation: attending events, following social media accounts, reading newsletters
- Focus groups or community conversations

**Documentation discipline for Small Listening:**
- Interviews: record and transcribe (or take detailed notes with key quotes)
- Media sources: track with title, publication, date, URL, and brief note on what it reveals
- Observations: consistent format — date, space, what was observed, what it suggests
- All entries: eventually mapped to the CSV Database columns used by Agent 02b

The quality of the full research output depends as much on the Small Listening as on the Big Listening. AI-generated findings are a structural map. Small Listening fills it with community voice, texture, and lived experience that digital data cannot capture.

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
