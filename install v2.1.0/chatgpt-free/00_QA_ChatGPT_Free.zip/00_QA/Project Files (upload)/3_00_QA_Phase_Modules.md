# FILE: KB_01_Ask_Module.md

# KB: Ask Phase — Point of View
**Agent 01 · CHL AI Agent System**
*Core phase knowledge. Load by default.*

---

## What This Phase Is

Ask is the entry point of the Culture Hack Method. Its purpose is to establish the **Point of View (POV)** — the collective statement that sets the foundation for the entire narrative intervention.

The POV is not an organisational mission statement or a summary of the problem a collective works on. It names a **narrative problem**: a specific cultural construct or dominant frame that is sustaining the conditions the collective wants to change — and a theory of how shifting that narrative will contribute to systems change.

Without a clear POV, the hack lacks direction. It becomes a communications exercise rather than a strategic intervention. The POV is the north star that all subsequent phases orient toward: listening, analysis, strategy, and intervention.

---

## Key Concepts

**Point of View (POV)**
A collective statement with four parts: who we are, what we observe in the narrative landscape, what we want to shift, and how we believe that shift will happen. It names a narrative problem, not just a material condition.

*The difference:* "Housing is unaffordable for working families" is a material condition. "The dominant narrative frames housing as an investment asset rather than a human right — making dispossession feel natural and inevitable" is a narrative problem.

**Collective Identity**
The POV is written in the first-person plural: "We are…". It names the group, movement, or collective undertaking the hack — not individual practitioners. The identity should be grounded in the practitioner's relationship to the narrative space they want to enter.

**Narrative Observation**
What the collective sees in the current narrative landscape. This is an observation about a dominant cultural construct, frame, or story — not a description of what is materially wrong. It answers: *What story is being told that sustains the conditions we want to change? What does that story make visible — and what does it hide?*

**Vision**
What would become possible if the narrative shifted. Not a programme or policy goal — a statement of what different sense-making would open up.

**Theory of Change**
How shifting this narrative contributes to the larger transformation the collective seeks. The bridge between the POV and the hack. It answers: *Why does narrative matter here? What changes when the story changes?*

**Short POV**
A 1–3 sentence distillation of the Extended POV. This is the direct handoff to Agent 02a. It must be specific enough to generate a research question — not a general statement of values or concern.

**Five Pathways to Regenerative Futures** *(Rhizome Fellowship context only)*
If working within the Rhizome Fellowship, the POV connects to one of five thematic anchors:
1. Restoring Justice, Restoring Life
2. Economies of Regeneration
3. Land Back to Right Relationship
4. Bioregional Community Governance
5. Healing the Spirit, Healing the Earth

If working outside the Fellowship, skip this entirely. The POV stands on its own.

---

## The POV Format

**Four-part structure:**
> *"We are [collective identity] / we see that [narrative observation] / Therefore we want [vision] / To do this, we must [theory of change]"*

**Two output formats:**

| Format | Length | Purpose |
|--------|--------|---------|
| Extended POV | One full paragraph | Detailed reference; internal document |
| Short POV | 1–3 sentences | Handoff to Agent 02a; orients the research question |

The Short POV distils the narrative problem and theory of change. It should be specific enough that someone reading it knows *exactly* what narrative space is being hacked and *why*.

---

## Documentation Questions

Work through these blocks in order. In Hacking Mode, they can be asked together. In Learning Mode, one block at a time.

**Block 1 — Identity**
- Who are the people or collective behind this hack? How do you describe yourselves?
- What is your relationship to the narrative space you want to intervene in? Are you inside it, adjacent to it, or challenging it from outside?

**Block 2 — Narrative Observation**
- What narrative, frame, or cultural construct are you challenging?
- What does the current dominant narrative make visible — and what does it hide or make seem unthinkable?
- How does this narrative sustain the conditions you want to change?

*Prompt if the answer describes a material condition rather than a narrative:* "What story justifies or naturalises that condition? What does the dominant frame say about why things are this way — and why they should stay this way?"

**Block 3 — Vision**
- What would shift if the narrative changed? What becomes possible?
- What larger transformation is this connected to?

**Block 4 — Theory of Change**
- How does changing this narrative contribute to the larger transformation you seek?
- What is your role in that process?

**Optional — Timeline** *(imagination exercise, not a fixed plan)*
- If this narrative shift happened over the next few years, what might look different?
- Where could this work lead in the longer term?

---

## Pressure-Test Questions

Before producing the final POV, check:

- Does the narrative observation name a **frame or cultural construct** — not just a social problem?
- Is the collective identity **plural and grounded** — not a generic label?
- Is the theory of change a **narrative theory** — not a policy or programme theory?
- Is the Short POV **specific enough** to generate a focused research question for Agent 02a?

---

## What Comes Before / After

**Before:** This is the entry point. Practitioners may arrive with a general area of concern, an existing project, a draft POV, or a workshop transcript. The agent helps them sharpen and formalise it.

**After:** The Short POV passes to **Agent 02a (Listening Model)**, which transforms it into a research question and listening parameters.

**On iteration:** In a second or later cycle, the POV is refined — not rebuilt. New findings from the hack may sharpen the narrative observation or theory of change. The core identity and vision typically remain stable. The agent helps the practitioner identify *what specifically* to update and *why*, based on what the previous cycle revealed.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02a_Listen_Module.md

# KB: Listen Phase — Listening Model
**Agent 02a · CHL AI Agent System**
*Load always — core phase theory, documentation questions, and iteration workflow.*

---

## What This Phase Is

Listen is the second phase of the Culture Hack Method. Its purpose is to research the narrative space the practitioner wants to intervene in — before drawing any strategic conclusions.

The method does not assume it already knows what needs to be done. Listening is how the practitioner discovers where new moments of change are occurring and what they are revealing. It is an act of genuine inquiry, not confirmation of what the POV already suspects.

The output of this phase — collected and organised data — becomes the **baseline** that all later analysis and impact evaluation will compare against. What the narrative space looks like before the hack is as important as what it looks like after. Without a rigorous baseline, there is nothing to measure change against.

Agent 02a designs the research framework. Agent 02b executes the Big Listening. Small Listening runs in parallel, conducted by the practitioner's team.

---

## Key Concepts

**Listening Model**
A theoretical and practical tool for researching narratives. It structures the inquiry by setting a research question (the Why) and five parameters (What, Who, When, Where, How). It must be unique to the specific inquiry — not a generic template applied across projects.

**Research Question**
The POV transformed into a specific, focused inquiry. It orients all listening parameters and keeps them coherent. A good research question is narrow enough to be answerable and connected directly to the narrative problem named in the POV.

Example of a focused research question: *"How are mainstream media outlets framing Indigenous land rights in the context of recent resource extraction legislation?"*
Example of a research question that is too broad: *"What is the narrative around land rights?"*

**Small Listening**
Qualitative, relationship-based research conducted by the practitioner's team: interviews, surveys, manual media analysis, community observation. Identifies texture, nuance, and direct community voice. Small Listening is particularly important for investigating patterns that emerge from Big Listening and for grounding AI-generated findings in lived community experience.

**Big Listening**
Large-scale digital research using online research tools to observe and collect data at scale. Reveals broader patterns across platforms and networks: which narratives are active, which actors are most influential, how narratives flow between communities. The Big Listening Inquiry is the structured research brief handed off to Agent 02b.

Both modes are complementary and run in parallel. Small Listening adds depth and community grounding; Big Listening adds scale and structural pattern recognition. Neither replaces the other.

**Big Listening Inquiry**
The structured handoff document from 02a to 02b. It contains the Research Question and the five parameters. The Research Question carries the hypothesis — the reason the practitioner is listening and what they want to understand. The parameters orient the research: what to look for, who to find, when and where to look, and how to capture it. Simple and sufficient to run the research.

---

## The Listening Model Structure

### Why — Research Question
Derived directly from the Short POV. The single question the listening is designed to answer.

Ask: *Given our POV, what do we most need to understand about this narrative space to design an effective intervention?*

### The Five Parameters

These apply to both Small and Big Listening:

| Parameter | What to define |
|---|---|
| **What** | Specific narrative themes, keywords, frames, or topics to track — including primary themes and secondary themes |
| **Who** | Communities, actors, organisations, or demographics of interest — including voices you expect to find and voices you suspect are absent |
| **When** | Time period for research — and why that timeframe. Are there defining events, political moments, or systems crises that bound the relevant period? |
| **Where** | Platforms, geographic regions, physical or digital spaces — including less visible or harder-to-access spaces where the conversation may be happening differently |
| **How** | Research methods, documentation format, and expected output. What is realistic for the team's capacity? How will data be stored so it can be retrieved and compared later? |

**A note on How:** Documentation discipline matters. The data collected here becomes the knowledge base for all analysis in the Understand phase and for measuring impact in the Evaluate phase. Interviews should be recorded and transcribed. Media sources tracked with links. Observations captured in consistent formats. If data cannot be retrieved and compared later, it cannot anchor any claims of change.

---

## Documentation Questions

Use these to guide the practitioner through designing their Listening Model. Work through them in sequence. In Hacking Mode, ask only for what is genuinely missing.

**Research Question**
- What do you most need to understand about this narrative space to inform your intervention?
- What assumptions does your POV make that need to be tested or validated through research?
- What are you genuinely uncertain about — what might surprise you?

**Parameters — What**
- What narrative themes, topics, or conversations are you tracking?
- What keywords or phrases are most likely to surface the narratives you care about?

**Parameters — Who**
- Which communities, actors, or organisations are active in this narrative space?
- Are there voices you already know about? Voices you suspect are there but haven't found yet?
- Whose voices are likely to be absent from digital data — and how will Small Listening reach them?

**Parameters — When**
- What time period will you research? Why that window?
- Are there specific events, campaigns, political moments, or systems crises that define the relevant period?

**Parameters — Where**
- Where does this narrative live — which platforms, media outlets, physical spaces, or geographic regions?
- Are there spaces where this conversation happens that are less visible or harder to access?

**Parameters — How**
- What research methods are realistic for your team's capacity?
- How will you store and organise what you collect so it can be used later?
- What do you expect this listening to produce?

**Small Listening design support:** If the practitioner needs help designing their Small Listening instruments — interview guides, observation frameworks, survey questions oriented toward narrative listening — load `KB_02a_Listen_SmallListening.md`. This is available on request at any point during the session, including after the Listening Model has been produced.

**Feasibility Check — before producing outputs**
Once the Small Listening design is drafted, confirm with the practitioner before finalising:
- Does the proposed plan match your team's actual capacity — time, access, community relationships, languages?
- Is anything here not realistic? Is anything important missing?

This is a brief alignment moment, not a re-opening of all the parameters. A simple confirmation is enough to proceed.

**Big Listening Inquiry**
- What is the specific research question you want the Big Listening to answer?
- What keywords, actors, platforms, and timeframe should the research focus on?

---

## Iteration Workflow

In a second or later cycle, the practitioner does not rebuild the Listening Model from scratch. They update it based on what the previous hack revealed.

**Iteration is activated when the practitioner provides any of:**
- A Case Study from Agent 05b
- A Post-Hack Evaluation (Output B) from Agent 05b
- A Narrative Strategy or Narrative Objectives from Agent 04

**What stays stable in iteration:**
- The core POV (may be sharpened but is not rebuilt)
- The basic research question structure (focus may sharpen)
- The CSV Database from Agent 02b (extended, not replaced)

**What gets updated in iteration:**
- Research question: refined based on what the hack revealed
- Parameters: new timeframe covering the period since the last cycle; updated keywords reflecting new frames or language observed; new actors or communities identified during the hack; new platforms or spaces revealed by the hack
- Small Listening actions: new methods or communities based on gaps identified in the previous cycle
- Big Listening Inquiry: reproduced with updated research question and parameters

**The iteration input tells the agent what to update:**
- Case Study / Post-Hack Evaluation → update based on what shifted (or didn't) in the narrative space
- Narrative Strategy → update to investigate whether strategic frames are gaining traction
- Narrative Objectives → update to track whether target communities are moving

**On POV refinement in iteration:**
New findings from the hack may sharpen the narrative observation or theory of change. The core collective identity and vision typically remain stable. If the hack revealed that the original POV was misaligned with what was found in the narrative space, this should be flagged to the practitioner and potentially returned to Agent 01 before proceeding.

---

## What Comes Before / After

**Before:** Receives the **Short POV** from Agent 01. If no POV exists, direct the practitioner to Agent 01 before proceeding.

**After:** Passes the **Big Listening Inquiry** to Agent 02b, which executes the large-scale digital research. Small Listening runs in parallel, conducted by the practitioner's team.

**On the cycle:** Listen is the second phase. The baseline established here travels all the way to Agent 05b (Impact & Iteration), where it becomes the reference point for measuring change. A weak baseline produces a weak evaluation.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_02b_Research_Module.md

# KB: Listen Phase — Research
**Agent 02b · CHL AI Agent System**
*Load always — phase scope, key concepts, research process, and the NO INVENTION principle.*

---

## What This Agent Does

Agent 02b receives the Big Listening Inquiry from Agent 02a and executes the large-scale digital research. It also helps the practitioner process and organise Small Listening data collected by their team in parallel. When a project runs on Small Listening only — with no digital research — Agent 02b processes that material directly into the same standardised outputs. All streams produce the same three outputs and pass the same package to Agent 03.

The goal is to produce the structural picture the data reveals. Patterns and initial community impressions emerge during this process — but they are observations, not conclusions. The interpretation, analysis, and mapping belong to Agent 03.

---

## The NO INVENTION Principle

**This is the foundational rule of this agent: do not invent anything.**

Every statement in every output — every pattern named, every community described, every dynamic observed — must have a source. That source must be traceable to a Folio ID in the CSV. If the agent cannot find a source for something it suspects is true, it flags it explicitly as an **unverified pattern** and notes that Small Listening confirmation is needed before it can be treated as a finding.

This rule exists because the Narrative Report becomes the baseline for the entire cycle. Agent 05b will compare the narrative space after the hack against this baseline to measure impact. If the baseline contains invented or unsourced claims, the impact evaluation has no foundation.

When in doubt: cite or flag. Never assume.

---

## Key Concepts

**Narrative Space**
The field of coexisting and interacting narrative forms on a specific topic, within a specific time period. Big Listening maps this space by identifying what is being said, by whom, where, and with what reach.

**Big Listening**
Large-scale digital research using online research tools. Reveals broader patterns across platforms and networks: which narratives are active, which actors are most influential, how narratives flow between communities. Operates at scale — looking for structure, not individual cases. Executed using deep web search and synthesis tools (Exa Search MCP and Claude Research Mode in Claude; equivalents elsewhere — see `KB_02b_Research_Tools.md`).

**Small Listening**
Qualitative research conducted by the practitioner's team: interviews, surveys, manual media analysis, community observation. Identifies texture, nuance, and direct community voice that digital data cannot capture. Agent 02b helps structure Small Listening data into the CSV — but the practitioner must review all Small Listening entries before handoff to Agent 03, because nuance and community-specific meaning in interview data can be lost in AI-assisted processing.

**Nodes**
The basic units of narrative communities in online research — people, publications, groups, or organisations. Identifying which nodes are most active and how they connect to each other is the foundation of the network analysis Agent 03 will do.

**Narrative Community (first draft)**
At this stage, a narrative community is a cluster of actors persistently discussing a specific topic using similar language and frames. The agent identifies 3–5 communities from the data — stating what the data shows about each, not what it means. Formal ANP analysis, language analysis, Justice/Ontology mapping, and Window of Discourse placement all happen in Agent 03. The community picture produced here is explicitly preliminary — it will be confirmed and deepened once Small Listening findings and analytical frameworks are applied.

**Folio ID**
A unique reference code assigned to every entry in the CSV. Format: `[Inquiry Tag]-[Community Initial]-[Number]`. Examples: `BL-H-001` (Big Listening, Hegemonic community, entry 1), `SL-A-003` (Small Listening, Alternative community, entry 3), `BL-C-012` (Big Listening, Catalytic community, entry 12). For entries that cannot yet be assigned to a community, use `BL-U-[number]` (Unassigned). Folio IDs are the audit trail — every claim in the Narrative Report cites the Folio IDs that support it.

---

## Research Process

### Step 1 — Receive and confirm the inquiry
Take in the Big Listening Inquiry from Agent 02a. Before running any research, confirm:
- Is the research question specific enough to orient the search?
- Are keywords defined clearly enough to avoid irrelevant results?
- Is the timeframe bounded with a start and end date?
- Is the geography specified?

If any parameter is vague, ask one focused question. Do not begin on underspecified parameters — unfocused research produces noise, not signal.

### Step 2 — Execute Big Listening
Work through the five parameters systematically using the deep web search and synthesis tools. As sources are retrieved, assign Folio IDs immediately and enter them into the CSV. Do not batch-enter at the end — Folio IDs are assigned as research happens so the audit trail is complete from the start.

The aim is to locate:
- The main actors and nodes active in this narrative space
- The narratives in circulation — what is being said, by whom, with what reach
- How narratives flow and spread across platforms and networks
- Where different clusters of actors are forming
- Patterns and changes over the research timeframe

### Step 3 — Process Small Listening data
If Small Listening material is available, help the practitioner structure it into the CSV:
- Extract claims, observations, and quotes into individual CSV entries
- Assign Folio IDs using `SL-` prefix
- Assign community where visible — or leave as Unassigned (`SL-U-`)
- Flag explicitly where Small Listening confirms, adds to, or contradicts Big Listening findings

Divergences between Big and Small Listening are not problems to smooth over — they are among the most important signals in the data. Note them clearly for Agent 03.

**Important:** The practitioner should review all Small Listening CSV entries before handoff. The agent organises and surfaces — the practitioner verifies meaning and context.

### Step 4 — Identify narrative communities (first draft)
From the accumulated CSV data, identify 3–5 narrative communities. For each, state only what the data shows:
- Working name
- One-line description
- Which actors and nodes cluster together (cite Folio IDs)
- What language and recurring terms they use (cite Folio IDs)
- Where they are most active — platforms, geography
- Initial community type: Hegemonic / Alternative / Catalytic — with brief reasoning based on observed reach and position

State observations only. Do not interpret what the community means, what its strategy is, or how it relates to the POV. That belongs to Agent 03.

### Step 5 — Select ANP Source Library entries
Review the CSV and flag the 5 strongest entries per community as `ANP Source = Yes`. Selection criteria:
- Does this entry clearly illustrate the community's narrative, language, or reach?
- Does it provide evidence useful for Attention, Network, or Power analysis?
- Is it from a credible, traceable source?

Standard is 5 per community. The practitioner can request more at any time — see `KB_02b_Research_Prompting.md`.

### Step 6 — Produce the three outputs
See `KB_02b_Research_Actions.md` for all templates. Produce in order:
1. Narrative Report (Output A)
2. CSV Database confirmation (Output B — already built during research)
3. ANP Source Library (Output C — drawn from `ANP Source = Yes` entries)

### Step 7 — Generate the Handoff Checklist
At the end of the Narrative Report, generate 4–6 specific questions for Agent 03, drawn from what the research actually found. These are not generic — they come from the specific gaps, divergences, and uncertainties in this research. The practitioner answers what they can before passing to Agent 03. Unanswered questions are flagged so Agent 03 knows to address them before starting analysis.

---

## Iteration Workflow

In a second or later cycle, the practitioner provides:
- The existing CSV from the previous cycle
- The existing Narrative Report from the previous cycle
- A new Big Listening Inquiry from Agent 02a with updated parameters

**What the agent does in iteration:**
- Extends the CSV — new entries are added with new Folio IDs, existing entries remain unchanged
- The Inquiry Tag column distinguishes entries from different cycles (e.g. `C1` for cycle 1, `C2` for cycle 2)
- Runs new research with updated parameters
- Produces an updated Narrative Report that includes a **What Has Changed** section — explicitly comparing the current narrative space against the previous cycle's findings
- Re-selects ANP Source Library entries to include new cycle material, flagging which are new

The CSV is the longitudinal record of the narrative space across cycles. It is never replaced — only extended.

## Small Listening-Only Workflow

Some projects run entirely on Small Listening — community interviews, observations, and qualitative research — without any digital Big Listening. This is a valid and complete research path. The outputs are the same; only the source stream changes.

**When this workflow applies:**
- The practitioner submits community research material without a Big Listening Inquiry
- The project's narrative space is primarily offline or relationship-based
- The community being researched has low digital visibility or actively avoids digital platforms
- The practitioner has chosen to prioritise community voice over digital pattern recognition

**What changes:**
- Steps 1 and 2 of the standard workflow (receive inquiry, execute Big Listening) are skipped
- All Folio IDs use the `SL-` prefix
- The Narrative Report omits Sections 2 (Narrative Patterns Timeline from digital data) and notes at the top that findings are based on Small Listening only
- The ANP Source Library is built from Small Listening entries only — the standard of 5 per community still applies

**What stays the same:**
- The CSV structure and all 13 columns
- The Folio ID system
- The community first draft approach — observations only, no interpretation
- The Handoff Checklist for Agent 03
- The NO INVENTION principle — all claims must trace to a Folio ID

**At the end of a Small Listening-only Narrative Report, add a section:**

```
## What Big Listening Could Add

This report is based on Small Listening only. The following gaps could be
addressed by running a Big Listening cycle with Agent 02b:

- [Specific gap — e.g. "Digital reach and platform presence of communities
  identified in interviews is unknown"]
- [Specific gap — e.g. "Whether the narratives observed in interviews are
  also visible at scale in public discourse has not been verified"]
- [Add as relevant to this specific project]

If the practitioner decides to run Big Listening in a future cycle, the existing
CSV can be extended — existing Small Listening entries are retained and new
Big Listening entries are added alongside them.
```

---

## Prior CHL Research

Before running new research, ask the practitioner: has CHL or the Rhizome Fellowship done prior research on this narrative space or Pathway? If so, those sources can be entered into the CSV as `BL-` entries from the prior period, assigned Folio IDs, and referenced in the Narrative Report — giving the research a longer baseline without duplicating work already done.

---

## The Boundary with Agent 03

Agent 02b produces:
- What actors and nodes are present and active
- What language and narratives are in circulation
- Where communities cluster (first draft, data-based)
- What sources support each observation

Agent 03 produces:
- ANP analysis (scored, interpreted)
- Language analysis (frames, metaphors, ideological logic)
- Justice/Ontology mapping
- Window of Discourse assessment
- Strategic conclusions

If a question belongs to Agent 03's territory, note it as an open question for the Handoff Checklist — do not attempt to answer it.

---

*v2.1.0 · updated 2026-10-14 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_03_Understand_Module.md

# KB: Understand Phase — Narrative Communities + Mapper
**Agent 03 · CHL AI Agent System**
*Load always — phase theory, analytical sequence, key concepts, and iteration workflow.*

---

## What This Phase Is

Understand is the third phase of the Culture Hack Method. It transforms the research package from Agent 02b into strategic intelligence about the narrative space.

The phase applies four analytical tools in sequence:

1. **ANP Analysis** — Attention, Network, Power: evidence-based assessment of each community's presence and position in the narrative space, grounded in the ANP Source Library from Agent 02b
2. **Language Analysis** — Frames, metaphors, and ideological logic: the cognitive architecture that organises how each community makes sense of the issue
3. **Community Mapping** — Positioning communities on the Justice/Ontology axes, reviewed and confirmed by the practitioner through the Map Check-in
4. **Window of Discourse** — Identifying which narratives are mainstream, emerging, or marginalised, and where intervention can shift the window

Together these produce the **Community Analysis Report** and the **Narrative Map** — the strategic foundation that Agent 04 builds its strategy on.

---

## What Arrives from Agent 02b

Before beginning analysis, confirm these four inputs are present:

- **Narrative Report** — the landscape summary with community first drafts, patterns, and Folio ID citations
- **CSV Database** — the full source dataset with 13 columns including Folio IDs and ANP Source flags
- **ANP Source Library** — 5+ sourced extracts per community, drawn from the CSV, ready for ANP analysis
- **Handoff Checklist** — 4–6 specific questions from Agent 02b about gaps, divergences, and unclear communities

**Step 0 — Handoff Checklist check:**
Review the Handoff Checklist before starting any analysis. If critical questions are unanswered — particularly about community identification, Big/Small Listening divergences, or missing voices — surface them to the practitioner and resolve before proceeding. Minor gaps can be noted and carried forward into the analysis.

---

## Key Concepts

**Narrative Community**
A group of actors persistently engaged in conversation about a specific topic over time, using shared language, frames, and belief systems. Three types:
- **Hegemonic** — reinforces dominant narratives and existing power structures
- **Alternative** — proposes different stories; exists at the fringes of mainstream
- **Catalytic** — has high potential to drive broader narrative shifts and bridge communities

Note on Cooptation: communities that perform progressive or pluralistic language while their actual practices reinforce systems of oppression are typed as `alternative` in the mapper tool but positioned in the **Injustice + Ontofake** quadrant. They are not a fourth community type — they are a specific and dangerous configuration that requires practitioner knowledge to identify correctly. Automated analysis will almost always misread them as Catalytic or Justice + Onto-shift. See the critical Ontofake note in the Justice/Ontology Map section below.

**ANP Analysis**
Three criteria for assessing narrative communities. Each has a deep-dive structure:

*Attention — volume, reach, and resonance:*
- Content volume: frequency of narrative production over the research timeframe
- Reach: how far narratives travel beyond the immediate community
- Resonance: which themes generate the most activity and sharing
- Temporal patterns: is the community's narrative growing, declining, or stable?
- Comparative: how does this community's attention level compare to others in the space?

*Network — social structure:*
- Key nodes: which actors or organisations are most central
- Density: how tightly connected is the community internally
- Topology: centralised (hub-and-spoke), decentralised (multiple centres), or distributed (flat)
- Bridge actors: who moves between this community and others — these are strategically important
- Information flow: how do ideas spread within and beyond this community

*Power — influence and centrality:*
- Institutional power: media access, economic resources, policy influence
- Cultural power: legitimacy, credibility, symbolic authority — whose framing is treated as common sense
- Network power: coalition capacity, mobilisation ability, ability to bring others into alignment
- Overall power level: High / Medium / Low — with reasoning

Communities with the most attention and network interactions over time have the most power. Power is relative — assess it in comparison to other communities in this space.

**Folio IDs in ANP Analysis**
The ANP Assessment is the evidence-based layer of the analysis. Every claim must cite the Folio IDs from the ANP Source Library that support it. Example: "This community has high institutional power, with consistent placement in mainstream media outlets [BL-H-003, BL-H-007]."

**Language Analysis — Frames and Metaphors**
Systematic analysis of the cognitive architecture of each community's narrative. This is interpretive work — it draws on the research data and practitioner knowledge but involves analytical judgment that goes beyond what can be sourced. Folio IDs are not required in this section.

Three frame questions:
1. *What is inside the frame?* — what is included, made visible, centred
2. *What is outside the frame?* — what is excluded, made invisible, dismissed
3. *How is what's inside constructed?* — how common sense is created; what makes certain ideas feel natural, inevitable, or acceptable, and others unthinkable

Alongside frames, identify:
- **Dominant metaphors** — conceptual mappings that ground abstract ideas in familiar experiences. What does the metaphor make thinkable? What does it foreclose? (e.g. "the economy is a machine" enables efficiency-thinking but disables care-thinking)
- **Ideological logic** — the worldview tying frames together into a coherent system with internal justification

What is absent in the discourse often says more than what is present.

**Justice/Ontology Map**
A two-axis map for positioning narrative communities:
- **Justice axis (X, 0–100):** 0 = Injustice/Individual/Reform end · 100 = Justice/Systemic/Transformative end
- **Ontology axis (Y, 0–100):** 0 = Monoculture/Singular ways of knowing · 100 = Onto-shift/Plural ways of knowing. High = more plural, top of map. Low = more singular, bottom of map.

**Note for the mapper tool:** The current mapper tool inverts the ontology axis (high value = bottom). A tool update is required to match this intuitive convention. Until updated, use the conversion in `KB_03_Understand_Tools.md` when generating JSON coordinates.

Four quadrants:
- **Upper Right (Justice + Onto-shift):** justice > 50, ontology > 50 — systems change + plural ways of knowing. Target direction for culture change.
- **Upper Left (Injustice + Ontofake):** justice < 50, ontology > 50 — structural oppression performing plural/change language. See critical note below.
- **Lower Right (Justice + Reform):** justice > 50, ontology < 50 — structural change through conventional knowledge
- **Lower Left (Injustice + Monoculture):** justice < 50, ontology < 50 — oppression + singular ways of knowing

The axes can be adapted to fit the POV's specific goals — the framework is a tool, not a fixed grid.

**Critical note — Injustice + Ontofake quadrant:**
This is the trickiest quadrant in the map. Ontofake communities use the language of ontological shift — plurality, relationality, Indigenous epistemology, care — while their actual practices and structures keep systems of oppression intact. Cooptation is the mechanism: progressive discourse absorbs and neutralises challenge rather than enabling it.

Automated analysis is structurally biased toward misreading Ontofake communities as Catalytic or Justice + Onto-shift — because the language looks right and the metaphors can look right. Only practitioner knowledge of actual practices, structural effects, and community context reveals the cooptation. This is why the Map Check-in is a co-creation moment, not an automated output.

When analysing a suspected Ontofake community in Language Analysis, apply a specific additional lens: **the gap between discourse and practice.** Ask: What does this community say versus what does it structurally do? Who benefits from the narrative it produces? Does the language of change function to absorb and neutralise dissent rather than enable transformation? Does progressive framing serve to maintain existing power arrangements?

**Acupuncture Points**
Specific communities, actors, moments, or connections in the narrative space where a targeted culture hack could have disproportionate impact — small pressure, significant shift. Named by analogy to acupuncture: the right intervention at the right point in the system produces effects beyond what the scale of the intervention would suggest. Acupuncture Points emerge from the intersection of the ANP analysis (where is there network bridging capacity?), the Language Analysis (where are the frame contradictions or openings?), and the Window of Discourse (what is close to tipping?). They are the most specific and actionable outputs of the Strategic Insights section.

**Window of Discourse**
The Window of Discourse is the range of narratives treated as acceptable in public debate at a given moment. Positioning the narrative space against it shows what is currently common sense, what is gaining ground, and what remains marginal. Three positions:
- **Mainstream/Acceptable** — dominant, treated as common sense
- **Emerging/Contested** — gaining traction, not yet mainstream
- **Radical/Unacceptable** — marginalised, treated as extreme or unthinkable

The window is represented on the Narrative Map as a draggable rectangle with coordinates:
- `left`: X position of the window's left edge (0–100, same as justice axis)
- `top`: Y position of the window's top edge (0–100, same ontology axis — 100 = Onto-shift, top of map)
- `width` and `height`: size of the window as percentage of map

The window is always moving. Social movements, cultural moments, and political crises shift what sits inside or outside it. Identifying where the practitioner's desired reframe currently sits — and what would move the window — is the strategic conclusion of this phase.

---

## The Analytical Sequence

### Step 1 — Confirm Community First Drafts

From the Narrative Report, confirm the community first drafts from Agent 02b. For each community, review:
- Name and description
- Initial type (Hegemonic / Alternative / Catalytic)
- Whether the practitioner agrees with the initial identification

Adjust names, descriptions, or types as needed. If the practitioner identifies that a community is more complex than initially mapped — for example, two distinct sub-communities were grouped together — split it here before proceeding. 3–5 communities is the working range.

### Step 2 — ANP Analysis

For each community, work through the full deep-dive structure. Use the ANP Source Library entries as evidence — cite Folio IDs. Produce an ANP Assessment for each community covering all three dimensions with sub-lenses. Compare communities relatively: which has most attention, most power, most bridging capacity?

Bridge actors are particularly important — identify any actors who appear in multiple communities or move between them. These are strategic nodes for the Recode phase.

### Step 3 — Map Check-in

After ANP, before Language Analysis. This is the single co-creation moment in Agent 03. Load `KB_03_Understand_MapCheck.md`. Present the draft positioning, invite the practitioner to review and adjust. Proceed only after confirmation.

The Map Check-in is the pivot between evidence-based work (ANP) and interpretive work (Language Analysis). The positioning confirmed here feeds directly into the final Narrative Map JSON.

### Step 4 — Language Analysis

For each community, apply the three frame questions. Identify dominant metaphors and what they make thinkable or foreclose. Identify the ideological logic. Note what is absent — what the community doesn't say, what would feel out of place, what is treated as unthinkable.

For any community positioned in the **Injustice + Ontofake** quadrant, apply an additional lens: the gap between discourse and practice. Ask: What does this community say versus what does it structurally do? Who benefits from the narrative it produces? Does the language of change function to absorb and neutralise dissent rather than enable transformation?

*Note at the start of this section in the output: "The following analysis is interpretive — it draws on research data and practitioner knowledge but involves analytical judgment. The practitioner should review this section before passing to Agent 04."*

### Step 5 — Window of Discourse

Assess the current narrative space as a whole. Where does the dominant narrative sit? Where does the practitioner's desired reframe currently sit — Mainstream, Emerging, or Radical? What would move the window? Identify the Catalytic communities already pushing in the desired direction.

Determine the Window of Discourse rectangle coordinates for the Narrative Map — where does mainstream discourse currently sit on the Justice/Ontology axes?

### Step 6 — Strategic Insights + Narrative Intentions

Surface what the analysis points toward. Two layers: Strategic Insights (observations about the narrative space — what is possible, where frame openings exist, where Acupuncture Points are) and Narrative Intentions (options for Agent 04 — possible communities, frames, directions). See the Strategic Insights + Narrative Intentions section below for full guidance.

---

## Strategic Insights + Narrative Intentions

At the end of the Community Analysis Report, surface what the analysis points toward. This section has two layers:

**Strategic Insights** — what the analysis observes about the narrative space: where movement is possible, where frame openings exist, where the window is close to shifting, where Acupuncture Points are located. These are analytical observations, not decisions.

**Narrative Intentions** — possible directions that emerge from the insights: options for which communities to engage, which frames to challenge or amplify, what kind of movement to pursue. These are options, not commitments. Agent 04 turns Narrative Intentions into Narrative Objectives — the committed strategic plan.

The distinction matters: Strategic Insights describe the landscape. Narrative Intentions describe possible moves within it. Narrative Objectives are the decisions made. Agent 03 produces the first two. Agent 04 produces the third.

---

## Iteration Workflow

In a second or later cycle, existing Community Profiles are updated — not rebuilt from scratch.

**What stays stable:**
- Community names (unless the hack revealed a naming problem)
- The basic analytical structure of each profile

**What gets updated:**
- ANP data: new research cycle, new Folio IDs, updated reach/power/network assessment
- Language patterns: new frames or metaphors that emerged during or after the hack
- Justice/Ontology positioning: has any community shifted? Document movement as evidence of change
- Window of Discourse: has the window moved? What is now Emerging that was Radical?
- Community type: has any community shifted from Alternative to Catalytic, or gained/lost influence?

**`[Updated]` markers:**
Any field that changed from the previous cycle gets an `[Updated]` tag with a brief note on what changed and why. Example: `**Attention:** High [Updated — reach increased significantly after the hack period, new actors entering the conversation — BL-C2-H-004]`

**Split communities:**
If the hack revealed that a community is more complex than initially mapped — for example, two distinct sub-communities with different frames and positions — split it into more specific communities that better reflect what was learned. Document the split with a note explaining why.

---

## What Comes Before / After

**Before:** Receives **Narrative Report + CSV Database + ANP Source Library + Handoff Checklist** from Agent 02b.

**After:** Passes **Community Analysis Report + Narrative Map** to Agent 04 (Recode), which uses them to set Narrative Objectives and build the reframe strategy.

**Note on the boundary with Agent 04:** Agent 03 produces analytical observations and surfaces Strategic Insights / Narrative Intentions. Agent 04 sets Narrative Objectives — which communities to target, which frames to challenge/strengthen/introduce, what direction of movement to pursue. This boundary matters: analysis should not be presented as strategy.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_04_Recode_Module.md

# KB: Recode Phase — Theory + Documentation Questions
**Agent 04 · CHL AI Agent System**
*Load always — phase scope, key concepts, documentation questions, iteration workflow.*

---

## What This Phase Is

Recode is the fourth phase of the Culture Hack Method. It is where analysis becomes strategy, and strategy becomes language.

The phase moves through five connected moments:

**Audience + Objectives** — Define who the hack needs to reach and what it aims to shift. These are co-defined: choosing an objective is choosing an audience. Both must be clear before decode/recode work can begin.

**Decode** — Identify a representative message — a paragraph-length text that carries the logic and framing being challenged. Systematically map its hidden structure: verbs, subjects, images, assumptions, logic, ideology, metaphors, framing. Each element reveals a political choice embedded in the language.

**Recode** — Build an alternative narrative using the same analytical lens. Every element is consciously rebuilt to open different imaginaries, guided by the audience and objectives.

**Message** — Translate the recoded narrative into exact language: the specific words, in a specific order, that activate the new frames for the target audience. The message is one to three paragraphs — it may read more like a manifesto than a slogan, and that is correct. This is the full structure of meaning the hack builds on. The meme, slogan, or condensed cultural unit comes later, in Agent 05a.

**Narrative Strategy** — The standalone synthesis. Integrates audience, objectives, and one or more decode/recode analyses into an action plan: short-term actions (what becomes the Hacking Tree) and long-term hypotheses (what could shift in the narrative space). Always checked against the POV — the strategy is a compass reading, not just a plan.

**Stand-alone use:** This phase can also be used independently of the full cycle — for example, to decode/recode a campaign message, test existing communications, or run a workshop exercise. In stand-alone mode, the Narrative Strategy is optional. Only Decode → Recode → Message is required.

---

## Key Concepts

**Audience vs. Narrative Community**
A Narrative Community (from Agent 03) is the analytical unit — a cluster of actors sharing frames and language, positioned on the Justice/Ontology map. The **Audience** is more specific: the particular people within or across communities that the hack needs to reach. A community is an analytical category; an audience is a person you can picture — with an age, a location, habits, feelings, and a relationship to the issue. The same community may contain multiple distinct audience segments. Hack design works at the people level, not the conceptual level.

**Audience Coherence**
A hack cannot speak simultaneously to audiences with incompatible logics, values, or cultural positions. If a practitioner identifies two audiences that would require contradictory messages, they must either choose one or design separate interventions — each with its own decode/recode thread and its own hack actions. The agent should name this as a strategic choice, not a problem to smooth over.

**Audience Objectives + Social Tipping Point**
For each audience, define: what shift is being sought, why this audience has the potential to move, and what their catalytic capacity is. Catalytic capacity is the potential for movement in this audience to ripple outward — into other communities, other conversations, broader narrative change. This connects to the **Social Tipping Point**: the theory that influencing 10–25% of a conversation can create a chain reaction that shifts the whole. Some audiences are strategically important precisely because they sit at this threshold — they are already connected to the right networks and can carry the reframe further than their own numbers suggest. The strategy question is not just "does this audience shift?" but "does their shift activate catalytic capacity that could cascade?" This is not mandatory for every hack, but it is always worth asking — and the answer shapes how the strategy is designed.

**Representative Message**
The specific text chosen for decode/recode. It must be paragraph-length — long enough to contain the logic, framing, and ideological structure being challenged. The message should already be visible in the 02b/03 outputs: a media excerpt, a campaign text, a community quote, a public statement. If the practitioner wants to decode their own existing message, that is a valid use of the same tool. If no clear message has been identified, the agent helps find or construct one before analysis begins.

**Decode**
Systematic analysis of a narrative's linguistic architecture through eight lenses: Verbs · Subjects & Objects · Evoked Images · Hidden Assumptions · Logic · Ideology · Metaphor · Framing. The goal is not to refute the narrative argument by argument — it is to reveal its hidden structure so the recode can work at the same deep level.

**Recode**
The construction of an alternative narrative using the same eight lenses. Every element is consciously rebuilt, guided by the audience and objectives. The recode is not a mirror inversion of the decode — it is a new construction built from different foundations, shaped by who it needs to reach and what shift it aims to produce.

**Narrative Objectives**
Specific goals for what the intervention aims to shift — framed around audiences, frames, and direction of movement. They include:
- Which audiences to engage and why
- What direction of movement is sought on the Justice/Ontology map
- Which frames to challenge, strengthen, or introduce
- Where the recoded narrative sits in the Window of Discourse and where it aims to move

**Narrative Strategy**
The standalone action plan that emerges from all the work above. It has two layers:
- **Short-term:** the specific intervention to develop in Agent 05a (the first hack)
- **Long-term:** iteration hypotheses — what could shift over time in language, attention, network, or power

The strategy should also surface the **implied effects** of the objectives: if this hack works, what would be visible? The practitioner may have a clear hypothesis, or may hold it open as an observation-based approach (like an A/B test). Both are valid. The agent helps formulate the effects rather than demanding certainty.

---

## The Eight Lenses (Decode + Recode)

| Element | Question |
|---------|----------|
| **Verbs — Actions** | What actions are present? Who acts, who is acted upon? What actions are made invisible? |
| **Subjects & Objects — Actors** | Who has agency? Who is absent? What power dynamics are encoded in who does what to whom? |
| **Evoked Images** | What mental pictures, sensory associations, and emotional resonances does this language produce? |
| **Hidden Assumptions** | What must already be believed for this message to make sense? What questions are not allowed? |
| **Logic — Truth Claims** | What is stated as fact? What causal logic is embedded? What counts as evidence? |
| **Ideology — Worldview** | What larger belief system does this serve? What future does it imply? What does it protect? |
| **Metaphor** | What is the primary metaphor? What does it make thinkable — and what does it foreclose? |
| **Framing — Point of View** | Whose perspective is centred? What is inside the frame and what is outside? Whose interests does this serve? After the analysis, distil the whole into one sentence that captures the coherent worldview — e.g. *"economic growth is more important than life"* or *"development is civilisation."* For the recode, produce the reverse synthesis — e.g. *"life is more important than money"* or *"the future is a territory to defend."* This distilled frame is the most actionable output of the analysis. |

---

## Documentation Questions

**On audience and objectives**
- Who exactly is the hack trying to reach? Describe them as people — not just a category.
- What is the relationship between the practitioner and this audience? What access or connection already exists?
- What shift are you seeking in this audience? What does movement look like for them?
- What is the catalytic potential of this audience — if they shift, what else could move?
- If you have named more than one audience: are these coherent? Do they require the same message, or different ones?

**On finding the representative message**
- Looking at the 02b/03 outputs: is there a quote, excerpt, or text that captures the dominant narrative being challenged?
- Does this text contain the logic, framing, and assumptions you want to work against?
- Is it paragraph-length — specific enough to analyse, not just a single phrase?
- If you are decoding your own existing message: what prompted this, and what do you suspect it might be doing unintentionally?

**On Decode**
- Walk through the eight lenses: what do you find in each?
- What does this narrative make invisible? What does it make seem natural or inevitable?
- What ideology does it serve, and what future does it foreclose?
- Which lens reveals the most important strategic insight?

**On Recode**
- For each element: what changes, why, and what effect is intended?
- What new frames and metaphors are being activated?
- Is the recode building from the audience's own language and cultural references?
- What is the exact message — the specific words that carry this reframe?

**On Narrative Strategy**
- What is the short-term action this strategy leads to? What gets handed to Agent 05a?
- If there is more than one decode/recode: how do they integrate into one strategy?
- What are the long-term hypotheses? What could shift in attention, network, power, or language if this works?
- Are these hypotheses specific, or held open for observation? Either is valid — name which.
- What does the practitioner need to see in Agent 05b's evaluation to know this strategy is working?

---

## What Comes Before / After

**Before:** Receives **Community Analysis Report + Narrative Map + Window of Discourse assessment** from Agent 03. The community map — including quadrant positions, Catalytic community identifications, and Window of Discourse placement — is the strategic foundation for setting audience, objectives, and building the reframe.

**After:** Passes **Narrative Strategy + Recoded Narrative (with Message)** — and optionally **Audience Profile(s)** — to **Agent 05a (Hacking Tree)**, which translates the message into a concrete cultural intervention.

**On iteration:** In a second or later cycle, the Recode is revised based on what the hack revealed. New community insights may shift target audiences, frame priorities, or the message itself. The POV may also be sharpened here. The strategy's long-term hypotheses are tested against what Agent 05b found and updated accordingly.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05a_Hack_Module.md

# KB: Hack Phase — Hacking Tree + Logistics
**Agent 05a · CHL AI Agent System**
*Load always — phase scope, key concepts, documentation questions, stand-alone mode, before/after.*

---

## What This Phase Is

Hack is the fifth phase of the Culture Hack Method. It is where the recoded narrative becomes a concrete cultural intervention — something that actually exists in the world and reaches an audience.

The phase works through two layers:

**The Hacking Tree** — four creative branches that translate the message into a cultural unit and design its delivery: Media (what format), Meme (what cultural unit), Tone (what emotions), and Hack (what space, scale, and moment).

**Logistics** — the practical plan that makes the hack real: timeline, team, capacities, budget, documentation, and monitoring.

**On creativity:** This phase is a co-creative moment. The agent helps brainstorm, structure, and sharpen — but the best hacks carry a human creative touch that no tool can produce alone. The practitioner should feel free to bring in artists, designers, or community members at any point in this phase. The Hacking Tree can serve as a creative brief handed to collaborators, or as a script for the practitioner's own creative process.

**On prototyping:** Culture hacking is iterative by nature. The goal is not a perfect intervention — it is a good-enough one that can be launched, learned from, and improved. A hack that ships and fails teaches more than one that never launches. Build in enough to start; the next cycle will sharpen it.

**Stand-alone use:** This phase can be used independently of the full cycle — for example, to design a campaign action, a workshop, or a one-off intervention. In stand-alone mode, the agent collects a light Audience Profile before proceeding. "The general public" is not a valid audience — the hack must be designed for specific people.

---

## Key Concepts

**The Hacking Tree**
The structured creative design of the intervention. Four branches, each with three sub-elements, each building on the previous. Together they answer: how does the message become an action in the world?

**Media**
The format and platform that carries the message to the audience. The best media is the one the audience already uses, understands, and shares — TikTok, hip hop, slam poetry, murals, food rituals, theatre, op-eds, billboards. Media choice is driven by audience habits, cultural ground, and the team's production capacity.

The Media branch has three sub-elements:
- **Audiences** — who specifically the hack reaches (one or more from Agent 04, or built in stand-alone mode)
- **Intersections** — the shared cultural ground between audience segments: the platforms they both use, the references they share, the aesthetic they both respond to. This is what makes a format choice strategic rather than arbitrary.
- **Format** — the specific medium chosen, with reasoning: why this format fits this audience, and whether the team can produce it

**Meme**
The message distilled into a simple cultural unit that can jump from mind to mind — something people can instantly grasp, share, and make their own. The meme is the vessel; the message from Agent 04 is the cargo. A hashtag, slogan, image, or gesture carries the full logic of the recoded narrative without stating it. That is the memetic power: the whole worldview travels inside a single shareable unit.

The Meme branch has three sub-elements:
- **Symbols** — existing cultural objects already in circulation that carry emotional or cultural weight for the audience
- **Associations** — remixing what those symbols mean: from their current association to the new one that activates the recoded frames
- **Synthesis** — the exact cultural unit: the hashtag, slogan, image, gesture, or phrase that carries the message in condensed, spreadable form

**Stickiness test (SUCCESs):** Simple · Unexpected · Concrete · Credible · Emotional · Story

**Tone**
The emotions evoked through the message and spread in the conversation. Just as films use sound, colour, and rhythm to shape feeling, the hack intentionally evokes specific sentiments. Tone is not decoration — it is strategy. Emotion leads to agency, not just feeling.

The Tone branch has three sub-elements:
- **Mood** — the current emotional climate of the narrative space and the target audience
- **Feelings** — the emotions the hack aims to generate, and the emotional journey from where the audience is now to where the hack wants to take them
- **Stimuli** — the specific creative tools (visual, sonic, linguistic, physical) that produce those feelings

Tone must be empowering and authentic. The test: does the emotion lead to action and agency, or does it trap people in feeling?

**Hack: Space, Scale, Moment**
The three dimensions of where, how big, and when:

- **Space** — where to intervene: physical public space, community space, virtual platform, institutional space, or hybrid. Space choice carries symbolic meaning. The Point of Intervention framework helps identify leverage: production, destruction, consumption, decision, assumption, or potential.
- **Scale** — the realistic reach: Micro (under 100), Meso (100–10,000), Macro (10k–1M), Mega (1M+). Scale must match the narrative ambition and the team's actual capacity.
- **Moment** — the political timing that maximises impact: planned timing, event-responsive timing (catching a crisis, movement surge, or cultural moment), or cyclical timing (commemorations, ecological cycles, political rhythms). The key question: is there a wave to catch?

**Logistics**
The practical infrastructure that lets the hack actually happen. Two tracks are available:
- **Lean logistics** — for teams that need speed: timeline essentials, roles, minimum budget, and a documentation baseline
- **Full logistics** — for teams that need depth: detailed timeline with phases, full team roles, capacity assessment, budget breakdown (minimum viable through optimal), documentation plan, and monitoring with response protocols

Logistics is a reality check: can the team actually do this? Ambition is good; overcommitment kills hacks. The logistics plan should be honest.

---

## Stand-alone Audience Profile (light)

When arriving without Agent 04 outputs, collect the following before starting the Hacking Tree:

**Essential (required):**
- Age, gender, location, political stance
- Narrative objective: what shift is being sought with this audience?

**Optional (deepen when relevant):**
- What do they hear about this issue?
- What do they see in daily life?
- What do they say about the topic?
- What do they think/feel (logics, values, feelings)?
- What do they do (actions related to the issue)?

"The general public" is not a valid audience. If the practitioner cannot describe their audience as specific people, the agent should help them narrow before proceeding.

---

## Documentation Questions

**On audience and media**
- Who exactly is the hack reaching? Are these the same audiences from Agent 04, or have they shifted?
- What do both/all audience segments have in common — platforms, aesthetics, cultural references, shared experiences?
- What format fits this audience and is within the team's real production capacity?

**On meme**
- What symbols are already active in the audience's world? Which carry emotional weight?
- What does the chosen symbol currently mean, and what do you want it to mean instead?
- What is the exact cultural unit — the hashtag, slogan, image, or gesture? Say it in one line.
- Does it pass the stickiness test: is it simple, unexpected, concrete, credible, emotional, story-like?

**On tone**
- What is the dominant emotional mood of the narrative space right now? What is your audience feeling?
- What feelings do you want to generate — and what is the journey from where they are to there?
- What specific creative tools (colours, rhythm, imagery, word register, music, physical movement) produce those feelings?
- Is the emotion empowering? Does it lead to agency?

**On space, scale, moment**
- Where are you intervening — and why does that space create leverage?
- What point of intervention is this: production, destruction, consumption, decision, assumption, or potential?
- What is the realistic scale — primary and secondary reach?
- Is there a wave to catch — a political crisis, movement surge, anniversary, or cultural moment? If so, when is it cresting?

**On logistics**
- What is the honest timeline from development through launch to evaluation?
- Who does what? Are there gaps in the team?
- What can the team do in-house? What needs to be sourced externally?
- What is the minimum viable budget — and what is secured?
- What needs to be documented before, during, and after — and how?

---

## What Comes Before / After

**Before:** Receives **Narrative Strategy + Recoded Narrative (with Message) + Audience Profile(s)** from Agent 04. The message, target audience, and strategy objectives are all direct inputs to the Hacking Tree design.

**After:** Passes the **Hacking Tree + Logistics Plan** to Agent 05b (Impact & Iteration). The full documentation package — baseline from Agents 02b and 03, narrative strategy from Agent 04, and the monitoring plan from this phase — travels with it.

**On iteration:** Hacks are iterative. Some things work and some don't. The logistics plan includes a documentation and monitoring layer precisely so that what is learned feeds the next cycle. After evaluation, the practitioner may return to Agent 02a to update the Listening Model, or to Agent 04 to revise the narrative strategy.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05b_Impact_Module.md

# KB: Impact & Iteration — Theory + Documentation Questions
**Agent 05b · CHL AI Agent System**
*Load always — phase scope, evaluation theory, reflection questions, iteration logic.*

---

## What This Phase Is

Impact & Iteration is the closing and opening of the cycle. It answers the central question: *is the narrative space being rewilded?*

It is nested within the Hack phase — not a separate endpoint. The cycle runs: launch → monitor → evaluate → adapt → relaunch. Each turn of the cycle sharpens the strategy and increases the chances of the hack shifting the narrative space.

This phase has four outputs that serve different purposes and different moments. None of them blocks the others. Output B alone is enough to keep hacking.

**On prototyping:** Think of early hacks as prototypes. They won't be perfect — they grow through experiments. A/B testing (running two versions and comparing outcomes) is a valid evaluation approach. Both versions count as part of the same hack and generate learning. Document both; compare what worked.

**On the three closing questions:** Every evaluation — whether a quick Output B or a full case study — closes with three personal reflection questions:
- What are the implications of this work for me personally?
- What are the implications of this work for my community?
- What are the implications of this work for the planet?

These are human co-creation moments, not data fields. The agent can generate in-depth questions drawn from the hack's specific context to help the practitioner arrive at their own answers — but the answers must come from the practitioner. They can be data-informed (grounded in what the evaluation found) or purely personal. Both are valid.

---

## The Three Levels of Evaluation

### Level 1 — Audience Impact
*Timescale: weeks to months. The hack reached specific people and provoked specific responses.*

**Reach** — how many people in the target audience saw or encountered the hack?
**Response** — did it spark the emotions and reactions intended? Quantitative (engagement metrics) and qualitative (what people said and did).
**Adoption** — are target audiences using the new frames, language, or behaviours? Short-term (0–3 months): early uptake. Medium-term (3–6 months): integration. Long-term (6+ months): cultural embedding.

For A/B testing: compare reach, response, and adoption across versions. Document what distinguished the higher-performing version.

### Level 2 — Discourse Impact
*Timescale: months. The narrative space itself is shifting.*

Narrative shifts happen when the audience not only receives the reframe but integrates and repeats it — when the narrative becomes not only *known* but *owned*.

Measure against the ANP baseline from Agent 03:
**Attention** — did the hack draw focus? Are the recoded frames appearing more frequently? Are the frames being challenged losing traction?
**Network** — are new connections forming between previously separate actors, platforms, or communities? Are bridge actors emerging?
**Power** — is there stronger coherence around the reframed logic? Are the frames gaining authority and legitimacy? Where does the recoded narrative now sit in the Window of Discourse?

To evaluate discourse shifts, return to the Listen phase (Agent 02b): run a new research cycle with updated parameters and compare to the baseline.

### Level 3 — Systems Change Contribution
*Timescale: years. The hack is contributing to tipping point conditions.*

A tipping point is reached when:
- **Attention convergence** — enough people are shifting focus toward the recoded frames (10–25% adoption signal)
- **Network intertwining** — disparate actors and platforms begin to connect; networks converge and multiply discourse force
- **Power realignment** — the reframe becomes common sense; a catalytic community moves from fringe to mainstream; narrative change starts to restructure politics, culture, and material life

No single hack produces a tipping point. The question is whether it is contributing to the conditions for one. Assess early signals honestly. A realistic horizon matters more than aspirational claims.

---

## Documentation Questions

**On baseline and readiness (for Output A)**
- Is the baseline from the Listen/Understand phases accessible and documented?
- Are the narrative objectives from Agent 04 specific enough to evaluate against?
- What does the target audience currently look like — before the hack?
- What monitoring is in place for during and after launch?

**On audience impact (for Output B)**
- How far did the hack travel? Who saw it, and where?
- How did the target audience respond — quantitatively and qualitatively?
- Were there unexpected reactions — positive or negative?
- Are there early signs that the new frames or language are being adopted?
- If A/B testing: which version performed better, and what explains the difference?

**On discourse impact (for Output B)**
- Comparing against the ANP baseline: what has changed in attention, network, and power?
- Are the frames being challenged losing traction? Are the recoded frames appearing more frequently?
- Has the Window of Discourse position of the recoded narrative shifted at all?
- Are there new connections between communities that didn't exist before?

**On systems change (for Output B)**
- What early signals of broader shift are visible — even small ones?
- How does this hack connect to other movements or narratives working in the same space?
- What is this hack contributing to in terms of longer-term tipping point conditions?

**On the three closing questions (for Output B, C, and D)**
- What are the implications of this work for you personally?
- What are the implications of this work for your community?
- What are the implications of this work for the planet?

*If the practitioner is unsure, the agent draws on the specific hack context — who was reached, what shifted, what the POV pointed toward — and generates targeted questions to help them arrive at their own answers.*

**On learnings and iteration (for Output B)**
- What worked? What didn't? What surprised you?
- What would you do differently in the next hack?
- What does the next cycle need — updated research, revised strategy, different timing, different audience?

---

## Iteration Logic

After evaluation, the cycle continues. Output B includes an explicit iteration strategy: based on what the evaluation found, which phase needs updating and which agent handles it.

| What the evaluation found | Where to go | What to do |
|---------------------------|-------------|------------|
| Audience didn't shift as expected | Agent 04 | Revise message, recode, or audience targeting |
| Research baseline was too thin | Agent 02a → 02b | Update Listening Model, run new research |
| Community map needs updating | Agent 03 | Update community profiles with new data |
| Hack design didn't land | Agent 05a | Redesign Hacking Tree — different media, meme, tone, space, or moment |
| Strategy was misaligned with POV | Agent 01 → 04 | Refine POV, then revise narrative strategy |
| Strong early signals — amplify | Agent 05a | Design next hack building on what worked |

The practitioner does not restart at Agent 01. The POV is refined, not rebuilt. Community profiles are updated, not rediscovered. Each cycle deepens the practice.

---

## What Comes Before / After

**Before:** Receives the **Hacking Tree + Logistics Plan** from Agent 05a, plus all prior documentation: baseline from Agents 02b and 03, narrative strategy and hypotheses from Agent 04, POV from Agent 01.

**After:** Output B feeds back into any phase agent to activate iteration. Output C becomes the persistent institutional record. Output D becomes movement knowledge — publishable and shareable.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
