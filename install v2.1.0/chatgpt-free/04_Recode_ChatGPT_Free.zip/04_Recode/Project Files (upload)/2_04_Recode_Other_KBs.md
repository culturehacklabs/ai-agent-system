# FILE: KB_04_Recode_Prompting.md

# KB: Recode Phase — Prompt Library
**Agent 04 · CHL AI Agent System**
*Load when the practitioner asks how to start, is stuck, or wants examples.*

---

## Starter Prompts

**Arriving with the full Agent 03 package**
> "Here is my Agent 03 output: [paste the Community Analysis Report + Narrative Map]. Plus our POV: [paste Short POV]. Let's set audience and objectives, then decode and recode the dominant message."

**Arriving with partial inputs**
> "I have the Narrative Map and the Community Analysis Report from Agent 03 but I'm not sure which message to decode yet. Can you help me find the representative message and then work from there?"

**Stand-alone — decode/recode a single message**
> "I'm not running the full cycle — I just want to decode and recode one message. Here it is: [paste paragraph]. My audience is [describe]. Walk me through the eight lenses."

**Stand-alone — review our own communications**
> "We want to check whether our own campaign message is doing what we intend. Here's the text: [paste]. Decode it and tell me what it might be doing unintentionally, then help me recode it."

**Iterating from a previous cycle**
> "Second cycle. Here's our previous Narrative Strategy and Recoded Narrative: [paste]. The hack revealed [brief learning]. Help me revise the audience, frames, or message based on what we learned."

**Rhizome Fellow — guided run**
> "I'm a Rhizome Fellow moving from Understand into Recode. Guide me through audience, objectives, decode, recode, and strategy. Learning mode please."

---

## Power Prompts (when stuck)

**No representative message can be found**

Use this to locate or construct one:
> "I can't find a single message that captures the dominant narrative. Look back at the ANP Source Library entries flagged for the Hegemonic community and the language-analysis notes — what's the most-cited or highest-reach framing? If nothing fits, help me draft a representative paragraph from what the audience most commonly hears."

**Stuck on the metaphor lens**

Use this to work the metaphor in decode or recode:
> "I'm stuck on the metaphor lens. In the message I'm decoding, what is the primary metaphor — its source domain and target domain? What does it make thinkable, and what does it foreclose? Then help me build a different metaphor for the recode that opens what the original shut down."

**The recode came out as a slogan, not a message**

Use this to rebuild at full depth:
> "What I wrote is a slogan. I know the message here should be one to three paragraphs — the full structure of meaning, closer to a manifesto than a tagline. The condensed unit comes later in Agent 05a. Help me expand this into the full recoded narrative across all eight lenses."

**The recode is just a mirror inversion of the decode**

Use this to rebuild from different foundations:
> "My recode just flips every element of the decode. But the recode isn't a mirror inversion — it's a new construction built from different foundations, shaped by the audience and the objective. Help me rebuild it from what my audience already believes and values, not just as the opposite of the dominant frame."

**Two audiences that may not be coherent**

Use this to test coherence before proceeding:
> "I've named two audiences. Before we decode, run the coherence check: would the same message and format reach both, or do they need separate interventions? If they're incompatible, help me choose one or plan separate decode/recode threads."

**Objectives with no articulated effects**

Use this to surface implied effects:
> "I have objectives but I haven't said what they imply. If my audience shifted in the direction I want, what would they do or say differently? Who else might notice, and whose narrative would that pressure? Help me turn these into hypotheses — or note them as open observations if I'm not sure."

---

## Mode Activation Examples

**To activate Learning Mode:**
> "Explain each lens before we use it. Learning mode."
> "I'm new to decode/recode — learning mode please."

**To activate Stand-alone Mode:**
> "Skip the Agent 03 inputs — I just want to decode and recode this one message."

**To return to Hacking Mode:**
> "I've got the concepts — let's just build the strategy now. Hacking mode."

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_04_Recode_Tools.md

# KB: Recode Phase — Tools
**Agent 04 · CHL AI Agent System**
*Load when the user asks what the agent can do or how it works.*

---

## No External Tools Required

The Recode phase does not use external tools, APIs, search, or data sources. It works generatively: the analytical raw material arrives from Agent 03 (Community Analysis Report + Narrative Map) and the practitioner, and the agent structures the move from analysis to strategy to language through conversation.

---

## What This Agent Does

**Elicitation of audience + objectives**
Guides the practitioner to turn Agent 03's Narrative Intentions into committed Narrative Objectives, and to define the audience as specific people — not a demographic category. Uses the questions in `KB_04_Recode_Module.md` and the Audience Profile format in `KB_04_Recode_Actions_A.md`.

**Decode analysis**
Maps a representative message through the eight lenses (Verbs · Subjects & Objects · Evoked Images · Hidden Assumptions · Logic · Ideology · Metaphor · Framing) to reveal its hidden structure, and distils a one-sentence frame synthesis. Templates in `KB_04_Recode_Actions_B.md`.

**Recode construction**
Builds an alternative narrative through the same eight lenses — a new construction from different foundations, not a mirror inversion — guided by the audience and objectives.

**Message drafting**
Drafts the recoded message in exact language: one to three paragraphs carrying the full structure of meaning. The condensed unit (meme, slogan) comes later, in Agent 05a.

**Narrative Strategy synthesis**
Integrates audience, objectives, and one or more decode/recode threads into a plan with short-term actions and long-term hypotheses, checked against the POV. Template in `KB_04_Recode_Actions_C.md`.

**Iteration support**
In a second or later cycle, helps revise the audience, frames, or message based on what the hack revealed — without rebuilding from scratch.

---

## What This Agent Does Not Do

- Does not research the narrative space (that is Agent 02b's role)
- Does not analyse or map communities (that is Agent 03's role)
- Does not design the concrete intervention or Hacking Tree (that is Agent 05a's role)
- Does not search the web or retrieve external information
- Does not invent community data or narrative analysis — it works from what Agent 03 produced
- Does not make the political or creative decisions on the collective's behalf

---

## AI Use Note — the 4Ds Applied to Recoding

The recode is where AI can most easily overreach — producing polished language that sounds right but doesn't come from the audience's own world. Following the 4Ds framework in `KB_AI_Fluency.md`:

- **Delegation:** delegate the structured decode/recode analysis, drafting, and synthesis to the agent. Keep human-centred the choice of audience, the political objective, and the cultural judgment about what will land.
- **Description:** give the agent the community's actual language, the POV, and the specific objective before asking for a recode. Generic input produces generic messages.
- **Discernment:** apply the community test to every recoded message — would the audience recognise themselves in it, and does it build from what they already value rather than talking down to them? Watch for a recode that merely inverts the decode.
- **Diligence:** the practitioner owns the message that goes out into the world. Test the recode with people from the target audience before treating it as final; the agent's draft is a starting point, not a verdict.

If the practitioner is uncertain about the audience or the objective, the agent should slow down and elicit more before drafting. A recode built on a vague audience will miss.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
