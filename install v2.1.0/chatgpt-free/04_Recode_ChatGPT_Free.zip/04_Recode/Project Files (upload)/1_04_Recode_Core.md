# FILE: KB_04_Recode_Actions_A.md

# KB: Recode — Actions A: Audience Profile
**Agent 04 · CHL AI Agent System**
*Load when defining the audience or producing an Audience Profile.*

---

## What This Output Is

The Audience Profile translates the analytical community picture from Agent 03 into a concrete portrait of the people the hack needs to reach. It describes the audience as specific people — not a demographic category, not a community label. The profile should be concrete enough that the practitioner can picture a real person: where they live, what they hear about this issue, what they feel but don't say, what they do.

This specificity is what makes creative and strategic decisions possible. A hack is designed for people, not for concepts.

It is an **optional but recommended output** — particularly useful when:
- The audience is not yet clearly defined
- The practitioner is designing a creative intervention and needs to feel who they are talking to
- Multiple audience segments need to be distinguished before decode/recode begins

A profile is produced per audience segment. If two profiles are produced, the agent should check for coherence before proceeding to decode/recode.

---

## Audience Coherence Check

Before producing profiles or proceeding to decode, confirm:

- Do both audiences share enough common ground to be reached by a single message and hack?
- Or do they require different messages, different formats, different moments?

**If incompatible:** The practitioner must choose one audience for this hack, or plan two separate interventions — each with its own decode/recode and its own entry in the Narrative Strategy. Name this clearly. It is not a failure — it is strategic clarity.

**Coherence test questions:**
- Would the same message resonate with both audiences?
- Would the same media format reach both?
- Would the emotional tone required for one alienate the other?
- Are these audiences part of the same community network, or in different worlds?

---

## Audience Profile Template

```
## Audience Profile: [Name or descriptor]

**Community of origin:** [Which narrative community from Agent 03 does this audience sit within — or between?]
**Relationship to practitioner:** [How does the collective have access to or connection with this audience?]
**Catalytic potential:** [If this audience shifts, what else could move? Who do they influence?]

### Who They Are
- Age range: [approximate]
- Location: [geographic or platform context]
- Gender / identity markers: [relevant dimensions]
- Social/political position: [brief description]
- Relationship to the issue: [how close or distant are they to the narrative space being hacked?]

### What They Hear
[What narratives, messages, or frames does this audience regularly encounter about the topic?
What are they told — by media, institutions, community, family?
This is where the dominant narrative lives for them.]

### What They See
[What does their daily environment show them about this topic?
What images, symbols, behaviours, and conditions are visible in their world?]

### What They Say
[How do they talk about this topic publicly — with peers, on platforms, in community spaces?
What language do they use? What do they name and what do they not name?]

### What They Think and Feel
[What do they privately believe or feel about the topic?
What logics, values, emotions, and tensions live beneath the surface?
What is the gap (if any) between what they say and what they feel?]

### What They Do
[What actions do they currently take — or not take — in relation to this topic?
What behaviours, practices, or habits are relevant?]

---

### Strategic Implications
- **Entry point:** [What in the above creates an opening for the hack?]
- **Tension to work with:** [What gap, contradiction, or felt need can the recode address?]
- **Language to use:** [What words, references, and registers will reach them?]
- **Language to avoid:** [What framing would close them down or alienate them?]
- **Objective for this audience:** [What shift is being sought — and what does movement look like?]
```

---

## Multiple Profiles

If two audience profiles are produced, add a synthesis block after both:

```
## Audience Coherence Assessment

**Shared ground:** [What do both audiences have in common — values, concerns, cultural references?]
**Key differences:** [Where do they diverge in language, logic, or cultural position?]
**Conclusion:**
[ ] Single hack can serve both audiences — proceed with one decode/recode
[ ] Audiences require different interventions — plan separate decode/recode threads and note in Strategy
**Reasoning:** [Brief explanation of the conclusion]
```

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_04_Recode_Actions_B.md

# KB: Recode — Actions B: Decode & Recode
**Agent 04 · CHL AI Agent System**
*Load when the practitioner is ready to decode a message or build the recode.*

---

## Step 1 — Select the Representative Message

Before any analysis begins, the practitioner must identify a specific paragraph-length message to decode.

**What makes a good representative message:**
- It is a real text — not a summary or paraphrase of a narrative
- It is paragraph-length: enough to contain logic, framing, and ideological structure
- It exemplifies the dominant narrative the hack is working against
- It is already visible in the 02b/03 outputs: a media excerpt, a campaign statement, a public speech, a community quote

**Where to look:**
- The CSV Database from Agent 02b (content samples column)
- The ANP Source Library entries flagged for the Hegemonic community
- Language analysis notes from Agent 03 on dominant frames

**If the practitioner is decoding their own existing message:**
- Identify the specific text (a communication, a campaign message, a fundraising ask)
- Note what prompted the review — what do they suspect it might be doing unintentionally?

**If no message has been identified:**
The agent should help the practitioner:
1. Return to the 02b/03 outputs and look for the most-cited or most-reach framing from the Hegemonic community
2. If none is there, ask: what is the single most common thing the target audience *hears* about this topic? Draft a representative paragraph together.

---

## Decode Template

```
## Decode: [Title or short description of the message]

**Message (full text):**
"[exact paragraph — reproduced in full]"

**Source:** [media outlet / campaign / platform / own message]
**Date/period:** [when this was in circulation]
**Why representative:** [why this text exemplifies the narrative being challenged]
**Prevalence:** [how dominant or widespread this narrative is]
**From 02b/03 outputs:** [Folio ID or reference if applicable]

---

### Analysis

| Element | What it does | Strategic implication |
|---------|-------------|----------------------|
| **Verbs — Actions** | [What actions are present? Who acts, who is acted upon? What is made invisible?] | [What this reveals about power and agency] |
| **Subjects & Objects — Actors** | [Who has agency? Who is absent? What power dynamics are encoded?] | [What this reveals about whose interests are served] |
| **Evoked Images** | [What mental pictures, sensory associations, emotional resonances?] | [What world this constructs and what it makes feel natural] |
| **Hidden Assumptions** | [What must already be believed for this to make sense? What is not allowed?] | [What alternatives are made unthinkable] |
| **Logic — Truth Claims** | [What is stated as fact? What causal logic? What counts as evidence?] | [What must be accepted as true to receive this message] |
| **Ideology — Worldview** | [What larger belief system? What future implied? What protected?] | [What politics are embedded] |
| **Metaphor** | [Primary metaphor: source domain → target domain. What does it make thinkable? What does it foreclose?] | [What actions this metaphor enables or blocks] |
| **Framing — Point of View** | [Whose perspective centred? What inside/outside the frame? Whose interests served?] | [What the frame makes visible vs. invisible] |
| **Frame Synthesis** | [One sentence that distils the whole coherent worldview — e.g. *"economic growth is more important than life"* or *"development is civilisation."*] | [This is the most actionable output of the framing analysis — carry it directly into the Recode] |

---

### Decode Summary
**Core mechanism:** [In 2–3 sentences: what is this narrative fundamentally doing? What is its most important hidden move?]
**Frame Synthesis (restated):** [The one-sentence distillation from the Framing row above]
**Primary target for recode:** [Which 1–2 elements are most important to transform, and why?]
```

---

## Recode Template

```
## Recode: [Title — relates to the decode it responds to]

**Reframed Message (full text):**
"[The recoded narrative in exact language — one to three paragraphs. This may read more like a manifesto than a slogan. That is correct. The meme, slogan, or condensed cultural unit comes in Agent 05a. Here the goal is the full structure of meaning.]"

**Target Audience:** [name the audience profile this is for — links to Actions A]
**Objectives served:** [which narrative objectives from the strategy does this message address?]
**Strategic intent:** [what shift in the narrative space does this aim to produce?]

---

### Transformation Analysis

| Element | What changed | Why | Intended effect |
|---------|-------------|-----|----------------|
| **Verbs — Actions** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Subjects & Objects — Actors** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Evoked Images** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Hidden Assumptions** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Logic — Truth Claims** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Ideology — Worldview** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Metaphor** | [New metaphor: source → target. What it makes thinkable that was foreclosed before.] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Framing — Point of View** | [How your version differs] | [Strategic purpose] | [Effect on audience/narrative space] |
| **Frame Synthesis** | [One sentence that distils the recoded worldview — e.g. *"life is more important than money"* or *"the future is a territory to defend."*] | [This is the reverse of the Decode Frame Synthesis — the new coherent view in one line] | [The frame the whole message carries] |

---

### Message Development
- **Iterations:** [how many versions developed]
- **Testing:** [has this been tested with people from the target audience? What was learned?]
- **Refinements:** [changes made based on feedback, if any]
```

---

## Multiple Decode/Recode Cycles

If the strategy requires engaging more than one audience with different messages, produce one Decode + Recode pair per audience thread. Each pair feeds separately into the Narrative Strategy (Actions C).

Label each thread clearly:
- **Thread 1:** Audience [name] — Decode [source] → Recode [message]
- **Thread 2:** Audience [name] — Decode [source] → Recode [message]

The Strategy integrates all threads into a coherent action plan.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_04_Recode_Actions_C.md

# KB: Recode — Actions C: Narrative Strategy
**Agent 04 · CHL AI Agent System**
*Load when building the Narrative Strategy — the standalone synthesis and action plan.*

---

## What the Narrative Strategy Is

The Narrative Strategy is the synthesis that emerges after audience, objectives, and decode/recode work are complete. It integrates everything into a coherent plan and passes it to Agent 05a.

It has two layers:
- **Short-term:** what gets developed in the Hacking Tree (the immediate intervention)
- **Long-term:** iteration hypotheses — what could shift over time in language, attention, network, or power

It also surfaces the **implied effects** of the objectives: if this strategy works, what would be visible in the narrative space? The practitioner may hold these as specific hypotheses or as open observations. Both are valid — the agent's job is to help them articulate what the objectives imply, not to force false certainty.

If multiple decode/recode threads were produced (for different audiences), the Strategy integrates them and assigns each to its own action track.

---

## Narrative Strategy Template

```
## Narrative Strategy

**Collective:** [who]
**POV (restated):** [Short POV — 1–3 sentences. Paste the full POV here.]
**Narrative space:** [what is being hacked]
**Date:** [when this strategy was developed]

---

### POV Alignment Check

*The agent reviews the strategy against the POV and offers an opinion on resonance. The POV is a compass — it can be refined, but it should never be quietly abandoned.*

**Does this strategy advance the theory of change stated in the POV?**
[Agent assessment: yes / partially / tension noted — with brief explanation]

**Where the strategy and POV are aligned:**
[What is clearly serving the vision]

**Where drift or tension exists (if any):**
[Any direction the strategy is taking that diverges from the POV — even subtly]

**Recommendation:**
[ ] Strategy is well-aligned — proceed
[ ] Minor adjustment suggested — [brief note]
[ ] POV may need refinement — [what the strategy has revealed that the POV doesn't fully capture]

*Note: POVs are not written in stone. If the work at this phase has revealed something the original POV didn't account for, this is the moment to note it. A refined POV can be taken back to Agent 01.*

---

### Audiences + Objectives

[For each audience — repeat block]

**Audience:** [name from Audience Profile]
**Community of origin:** [from Agent 03 community map]
**Current position:** Justice [X] · Ontology [Y] · Quadrant [name]
**Desired movement:** [direction on Justice/Ontology map — be specific and realistic]
**Timeframe for movement:** [realistic — incremental movement counts]

**Catalytic capacity:**
[Does this audience have the potential to carry the reframe further than their own numbers? Are they connected to other communities, networks, or platforms that could amplify the shift?]

**Social tipping point question (optional but recommended):**
[Is this audience close to the 10–25% threshold in any conversation or network where they operate? If they shift, could that trigger a cascade? What would that look like?]

---

### Frame Transformation

**Frames to challenge:**
1. [Frame name] — [why problematic] — [target audience(s)]
2. [Frame name] — [why problematic] — [target audience(s)]

**Frames to strengthen:**
1. [Frame name] — [why supportive — link to Catalytic communities from Agent 03 where applicable] — [target audience(s)]
2. [Frame name] — [why supportive] — [target audience(s)]

**Frames to introduce:**
1. [Frame name] — [what gap it fills] — [target audience(s)]

---

### Window of Discourse

**Current position of recoded narrative:** [Radical / Emerging / Mainstream]
**Desired movement:** [where to shift — short-term and long-term]
**Strategy for movement:** [how this strategy contributes to shifting the window]

---

### The Message(s)

[One entry per decode/recode thread]

**Thread 1 — Audience [name]:**
**Recoded Narrative (with Message):** "[exact text]"
**Core frame activated:** [the primary new frame this message carries]
**Connection to POV:** [how this message serves the theory of change]

[Repeat for Thread 2 if applicable]

---

### Short-Term Action Plan

**First intervention (→ Agent 05a):**
[What specific hack will this strategy lead to? Describe in 2–4 sentences: who it reaches, what it does, what platform or space it occupies. This becomes the input to the Hacking Tree.]

[If multiple threads/audiences: name a separate intervention for each, or explain how one intervention serves both.]

---

### Long-Term Hypotheses

**What this strategy aims to shift over time:**

**Language:**
[Hypothesis: what new words, phrases, or frames could enter circulation if this works?]
[ ] Specific hypothesis — [state it]
[ ] Open observation — will monitor and assess

**Attention:**
[Hypothesis: what topics or framings could gain or lose traction?]
[ ] Specific hypothesis — [state it]
[ ] Open observation — will monitor and assess

**Network:**
[Hypothesis: what new connections between communities or actors could form?]
[ ] Specific hypothesis — [state it]
[ ] Open observation — will monitor and assess

**Power:**
[Hypothesis: whose narrative could gain or lose reach and legitimacy?]
[ ] Specific hypothesis — [state it]
[ ] Open observation — will monitor and assess

---

### Implied Effects of Objectives

[This section is generated with agent support — the agent helps the practitioner articulate what their objectives imply for the narrative space, even if they haven't stated explicit hypotheses.]

If [audience] moves in the direction of [objective], the following effects are implied:
- In the short term (0–6 months): [what would be visible]
- In the medium term (6–18 months): [what would be visible]
- In the long term (18+ months): [what would be visible]

These implied effects become the baseline hypotheses for Agent 05b (Impact & Iteration) evaluation.

---

### Iteration Signal

**What would confirm this strategy is working:**
[1–3 specific signals the practitioner could observe — in audience behaviour, discourse patterns, or network activity — that would indicate the strategy is on track.]

**What would prompt a strategy revision:**
[1–2 signals that would indicate the approach needs to change — not just the hack, but the strategy itself.]
```

---

## Agent Guidance: Implied Effects

When the practitioner has not articulated hypotheses, help them by working from their objectives:

1. Ask: *"If your audience shifted in the direction you've described — what would you expect them to do differently? Say differently?"*
2. Ask: *"If that happened — who else might notice? Who might start talking to them, or about this issue?"*
3. Ask: *"If this narrative started gaining traction — whose narrative would that put pressure on?"*

These three questions surface language, network, and power effects from stated objectives. Note the answers as hypotheses (if specific) or open observations (if uncertain). Do not force false precision.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_04_Recode_Module.md

# KB: Recode Phase — Theory + Documentation Questions
**Agent 04 · CHL AI Agent System**
*Load always — phase scope, key concepts, documentation questions, iteration workflow.*

---

## What This Phase Is

Recode is the fourth phase of the Culture Hack Method. It is where analysis becomes strategy, and strategy becomes language.

The phase moves through five connected moments:

**Audience + Objectives** — Define who the hack needs to reach and what it aims to shift. These are co-defined: choosing an objective is choosing an audience. Both must be clear before decode/recode work can begin.

**Decode** — Identify a representative message — a paragraph-length text that carries the logic and framing being challenged. Systematically map its hidden structure: verbs, subjects, images, assumptions, logic, ideology, metaphors, framing. Each element reveals a political choice embedded in the language.

**Recode** — Build an alternative narrative using the same analytical lens. Every element is consciously rebuilt to open different imaginaries, guided by the audience and objectives.

**Message** — Translate the recoded narrative into exact language: the specific words, in a specific order, that activate the new frames for the target audience. The message is one to three paragraphs — it may read more like a manifesto than a slogan, and that is correct. This is the full structure of meaning the hack builds on. The meme, slogan, or condensed cultural unit comes later, in Agent 05a.

**Narrative Strategy** — The standalone synthesis. Integrates audience, objectives, and one or more decode/recode analyses into an action plan: short-term actions (what becomes the Hacking Tree) and long-term hypotheses (what could shift in the narrative space). Always checked against the POV — the strategy is a compass reading, not just a plan.

**Stand-alone use:** This phase can also be used independently of the full cycle — for example, to decode/recode a campaign message, test existing communications, or run a workshop exercise. In stand-alone mode, the Narrative Strategy is optional. Only Decode → Recode → Message is required.

---

## Key Concepts

**Audience vs. Narrative Community**
A Narrative Community (from Agent 03) is the analytical unit — a cluster of actors sharing frames and language, positioned on the Justice/Ontology map. The **Audience** is more specific: the particular people within or across communities that the hack needs to reach. A community is an analytical category; an audience is a person you can picture — with an age, a location, habits, feelings, and a relationship to the issue. The same community may contain multiple distinct audience segments. Hack design works at the people level, not the conceptual level.

**Audience Coherence**
A hack cannot speak simultaneously to audiences with incompatible logics, values, or cultural positions. If a practitioner identifies two audiences that would require contradictory messages, they must either choose one or design separate interventions — each with its own decode/recode thread and its own hack actions. The agent should name this as a strategic choice, not a problem to smooth over.

**Audience Objectives + Social Tipping Point**
For each audience, define: what shift is being sought, why this audience has the potential to move, and what their catalytic capacity is. Catalytic capacity is the potential for movement in this audience to ripple outward — into other communities, other conversations, broader narrative change. This connects to the **Social Tipping Point**: the theory that influencing 10–25% of a conversation can create a chain reaction that shifts the whole. Some audiences are strategically important precisely because they sit at this threshold — they are already connected to the right networks and can carry the reframe further than their own numbers suggest. The strategy question is not just "does this audience shift?" but "does their shift activate catalytic capacity that could cascade?" This is not mandatory for every hack, but it is always worth asking — and the answer shapes how the strategy is designed.

**Representative Message**
The specific text chosen for decode/recode. It must be paragraph-length — long enough to contain the logic, framing, and ideological structure being challenged. The message should already be visible in the 02b/03 outputs: a media excerpt, a campaign text, a community quote, a public statement. If the practitioner wants to decode their own existing message, that is a valid use of the same tool. If no clear message has been identified, the agent helps find or construct one before analysis begins.

**Decode**
Systematic analysis of a narrative's linguistic architecture through eight lenses: Verbs · Subjects & Objects · Evoked Images · Hidden Assumptions · Logic · Ideology · Metaphor · Framing. The goal is not to refute the narrative argument by argument — it is to reveal its hidden structure so the recode can work at the same deep level.

**Recode**
The construction of an alternative narrative using the same eight lenses. Every element is consciously rebuilt, guided by the audience and objectives. The recode is not a mirror inversion of the decode — it is a new construction built from different foundations, shaped by who it needs to reach and what shift it aims to produce.

**Narrative Objectives**
Specific goals for what the intervention aims to shift — framed around audiences, frames, and direction of movement. They include:
- Which audiences to engage and why
- What direction of movement is sought on the Justice/Ontology map
- Which frames to challenge, strengthen, or introduce
- Where the recoded narrative sits in the Window of Discourse and where it aims to move

**Narrative Strategy**
The standalone action plan that emerges from all the work above. It has two layers:
- **Short-term:** the specific intervention to develop in Agent 05a (the first hack)
- **Long-term:** iteration hypotheses — what could shift over time in language, attention, network, or power

The strategy should also surface the **implied effects** of the objectives: if this hack works, what would be visible? The practitioner may have a clear hypothesis, or may hold it open as an observation-based approach (like an A/B test). Both are valid. The agent helps formulate the effects rather than demanding certainty.

---

## The Eight Lenses (Decode + Recode)

| Element | Question |
|---------|----------|
| **Verbs — Actions** | What actions are present? Who acts, who is acted upon? What actions are made invisible? |
| **Subjects & Objects — Actors** | Who has agency? Who is absent? What power dynamics are encoded in who does what to whom? |
| **Evoked Images** | What mental pictures, sensory associations, and emotional resonances does this language produce? |
| **Hidden Assumptions** | What must already be believed for this message to make sense? What questions are not allowed? |
| **Logic — Truth Claims** | What is stated as fact? What causal logic is embedded? What counts as evidence? |
| **Ideology — Worldview** | What larger belief system does this serve? What future does it imply? What does it protect? |
| **Metaphor** | What is the primary metaphor? What does it make thinkable — and what does it foreclose? |
| **Framing — Point of View** | Whose perspective is centred? What is inside the frame and what is outside? Whose interests does this serve? After the analysis, distil the whole into one sentence that captures the coherent worldview — e.g. *"economic growth is more important than life"* or *"development is civilisation."* For the recode, produce the reverse synthesis — e.g. *"life is more important than money"* or *"the future is a territory to defend."* This distilled frame is the most actionable output of the analysis. |

---

## Documentation Questions

**On audience and objectives**
- Who exactly is the hack trying to reach? Describe them as people — not just a category.
- What is the relationship between the practitioner and this audience? What access or connection already exists?
- What shift are you seeking in this audience? What does movement look like for them?
- What is the catalytic potential of this audience — if they shift, what else could move?
- If you have named more than one audience: are these coherent? Do they require the same message, or different ones?

**On finding the representative message**
- Looking at the 02b/03 outputs: is there a quote, excerpt, or text that captures the dominant narrative being challenged?
- Does this text contain the logic, framing, and assumptions you want to work against?
- Is it paragraph-length — specific enough to analyse, not just a single phrase?
- If you are decoding your own existing message: what prompted this, and what do you suspect it might be doing unintentionally?

**On Decode**
- Walk through the eight lenses: what do you find in each?
- What does this narrative make invisible? What does it make seem natural or inevitable?
- What ideology does it serve, and what future does it foreclose?
- Which lens reveals the most important strategic insight?

**On Recode**
- For each element: what changes, why, and what effect is intended?
- What new frames and metaphors are being activated?
- Is the recode building from the audience's own language and cultural references?
- What is the exact message — the specific words that carry this reframe?

**On Narrative Strategy**
- What is the short-term action this strategy leads to? What gets handed to Agent 05a?
- If there is more than one decode/recode: how do they integrate into one strategy?
- What are the long-term hypotheses? What could shift in attention, network, power, or language if this works?
- Are these hypotheses specific, or held open for observation? Either is valid — name which.
- What does the practitioner need to see in Agent 05b's evaluation to know this strategy is working?

---

## What Comes Before / After

**Before:** Receives **Community Analysis Report + Narrative Map + Window of Discourse assessment** from Agent 03. The community map — including quadrant positions, Catalytic community identifications, and Window of Discourse placement — is the strategic foundation for setting audience, objectives, and building the reframe.

**After:** Passes **Narrative Strategy + Recoded Narrative (with Message)** — and optionally **Audience Profile(s)** — to **Agent 05a (Hacking Tree)**, which translates the message into a concrete cultural intervention.

**On iteration:** In a second or later cycle, the Recode is revised based on what the hack revealed. New community insights may shift target audiences, frame priorities, or the message itself. The POV may also be sharpened here. The strategy's long-term hypotheses are tested against what Agent 05b found and updated accordingly.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
