# FILE: KB_05b_Impact_Actions_A.md

# KB: Impact & Iteration — Actions A: Pre-Hack Documentation Plan
**Agent 05b · CHL AI Agent System**
*Load when producing Output A — before the hack launches.*

---

## What Output A Is

The Pre-Hack Documentation Plan is the evaluation infrastructure set up *before* the hack launches. Without it, Output B has no baseline to compare against and no structured data to analyse.

It covers three things:
1. **Baseline capture** — the state of the narrative space and target audience *before* the hack
2. **Monitoring setup** — what to track during and immediately after launch, and how
3. **Evaluation calendar** — when to collect data at each level, and who is responsible

This output is the bridge between Agent 05a's Logistics (which identifies what to document) and a rigorous evaluation. It takes the practitioner from "we should document this" to "here is exactly what we are capturing, when, and how."

---

## Output A Template

```
## Pre-Hack Documentation Plan

**Hack:** [name or short description]
**Launch date (planned):** [date]
**Evaluation lead:** [who is responsible for documentation]
**Date this plan was created:** [date]

---

### 1. Baseline Capture

*What the narrative space and target audience look like before the hack.
This becomes the reference point for everything in Output B.*

**Narrative space baseline:**
- Source: [Agent 03 community map / ANP analysis — date and version]
- Window of Discourse position of recoded narrative: [Radical / Emerging / Mainstream]
- Key frames in circulation before the hack: [list the dominant frames]
- Reach and power of target community/audience before the hack: [brief assessment]

**Audience baseline:**
- How does the target audience currently talk about this issue?
  [Capture 3–5 example phrases, headlines, or quotes from the CSV/research]
- What platforms/spaces are they currently active in? [list]
- Current sentiment/emotional mood: [from Tone analysis in Agent 05a]

**Monitoring baseline (snapshot before launch):**
- Metric 1: [e.g. search volume for key terms] — current value: [X] — tool: [Y]
- Metric 2: [e.g. engagement on related content] — current value: [X] — tool: [Y]
- Metric 3: [e.g. community following/reach] — current value: [X] — tool: [Y]

**Documentation of baseline:**
- Stored at: [link / folder / file name]
- Screenshots/exports taken: [yes/no — what was captured]

---

### 2. Monitoring Setup

*What to track during and immediately after launch.*

**Level 1 — Audience monitoring:**

Reach metrics:
- [Metric] — tool: [platform/analytics] — frequency: [daily/weekly]
- [Metric] — tool: [platform/analytics] — frequency: [daily/weekly]

Response metrics (quantitative):
- [Metric — e.g. engagement rate, shares, attendance] — tool: — frequency:

Response signals (qualitative):
- [What to look for — e.g. comments, messages, quotes, stories]
- [How to capture — e.g. screenshot, note in log, interview]

**Level 2 — Discourse monitoring:**

Attention:
- Keywords/frames to track: [list — drawn from Agent 04 Recode]
- Platforms to monitor: [list]
- Frequency: [weekly / monthly]
- Tool: [AI research tool / manual scan / social listening]

Network:
- New connections to watch for: [who might start talking to whom?]
- Citation/amplification tracking: [how — tool and frequency]

Power:
- Legitimacy signals to watch for: [media pickup, policy references, institutional uptake]
- Window of Discourse: [what would indicate movement?]

**Level 3 — Systems change signals:**
- Early tipping point signals relevant to this hack: [drawn from Agent 04 hypotheses]
- How to document if observed: [note in log / research snapshot / relationship record]

**A/B testing (if applicable):**
- Version A: [description] — tracking: [what metrics distinguish it]
- Version B: [description] — tracking: [what metrics distinguish it]
- Comparison method: [how you'll assess which performed better and why]

---

### 3. Evaluation Calendar

| Timeframe | Level 1: Audience | Level 2: Discourse | Level 3: Systems | Responsible |
|-----------|------------------|-------------------|-----------------|-------------|
| During launch (week 1–2) | [metrics/methods] | [initial scan] | [n/a or note] | [who] |
| Short-term (1–3 months) | [reach + response] | [attention shifts] | [early signals] | [who] |
| Medium-term (3–6 months) | [adoption signals] | [network + power] | [contribution] | [who] |
| Long-term (6+ months) | [embedding] | [full ANP rescan] | [tipping indicators] | [who] |

**Resources allocated:**
- Time per week for monitoring: [hours]
- Team member(s) responsible: [names/roles]
- Tools/subscriptions needed: [list]
- Budget for evaluation: [amount if applicable]

---

### 4. Readiness Check

Before launch, confirm:
- [ ] Baseline data is documented and stored
- [ ] Monitoring tools are set up and tested
- [ ] Team knows who is responsible for what
- [ ] Evaluation calendar is agreed
- [ ] Agent 04 hypotheses are accessible for comparison in Output B
```


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05b_Impact_Actions_B.md

# KB: Impact & Iteration — Actions B: Post-Hack Evaluation
**Agent 05b · CHL AI Agent System**
*Load when producing Output B — after the hack. Standalone, pasteable into any phase agent.*

---

## What Output B Is

Output B is the operational evaluation. It is what the practitioner needs to understand what shifted — and what to do next. It is standalone and pasteable: paste it into any phase agent (Agent 01–05) to activate iteration mode for that phase.

It does not require Output C or Output D to be useful. It is the minimum viable output from this phase to continue the cycle.

If A/B testing was used, treat both versions as part of the same hack. Document both and compare — the learnings from both count.

---

## Output B Template

```
## Post-Hack Evaluation

**Hack:** [name or short description]
**Launch date:** [date]
**Evaluation date:** [date]
**Baseline reference:** [Output A date / Agent 03 date — what you're comparing against]

---

### Level 1 — Audience Impact

**Reach:**
- Target audience reached: [estimate + evidence]
- Platforms/spaces: [where the hack landed]
- Comparison to baseline: [what changed vs. before]
- If A/B: Version A reach: [X] — Version B reach: [X] — difference: [observation]

**Response:**
Quantitative:
- [Metric]: [result] — baseline was: [X]
- [Metric]: [result] — baseline was: [X]

Qualitative:
- What people said: [2–4 specific quotes or observations]
- What people did: [actions taken in response]
- Unexpected reactions: [anything surprising — positive or negative]
- If A/B: What distinguished the responses to each version?

**Adoption (signals so far):**
- Early uptake (0–3 months): [are target audiences using new frames or language?]
- Framing adoption signals: [specific examples if any]
- Behavioural signals: [any change in how people act around this issue]

---

### Level 2 — Discourse Impact

*Compare against ANP baseline from Agent 03.*

**Attention:**
- Before: [baseline from Agent 03]
- After: [current state]
- Shifts observed: [are recoded frames appearing more? Are challenged frames losing traction?]
- Evidence: [specific examples — posts, articles, conversations]

**Network:**
- Before: [baseline from Agent 03]
- After: [current state]
- New connections or bridges: [any new actor relationships?]
- Evidence: [specific examples]

**Power:**
- Before: [baseline from Agent 03]
- After: [current state]
- Legitimacy/reach changes: [whose narrative gained or lost ground?]
- Evidence: [specific examples]

**Window of Discourse:**
- Before: [position from Agent 03]
- After: [current position]
- Movement observed: [even incremental — note it]

---

### Level 3 — Systems Change Contribution

**Early signals visible now:**
[What small signs of broader shift are observable? Be honest — a single hack rarely produces systemic change. The question is whether it is contributing to the conditions.]

**Connection to broader movement:**
[How does this hack connect to other hacks, campaigns, or movements working in the same space?]

**Contribution to tipping point conditions:**
- Attention convergence signals: [any evidence of 10–25% adoption in target network?]
- Network intertwining signals: [any unprecedented alliances or connections?]
- Power realignment signals: [any movement from fringe toward mainstream?]

**Realistic horizon:**
[What is achievable vs. aspirational? What is this hack contributing to long-term?]

---

### Three Closing Questions

*Human co-creation. The agent can generate context-specific questions to help you arrive at your answers — but the answers come from you.*

**What are the implications of this work for you personally?**
[Your reflection]

**What are the implications of this work for your community?**
[Your reflection]

**What are the implications of this work for the planet?**
[Your reflection]

---

### Learnings

**What worked:**
[Be specific — what element of the hack (media, meme, tone, space, scale, moment) performed best and why?]

**What didn't work:**
[What would you change? What failed or underperformed?]

**What surprised you:**
[Anything unexpected — in the response, in the discourse, in the logistics]

**If A/B tested:**
- Version A learnings: [what it revealed]
- Version B learnings: [what it revealed]
- Key lesson: [what the comparison taught you]

---

### Iteration Strategy

*Based on what the evaluation found, here is where the cycle needs attention and which agent handles it.*

**Primary iteration need:** [what most needs updating in the next cycle]

| Finding | Phase to update | Agent | What to do |
|---------|----------------|-------|------------|
| [e.g. audience didn't shift] | Recode | Agent 04 | Revise message or audience targeting |
| [e.g. baseline was thin] | Listen | Agent 02a → 02b | Update Listening Model, new research |
| [e.g. community map outdated] | Understand | Agent 03 | Update community profiles |
| [e.g. hack design didn't land] | Hack | Agent 05a | Redesign Hacking Tree |
| [e.g. strategy misaligned with POV] | Ask → Recode | Agent 01 → 04 | Refine POV, revise strategy |
| [e.g. strong signals — amplify] | Hack | Agent 05a | Design next hack building on what worked |

**Recommended next step:**
[Name the single most important action for the next cycle and which agent to activate]

**What to paste into the next agent:**
[This Output B document is designed to be pasted directly into Agent 01, 02a, 03, 04, or 05 to activate iteration. The agent will read it and propose specific updates based on what was found.]
```

---

## Agent Guidance: Three Closing Questions

If the practitioner says "I don't know" or "I'm not sure how to answer," draw on the specific hack context to generate in-depth prompts. Examples:

**For "implications for me personally":**
- "You named [specific surprise or learning] as unexpected. What does that reveal about your assumptions going in — and how has that changed you?"
- "The hack reached [audience]. What did working with them teach you about your own relationship to this issue?"

**For "implications for my community":**
- "Your community appeared as [community description from hack]. What does this evaluation suggest about where they are in the narrative space — and what role they could play next?"
- "Did this hack change anything in how your community talks about [issue]? Even small signals count."

**For "implications for the planet":**
- "Your POV named [theory of change]. Based on what you observed — are you more or less confident that this pathway leads where you hoped? What would need to be true for it to get there?"
- "This hack contributed [specific early signal] toward [tipping point condition]. What does that mean for the larger ecological or social transformation your work is pointed toward?"


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05b_Impact_Actions_C.md

# KB: Impact & Iteration — Actions C: Hack Database
**Agent 05b · CHL AI Agent System**
*Load when producing Output C — the full cycle synthesis record.*

---

## What Output C Is

The Hack Database is the institutional memory of the hack — a structured synthesis of the complete cycle from Ask to Evaluate. It captures the essential outputs of each phase in one navigable document.

It is a living record: it can be opened and updated at any point — before the hack, during it, after it, or across multiple cycles. It is not a worksheet or audit. It is a synthesis: the key decisions, the key findings, and the key learnings, organised to be useful for future cycles, for organisational knowledge, and for reporting.

**In Learning Mode / Stand-alone:** If the practitioner is reconstructing a past hack without prior agent outputs, the agent conducts a structured interview — one section at a time, one question at a time. Paste in whatever documentation exists; the agent will extract what it can and ask for what is missing.

**The three closing questions are the only section that is always co-created.** Everything else can be reconstructed from documentation, research, or interview. But the implications for self, community, and planet must come from the practitioner.

---

## Hack Database Template

```
## Hack Database: [Hack Name]

**Collective:** [who]
**Version:** [1.0 / 2.0 — update number and date when revised]
**Cycle:** [cycle number if iterating]
**Period:** [from POV development to evaluation]
**Last updated:** [date]

---

### Section 1 — Point of View

**Extended POV:** [full paragraph]
**Short POV:** [1–3 sentences]
**Theory of change:** [how narrative shift connects to systems change]
**Pathway:** [optional — Rhizome Fellowship only]

---

### Section 2 — Listening Model

**Research question:** [the specific inquiry that oriented the research]
**Listening objectives:** [2–4 questions the research was designed to answer]

**Small Listening summary:**
- Methods used: [interviews / surveys / observation / manual media analysis]
- Key findings: [2–4 bullet points]

**Big Listening summary:**
- Research scope: [platforms / geography / timeframe]
- Key patterns: [2–4 bullet points]

**Baseline date:** [when this research was conducted]

---

### Section 3 — Narrative Communities

**Communities identified:**

| Community | Type | Justice (X) | Ontology (Y) | Quadrant | Key frame |
|-----------|------|-------------|--------------|----------|-----------|
| [Name] | [H/A/C] | [0–100] | [0–100] | [LL/LR/UL/UR] | [one line] |
| [Name] | [H/A/C] | | | | |
| [Name] | [H/A/C] | | | | |

**Window of Discourse (baseline):**
- Mainstream: [dominant narratives]
- Emerging: [rising narratives]
- Radical: [marginalised narratives]
- Position of recoded narrative at baseline: [Radical / Emerging / Mainstream]

**Catalytic communities:** [which communities have tipping point potential and why]

---

### Section 4 — Recode

**Audience(s):**
[Name and brief profile of each audience the hack targeted]

**Narrative objectives:**
- Target community 1: [desired movement on Justice/Ontology map]
- Target community 2 (if applicable): [desired movement]

**Frame synthesis (decoded):** [one-line distillation of the dominant narrative — e.g. "economic growth is more important than life"]

**Frame synthesis (recoded):** [one-line distillation of the alternative — e.g. "life is more important than money"]

**Recoded message:** [full 1–3 paragraph message from Agent 04]

**Long-term hypotheses (from Narrative Strategy):**
- Language: [what was expected to shift]
- Attention: [what was expected to shift]
- Network: [what was expected to shift]
- Power: [what was expected to shift]

---

### Section 5 — Hacking Tree

**Media:**
- Format: [specific medium]
- Audience fit: [why this format]
- Distribution: [how it reached the audience]

**Meme:**
- Symbol: [what was used]
- Association remix: [from → to]
- Synthesis: [the exact cultural unit — hashtag / slogan / image / gesture]

**Tone:**
- Emotional journey: [from → through → to]
- Primary stimuli: [key creative tools used]

**Hack:**
- Space: [where — type and specific location/platform]
- Scale: [Micro / Meso / Macro / Mega] — realistic reach: [estimate]
- Moment: [when — planned / event-responsive / cyclical]
- Point of intervention: [production / destruction / consumption / decision / assumption / potential]

---

### Section 6 — Logistics Summary

- Timeline: [development → launch → evaluation dates]
- Team: [key roles]
- Budget: [total / secured / spent]
- Key external needs: [what was sourced]

---

### Section 7 — Evaluation

*(Paste Output B here, or summarise if Output B was completed separately)*

**Level 1 — Audience impact summary:**
[3–5 sentences: reach, response, adoption signals]

**Level 2 — Discourse impact summary:**
[3–5 sentences: ANP shifts, Window of Discourse movement]

**Level 3 — Systems change contribution summary:**
[2–3 sentences: early tipping point signals, connection to broader movement]

**Key learnings:**
- What worked: [brief]
- What didn't: [brief]
- What surprised: [brief]

---

### Section 8 — Closing Reflections

*Human co-creation. These answers come from the practitioner.*

**Implications for me personally:**
[Practitioner's reflection]

**Implications for my community:**
[Practitioner's reflection]

**Implications for the planet:**
[Practitioner's reflection]

---

### Section 9 — Iteration Plan

*(Drawn from Output B iteration strategy)*

**Next cycle priority:** [what most needs updating]
**Recommended next agent:** [which agent to activate and why]
**POV status:** [stable / refined — note if changed]
**What carries forward into the next cycle:** [key insights, updated frames, new community knowledge]
```

---

## Versioning

When the Database is updated for a new cycle:
- Increment the version number (e.g. 1.0 → 2.0)
- Add a "What Changed" note at the top of any updated section
- Do not delete previous cycle data — add alongside it with cycle labels
- The CSV Database from Agent 02b is extended, not replaced (same principle)


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05b_Impact_Actions_D.md

# KB: Impact & Iteration — Actions D: Case Study
**Agent 05b · CHL AI Agent System**
*Load when producing Output D — the publishable case study.*

---

## What Output D Is

The Case Study is movement knowledge — a 4–6 page narrative written to be shared with others for learning and iteration. It tells the story of the hack: what was done, what shifted, what was learned, and what comes next.

It is written *with* the practitioner, not *for* them. The agent proposes language drawn from the documentation (Output C or equivalent). The practitioner approves, adjusts, and adds. Nothing is invented.

**Requires:** Output C (Hack Database) or equivalent documentation covering the full cycle. If Output C is incomplete, the agent will identify the gaps before producing the case study.

**Optional Rhizome Fellowship fields** are marked clearly — include only if working within the Fellowship context.

**Tone:** The case study is not an academic report. It is a practitioner narrative — clear, grounded, honest about what didn't work, and oriented toward what others can learn from it.

---

## Case Study Structure

### Page 1 — Who We Are + The Context

```
## [Hack Name] — Case Study

**Collective:** [who — name, brief description, where based]
**Period:** [dates — from POV development to evaluation]
**Pathway:** [optional — Rhizome Fellowship only]
**Issue:** [one sentence — what narrative space was being hacked]

---

### Our Point of View

[Extended POV — collective identity, narrative observation, vision, theory of change.
Written in the practitioner's own voice. The agent proposes from the Database; the practitioner adjusts.]

### The Narrative Space We Entered

[2–3 paragraphs describing the narrative landscape before the hack:
- What dominant narratives were in circulation
- What communities were involved and where they sat
- What the Window of Discourse looked like
- Why this space needed hacking — what the POV was responding to]
```

### Page 2 — What We Did: The Strategy

```
### Our Audience

[Who specifically the hack was designed to reach — described as people, not categories.
Their relationship to the issue, their cultural ground, their catalytic potential.]

### Our Objectives

[What shifts were being sought — in audience, in discourse, in the narrative space.
What hypotheses the strategy was testing.]

### The Frame We Challenged

[The decoded frame synthesis — one line.
Brief description of the representative message decoded and what it was doing.]

### The Frame We Built

[The recoded frame synthesis — one line.
The recoded message — full text, 1–3 paragraphs.]
```

### Page 3 — The Hack

```
### The Hacking Tree

**Media:** [format and why — one paragraph]

**Meme:** [the cultural unit — what it was, how the symbol was remixed, why it was sticky]

**Tone:** [the emotional strategy — what feelings were designed, what journey the audience was invited on]

**Hack:** [space, scale, and moment — where, how big, when, and why that combination]

### How It Came to Life

[1–2 paragraphs: the production and launch story. Who was involved. What happened.
What it looked like in the world. Any creative or logistical surprises.]
```

### Page 4 — What Shifted

```
### Level 1 — Audience Impact

[What the hack reached and how people responded.
Quantitative signals and qualitative stories.
Early adoption indicators if visible.
If A/B tested: what the comparison revealed.]

### Level 2 — Discourse Impact

[What shifted in attention, network, and power — compared against baseline.
Window of Discourse movement, even incremental.
New connections or bridges that emerged.]

### Level 3 — Systems Change Contribution

[Early signals of broader shift.
How this hack connects to other movements in the space.
What tipping point conditions it is contributing to.
Honest about timescale — not overclaiming.]
```

### Page 5 — What We Learned

```
### What Worked

[Be specific — which element of the Hacking Tree performed best and why.
What about the strategy proved effective.]

### What Didn't Work

[Be honest — what failed, underperformed, or produced unexpected negative responses.
What would be done differently.]

### What Surprised Us

[Anything unexpected — positive or negative — that the team didn't anticipate.]

### For Others Doing This Work

[2–4 practical lessons for other narrative practitioners working in a similar space.
Written as direct guidance, not abstraction.]
```

### Page 6 — Looking Forward

```
### The Next Cycle

[What the evaluation revealed about what the next hack needs.
Which phase of the method needs the most attention — and what will be done differently.]

### Three Reflections

*In the practitioner's own words.*

**For me personally:**
[Implications of this work for the practitioner — what was learned, what changed, what remains.]

**For my community:**
[Implications for the community this work serves — what shifted, what is now possible, what is still needed.]

**For the planet:**
[Implications for the larger ecological and social transformation this work is pointed toward — what this hack contributed to, what still needs to happen.]

### Rhizome Fellowship Reflection *(optional — Fellowship context only)*
[Connection to the Pathway. What this work contributed to the broader Fellowship ecosystem. What the practitioner is carrying forward into future work.]
```

---

## Writing Principles

**Voice** — The case study should sound like the practitioner, not like a report. The agent proposes language; the practitioner owns it.

**Honesty** — What didn't work is as valuable as what did. The case study is for learning, not for showcasing success. Honest failure is more useful to the movement than polished victory.

**Specificity** — Vague claims ("the hack reached many people") undermine credibility. Use real numbers, real quotes, real examples wherever possible.

**No invention** — The agent never invents facts, quotes, or outcomes. If something is unknown or undocumented, it says so and asks the practitioner to fill it in.

**Length** — 4–6 pages. Longer than a summary, shorter than a report. Each page should be substantive but readable in 2–3 minutes.

---

## Before Producing

Confirm the following are available:
- [ ] Output C (Hack Database) — or equivalent documentation of the full cycle
- [ ] Output B (Evaluation) — especially Level 1–3 findings and learnings
- [ ] The three closing reflections — must come from the practitioner (agent can prompt, not fill in)
- [ ] Any quotes, stories, or images the practitioner wants to include

If Output C is incomplete, identify which sections are missing and ask the practitioner to provide them or work through Output C first.


---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*


# FILE: KB_05b_Impact_Module.md

# KB: Impact & Iteration — Theory + Documentation Questions
**Agent 05b · CHL AI Agent System**
*Load always — phase scope, evaluation theory, reflection questions, iteration logic.*

---

## What This Phase Is

Impact & Iteration is the closing and opening of the cycle. It answers the central question: *is the narrative space being rewilded?*

It is nested within the Hack phase — not a separate endpoint. The cycle runs: launch → monitor → evaluate → adapt → relaunch. Each turn of the cycle sharpens the strategy and increases the chances of the hack shifting the narrative space.

This phase has four outputs that serve different purposes and different moments. None of them blocks the others. Output B alone is enough to keep hacking.

**On prototyping:** Think of early hacks as prototypes. They won't be perfect — they grow through experiments. A/B testing (running two versions and comparing outcomes) is a valid evaluation approach. Both versions count as part of the same hack and generate learning. Document both; compare what worked.

**On the three closing questions:** Every evaluation — whether a quick Output B or a full case study — closes with three personal reflection questions:
- What are the implications of this work for me personally?
- What are the implications of this work for my community?
- What are the implications of this work for the planet?

These are human co-creation moments, not data fields. The agent can generate in-depth questions drawn from the hack's specific context to help the practitioner arrive at their own answers — but the answers must come from the practitioner. They can be data-informed (grounded in what the evaluation found) or purely personal. Both are valid.

---

## The Three Levels of Evaluation

### Level 1 — Audience Impact
*Timescale: weeks to months. The hack reached specific people and provoked specific responses.*

**Reach** — how many people in the target audience saw or encountered the hack?
**Response** — did it spark the emotions and reactions intended? Quantitative (engagement metrics) and qualitative (what people said and did).
**Adoption** — are target audiences using the new frames, language, or behaviours? Short-term (0–3 months): early uptake. Medium-term (3–6 months): integration. Long-term (6+ months): cultural embedding.

For A/B testing: compare reach, response, and adoption across versions. Document what distinguished the higher-performing version.

### Level 2 — Discourse Impact
*Timescale: months. The narrative space itself is shifting.*

Narrative shifts happen when the audience not only receives the reframe but integrates and repeats it — when the narrative becomes not only *known* but *owned*.

Measure against the ANP baseline from Agent 03:
**Attention** — did the hack draw focus? Are the recoded frames appearing more frequently? Are the frames being challenged losing traction?
**Network** — are new connections forming between previously separate actors, platforms, or communities? Are bridge actors emerging?
**Power** — is there stronger coherence around the reframed logic? Are the frames gaining authority and legitimacy? Where does the recoded narrative now sit in the Window of Discourse?

To evaluate discourse shifts, return to the Listen phase (Agent 02b): run a new research cycle with updated parameters and compare to the baseline.

### Level 3 — Systems Change Contribution
*Timescale: years. The hack is contributing to tipping point conditions.*

A tipping point is reached when:
- **Attention convergence** — enough people are shifting focus toward the recoded frames (10–25% adoption signal)
- **Network intertwining** — disparate actors and platforms begin to connect; networks converge and multiply discourse force
- **Power realignment** — the reframe becomes common sense; a catalytic community moves from fringe to mainstream; narrative change starts to restructure politics, culture, and material life

No single hack produces a tipping point. The question is whether it is contributing to the conditions for one. Assess early signals honestly. A realistic horizon matters more than aspirational claims.

---

## Documentation Questions

**On baseline and readiness (for Output A)**
- Is the baseline from the Listen/Understand phases accessible and documented?
- Are the narrative objectives from Agent 04 specific enough to evaluate against?
- What does the target audience currently look like — before the hack?
- What monitoring is in place for during and after launch?

**On audience impact (for Output B)**
- How far did the hack travel? Who saw it, and where?
- How did the target audience respond — quantitatively and qualitatively?
- Were there unexpected reactions — positive or negative?
- Are there early signs that the new frames or language are being adopted?
- If A/B testing: which version performed better, and what explains the difference?

**On discourse impact (for Output B)**
- Comparing against the ANP baseline: what has changed in attention, network, and power?
- Are the frames being challenged losing traction? Are the recoded frames appearing more frequently?
- Has the Window of Discourse position of the recoded narrative shifted at all?
- Are there new connections between communities that didn't exist before?

**On systems change (for Output B)**
- What early signals of broader shift are visible — even small ones?
- How does this hack connect to other movements or narratives working in the same space?
- What is this hack contributing to in terms of longer-term tipping point conditions?

**On the three closing questions (for Output B, C, and D)**
- What are the implications of this work for you personally?
- What are the implications of this work for your community?
- What are the implications of this work for the planet?

*If the practitioner is unsure, the agent draws on the specific hack context — who was reached, what shifted, what the POV pointed toward — and generates targeted questions to help them arrive at their own answers.*

**On learnings and iteration (for Output B)**
- What worked? What didn't? What surprised you?
- What would you do differently in the next hack?
- What does the next cycle need — updated research, revised strategy, different timing, different audience?

---

## Iteration Logic

After evaluation, the cycle continues. Output B includes an explicit iteration strategy: based on what the evaluation found, which phase needs updating and which agent handles it.

| What the evaluation found | Where to go | What to do |
|---------------------------|-------------|------------|
| Audience didn't shift as expected | Agent 04 | Revise message, recode, or audience targeting |
| Research baseline was too thin | Agent 02a → 02b | Update Listening Model, run new research |
| Community map needs updating | Agent 03 | Update community profiles with new data |
| Hack design didn't land | Agent 05a | Redesign Hacking Tree — different media, meme, tone, space, or moment |
| Strategy was misaligned with POV | Agent 01 → 04 | Refine POV, then revise narrative strategy |
| Strong early signals — amplify | Agent 05a | Design next hack building on what worked |

The practitioner does not restart at Agent 01. The POV is refined, not rebuilt. Community profiles are updated, not rediscovered. Each cycle deepens the practice.

---

## What Comes Before / After

**Before:** Receives the **Hacking Tree + Logistics Plan** from Agent 05a, plus all prior documentation: baseline from Agents 02b and 03, narrative strategy and hypotheses from Agent 04, POV from Agent 01.

**After:** Output B feeds back into any phase agent to activate iteration. Output C becomes the persistent institutional record. Output D becomes movement knowledge — publishable and shareable.

---

*v2.0.0 · updated 2026-07-05 · Part of the CHL AI Agent System. See `KB_Agent_Directory.md` for the full system map.*
